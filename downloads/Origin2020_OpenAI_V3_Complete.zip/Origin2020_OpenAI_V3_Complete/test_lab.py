"""Offline regression tests. No API key, Origin or Windows required."""
import copy
import io
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

import pandas as pd

from lab_core import (
    ai_plan, curve_color, default_plan, export_excel, group_key,
    inspection_payload, load_tables, materialize, numeric_blocks, plan_schema,
    query_curves, read_text, save_run, validate_plan,
)


def example_excel():
    frame = pd.DataFrame([
        ["Device", "A01", None, None],
        ["Voltage (V)", "Current (A)", "Polarization (uC/cm2)", "Other"],
        [-2, -1, -5, None], [0, 2, -1, None], [2, 3, 5, None],
        [0, -2, 1, None], [-2, -3, -5, None],
        ["END", None, None, None],
    ])
    stream = io.BytesIO()
    with pd.ExcelWriter(stream, engine="openpyxl") as writer:
        frame.to_excel(writer, index=False, header=False, sheet_name="Sweep")
        frame.iloc[:6].to_excel(writer, index=False, header=False, sheet_name="Second")
    return stream.getvalue()


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.tables = load_tables([("sample_3V_10kHz.xlsx", example_excel())], self.root / "raw")
        self.plan = default_plan(self.tables)
        for spec in self.plan["curves"]:
            spec["metadata"]["split_condition"] = "anneal-400C"

    def tearDown(self):
        self.tmp.cleanup()

    def test_multiple_sheets_shared_x_multiple_y(self):
        self.assertEqual(len(self.tables), 2)
        self.assertEqual(len(self.plan["curves"]), 4)
        curves = materialize(self.plan, self.tables)
        self.assertEqual(curves[0].data.x.tolist(), [-2, 0, 2, 0, -2])
        self.assertEqual(curves[0].data.source_row.tolist(), [3, 4, 5, 6, 7])
        self.assertEqual(curves[0].spec["metadata"]["frequency_hz"], 10000)
        self.assertEqual(curves[0].spec["metadata"]["voltage_v"], 3)

    def test_independent_xy_pairs(self):
        content = b"meta\nV,I,Time,Signal\n-1,2,10,5\n0,3,11,6\n1,4,12,7\n"
        tables = load_tables([("pairs.csv", content)], self.root / "raw")
        plan = default_plan(tables)
        spec = copy.deepcopy(plan["curves"][0])
        spec.update(x_column="C", y_column="D", x_name="Time", y_name="Signal")
        plan["curves"] = [plan["curves"][0], spec]
        curves = materialize(plan, tables)
        self.assertEqual(curves[1].data.x.tolist(), [10, 11, 12])
        self.assertEqual(curves[1].data.y.tolist(), [5, 6, 7])

    def test_missing_values_are_filtered_per_pair(self):
        table = self.tables[0]
        table.frame.iat[3, 2] = None
        plan = copy.deepcopy(self.plan)
        curves = materialize(plan, self.tables)
        self.assertEqual(len(curves[0].data), 5)
        self.assertEqual(len(curves[1].data), 4)
        self.assertEqual(curves[1].excluded_rows, 1)

    def test_hysteresis_zero_crossings_preserve_both_branches(self):
        c = materialize(self.plan, self.tables)[0]
        self.assertEqual([r["value"] for r in c.metrics["y_at_x_zero"]], [2, -2])
        self.assertGreater(len(c.metrics["x_at_y_zero"]), 1)

    def test_interpolation_does_not_bridge_removed_rows(self):
        table = self.tables[0]
        table.frame.iat[3, 1] = None
        table.frame.iat[5, 1] = None
        c = materialize(self.plan, self.tables)[0]
        self.assertEqual(c.metrics["y_at_x_zero"], [])

    def test_comparison_at_selected_x_is_recorded_per_run(self):
        one = materialize(self.plan, self.tables)
        db = self.root / "test.sqlite3"
        save_run(db, "one", "zero", self.plan, one)
        second = copy.deepcopy(self.plan)
        second["compare_at_x"] = 1
        two = materialize(second, self.tables)
        self.assertEqual(one[0].curve_id, two[0].curve_id)
        self.assertEqual(len(two[0].metrics["y_at_comparison_x"]), 2)
        self.assertEqual(save_run(db, "two", "one volt", second, two), 0)
        with sqlite3.connect(db) as con:
            metrics = json.loads(con.execute("SELECT metrics_json FROM run_curves WHERE run_id=? LIMIT 1", ("two",)).fetchone()[0])
        self.assertEqual(metrics["comparison_x"], 1)

    def test_sqlite_idempotent_point_order_and_condition_search(self):
        db = self.root / "test.sqlite3"
        curves = materialize(self.plan, self.tables)
        self.assertEqual(save_run(db, "run", "request", self.plan, curves), 4)
        self.assertEqual(save_run(db, "run", "request", self.plan, curves), 0)
        self.assertEqual(len(query_curves(db, {"voltage_v": 3})), 4)
        self.assertEqual(len(query_curves(db, {"voltage_v": 5})), 0)
        with sqlite3.connect(db) as con:
            points = con.execute("SELECT x FROM points WHERE curve_id=? ORDER BY point_index", (curves[0].curve_id,)).fetchall()
        self.assertEqual([p[0] for p in points], [-2, 0, 2, 0, -2])

    def test_unknown_group_conditions_do_not_merge(self):
        plan = copy.deepcopy(self.plan)
        plan.update(plot_mode="grouped", group_by=["voltage_v"])
        for spec in plan["curves"]:
            spec["metadata"]["voltage_v"] = None
        curves = materialize(plan, self.tables)
        self.assertNotEqual(group_key(curves[0], plan), group_key(curves[2], plan))

    def test_same_condition_same_color_different_units_separate(self):
        curves = materialize(self.plan, self.tables)
        self.assertEqual(curve_color(curves[0], self.plan), curve_color(curves[2], self.plan))
        self.assertNotEqual(group_key(curves[0], self.plan), group_key(curves[1], self.plan))

    def test_ragged_text_headers_and_repeated_blocks(self):
        content = b"instrument A\nvoltage current\n-1 2\n0 3\n1 4\n\nvoltage current\n-1 4\n0 5\n1 6\nEND\n"
        frame = read_text(content)
        self.assertEqual(numeric_blocks(frame), [(3, 5), (8, 10)])
        self.assertEqual(frame.iloc[6, 0], "voltage")

    def test_cp949_text_and_wide_excel_columns(self):
        text = "전압\t전류\n-1\t2\n0\t3\n1\t4\n".encode("cp949")
        self.assertEqual(read_text(text).iloc[0, 0], "전압")
        frame = pd.DataFrame([["header"] * 55, list(range(55)), list(range(1, 56))])
        stream = io.BytesIO()
        frame.to_excel(stream, index=False, header=False)
        tables = load_tables([("wide.xlsx", stream.getvalue())], self.root / "raw")
        plan = default_plan(tables)
        self.assertEqual(plan["curves"][-1]["y_column"], "BC")
        validate_plan(plan, tables)

    def test_invalid_ai_selections_and_duplicates_rejected(self):
        for field, value in (("start_row", 0), ("end_row", 99999), ("x_column", "ZZ"), ("source_id", "not_uploaded"), ("x_column", "B")):
            with self.subTest(field=field, value=value):
                plan = copy.deepcopy(self.plan)
                plan["curves"][0][field] = value
                with self.assertRaises(ValueError):
                    validate_plan(plan, self.tables)
        plan = copy.deepcopy(self.plan)
        plan["curves"].append(copy.deepcopy(plan["curves"][0]))
        with self.assertRaises(ValueError):
            validate_plan(plan, self.tables)

    def test_duplicate_uploads_and_filename_paths(self):
        data = example_excel()
        tables = load_tables([("../../device.xlsx", data), ("copy.xlsx", data)], self.root / "raw")
        self.assertEqual(len(tables), 4)  # different filenames may encode different device conditions
        self.assertEqual(tables[0].filename, "device.xlsx")
        self.assertEqual(len(list((self.root / "raw").glob("*.xlsx"))), 1)

    def test_excel_export_is_readable_and_contains_ordered_points(self):
        curves = materialize(self.plan, self.tables)
        data = export_excel(curves)
        with pd.ExcelFile(io.BytesIO(data)) as xls:
            self.assertEqual(len(xls.sheet_names), 5)
            first = pd.read_excel(xls, sheet_name="Curve_0001")
            self.assertEqual(first.x.tolist(), [-2, 0, 2, 0, -2])

    def test_openai_responses_contract_without_network(self):
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text=json.dumps(self.plan)))))
        result = ai_plan(self.tables, "same 3V", "not-a-real-key", "test-model", client=client)
        validate_plan(result, self.tables)
        args = client.responses.create.call_args.kwargs
        self.assertEqual(args["text"]["format"]["type"], "json_schema")
        self.assertTrue(args["text"]["format"]["strict"])
        self.assertNotIn(self.tables[0].path, args["input"])

    def test_openai_incomplete_response_does_not_execute(self):
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="incomplete", output_text="{broken"))))
        with self.assertRaises(ValueError):
            ai_plan(self.tables, "plot", "no-key", "test", client=client)

    def test_real_openai_sdk_with_mock_http_transport(self):
        import httpx
        from openai import OpenAI
        sent = []
        def respond(request):
            sent.append(json.loads(request.content))
            return httpx.Response(200, json={
                "id": "resp_offline", "object": "response", "created_at": 0,
                "status": "completed", "model": "gpt-4.1-mini",
                "output": [{"id": "msg_offline", "type": "message", "status": "completed",
                            "role": "assistant", "content": [{"type": "output_text",
                            "text": json.dumps(self.plan), "annotations": []}]}],
                "parallel_tool_calls": False, "tools": [], "tool_choice": "auto",
            })
        with OpenAI(api_key="offline-test-only", http_client=httpx.Client(transport=httpx.MockTransport(respond))) as client:
            proposed = ai_plan(self.tables, "same voltage", "unused", "gpt-4.1-mini", client=client)
        validate_plan(proposed, self.tables)
        self.assertEqual(sent[0]["text"]["format"]["name"], "measurement_plan")
        self.assertEqual(len(proposed["curves"]), 4)

    def test_schema_and_inspection_metadata(self):
        import jsonschema
        jsonschema.validate(self.plan, plan_schema())
        payload = json.loads(inspection_payload(self.tables))
        self.assertEqual(payload[0]["sample_rows"][0]["row"], 1)
        self.assertEqual(payload[0]["numeric_blocks_inclusive"], [[3, 7]])


if __name__ == "__main__":
    unittest.main(verbosity=2)
