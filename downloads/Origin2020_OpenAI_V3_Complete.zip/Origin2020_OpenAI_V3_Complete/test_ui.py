"""Streamlit workflow test with a synthetic upload and no remote API requests."""
import io
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
from types import SimpleNamespace

from streamlit.testing.v1 import AppTest

from test_lab import example_excel


class WebWorkflowTests(unittest.TestCase):
    def test_chat_answers_questions_without_plotting_and_keeps_history(self):
        decision = {"action": "answer", "reply": "네, P–V의 가로축은 전압입니다.", "task": ""}
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("chat_agent.chat_turn", return_value=decision) as chat, patch("origin_adapter.plot_origin") as origin, patch("lab_core.ai_plan") as planner:
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(directory).run()
            app.chat_input[0].set_value("P-V 가로축이 전압이지?").run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(app.session_state["chat_messages"][-1]["content"], decision["reply"])
            app.chat_input[0].set_value("방금 설명 조금 더 해줘").run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(len(chat.call_args.args[0]), 2)
            origin.assert_not_called()
            planner.assert_not_called()
            self.assertFalse(Path(directory, "runs").exists())

    def test_chat_plots_only_requested_sheet_and_pv_columns(self):
        upload = io.BytesIO(example_excel())
        upload.name = "bottomUV_10kHz.xlsx"
        def requested(tables, task, *args):
            from lab_core import default_plan, prepare_plan
            plan = default_plan(tables)
            plan["measurement"] = "PV"
            return prepare_plan(plan, tables)
        decision = {"action": "plot", "reply": "선택한 시트의 PV만 처리하겠습니다.", "task": "선택한 Sweep 시트의 PV만"}
        with tempfile.TemporaryDirectory() as directory, patch("streamlit.file_uploader", return_value=[upload]), patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("chat_agent.chat_turn", return_value=decision), patch("lab_core.ai_plan", side_effect=requested) as planner, patch("origin_adapter.plot_origin") as origin:
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(directory).run()
            scope = next(s for s in app.multiselect if s.label == "이번 요청에 사용할 파일 · 시트")
            selected = app.session_state["tables"][0].source_id
            scope.set_value([selected]).run()
            next(c for c in app.checkbox if c.label == "대화에서 플롯을 요청하면 Origin에도 실행").uncheck().run()
            app.chat_input[0].set_value("Sweep 시트 PV만 그려줘").run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            self.assertEqual(len(planner.call_args.args[0]), 1)
            result = app.session_state["result"]
            self.assertEqual(len(result["curves"]), 1)
            curve = result["curves"][0]
            self.assertEqual(curve.source.sheet, "Sweep")
            self.assertEqual(curve.spec["metadata"]["measurement_type"], "PV")
            self.assertEqual(curve.spec["metadata"]["treatment"], "bottom_uv")
            self.assertEqual(curve.data.x.tolist(), [-2, 0, 2, 0, -2])
            self.assertIn("10kHz", result["output_stem"])
            self.assertTrue((Path(result["run_dir"]) / "appearance.json").is_file())
            self.assertEqual(len(app.get("plotly_chart")), 1)
            origin.assert_not_called()

    def test_followup_switches_combined_to_separate_and_back_with_legends(self):
        upload = io.BytesIO(example_excel())
        upload.name = "sample_3V_10kHz.xlsx"
        def answer(curves, plan, request, *args):
            separate = "따로" in request
            return {"plot_mode": "separate" if separate else "combined", "group_by": [],
                    "legend_format": "" if separate else "{stem}",
                    "labels": [{"curve_id": curves[0].curve_id, "label": "Baseline"}] if separate else [], "notes": []}
        with tempfile.TemporaryDirectory() as directory, patch("streamlit.file_uploader", return_value=[upload]), patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("lab_core.ai_plot_options", side_effect=answer) as model_call:
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(directory).run()
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            self.assertEqual(len(app.get("plotly_chart")), 2)  # one I-V, one P-V
            original = [c.data.copy() for c in app.session_state["result"]["curves"]]
            next(t for t in app.text_input if t.label == "합치기 · 따로 그리기 · 범례 변경 요청").set_value("각각 따로, 첫 범례는 Baseline").run()
            next(b for b in app.button if b.label == "보기 요청 적용").click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            self.assertEqual(len(app.get("plotly_chart")), 4)
            self.assertEqual(app.session_state["result"]["curves"][0].spec["label"], "Baseline")
            next(t for t in app.text_input if t.label == "합치기 · 따로 그리기 · 범례 변경 요청").set_value("전부 한 그래프에 합쳐줘. 범례는 파일명").run()
            next(b for b in app.button if b.label == "보기 요청 적용").click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            self.assertEqual(len(app.get("plotly_chart")), 2)
            result = app.session_state["result"]
            for before, curve in zip(original, result["curves"]):
                self.assertTrue(before.equals(curve.data))
                self.assertEqual(curve.spec["label"], "sample_3V_10kHz")
            self.assertEqual(model_call.call_count, 2)

    def test_model_catalog_selection_and_manual_entry(self):
        api = MagicMock()
        api.__enter__.return_value = api
        api.models.list.return_value = [SimpleNamespace(id=name) for name in
            ("gpt-test-model", "gpt-4.1-mini", "gpt-test-audio", "text-embedding-test")]
        with patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("openai.OpenAI", return_value=api):
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            selector = next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델")
            self.assertEqual(selector.value, "gpt-4.1-mini")
            next(b for b in app.button if b.label == "API 모델 목록 불러오기").click().run(timeout=30)
            selector = next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델")
            self.assertIn("gpt-test-model", selector.options)
            self.assertNotIn("gpt-test-audio", selector.options)
            selector.select("gpt-test-model").run()
            self.assertEqual(next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").value, "gpt-test-model")
            next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").select("직접 입력…").run()
            next(t for t in app.sidebar.text_input if t.label == "모델 ID 직접 입력").set_value("gpt-my-custom-model").run()
            self.assertFalse(app.exception)
            self.assertEqual(api.models.list.call_count, 1)

    def test_saved_custom_model_and_catalog_failure_preserve_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            original = Path(__file__).with_name("agent_origin2020_openai.py")
            app_path = root / original.name
            app_path.write_text(original.read_text().replace("USE_SAVED_SETTINGS = False", "USE_SAVED_SETTINGS = True"), encoding="utf-8")
            (root / "local_settings.json").write_text(json.dumps({"model": "gpt-saved-custom-model"}), encoding="utf-8")
            with patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("openai.OpenAI", side_effect=RuntimeError("simulated offline")):
                app = AppTest.from_file(str(app_path)).run(timeout=30)
                self.assertEqual(next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").value, "gpt-saved-custom-model")
                next(b for b in app.button if b.label == "API 모델 목록 불러오기").click().run(timeout=30)
                self.assertFalse(app.exception)
                self.assertEqual(next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").value, "gpt-saved-custom-model")
                self.assertTrue(any("목록 조회 실패" in w.value for w in app.warning))

    def test_code_defaults_override_saved_model_in_code_mode(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = Path(__file__).with_name("agent_origin2020_openai.py")
            app_path = root / source.name
            app_path.write_bytes(source.read_bytes())
            (root / "local_settings.json").write_text(json.dumps({"model": "gpt-previous-saved"}), encoding="utf-8")
            app = AppTest.from_file(str(app_path)).run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").value, "gpt-4.1-mini")
            self.assertTrue(next(b for b in app.button if b.label == "경로·모델·선 두께 기본값 저장").disabled)

    def test_upload_extract_export_db_and_idempotent_resave(self):
        upload = io.BytesIO(example_excel())
        upload.name = "sample_3V_10kHz.xlsx"
        with tempfile.TemporaryDirectory() as directory, patch("streamlit.file_uploader", return_value=[upload]):
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(directory).run()
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            db = Path(directory, "experiments.sqlite3")
            self.assertTrue(db.is_file())
            self.assertEqual(len(list(Path(directory).glob("runs/*/cleaned.xlsx"))), 1)
            next(b for b in app.button if b.label == "이 결과를 DB에 저장 / 재확인").click().run(timeout=30)
            self.assertFalse(app.exception)
            with sqlite3.connect(db) as con:
                self.assertEqual(con.execute("SELECT COUNT(*) FROM curves").fetchone()[0], 4)
                self.assertEqual(con.execute("SELECT COUNT(*) FROM runs").fetchone()[0], 1)
                self.assertEqual(con.execute("SELECT COUNT(*) FROM points").fetchone()[0], 18)


if __name__ == "__main__":
    unittest.main(verbosity=2)
