"""Update an existing app while preserving its API key, defaults and data."""
import ast
import sys
import uuid
from datetime import datetime
from pathlib import Path

FILES = ("agent_origin2020_openai.py", "lab_core.py", "origin_adapter.py", "plot_rules.py", "lab_features.py", "chat_agent.py", "curve_integrity.py", "v4_selection.py", "analysis_core.py", "db_compare.py", "comparison_agent.py")
PRESERVE = {"OPENAI_API_KEY", "DEFAULT_MODEL", "DEFAULT_WORKSPACE", "DEFAULT_TEMPLATE", "DEFAULT_TEMPLATE_PV", "DEFAULT_TEMPLATE_IV", "USE_SAVED_SETTINGS"}


def preserve_config(new_text, old_text):
    old = {}
    for node in ast.parse(old_text).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in PRESERVE:
                    old[target.id] = ast.get_source_segment(old_text, node.value)
    if "OPENAI_API_KEY" not in old or "from lab_core import" not in old_text:
        raise ValueError("Choose the existing OpenAI app, not the original Gemini program.")
    lines = new_text.splitlines(keepends=True)
    replacements = []
    for node in ast.parse(new_text).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in old:
                replacements.append((node.lineno - 1, node.end_lineno, name + " = " + old[name] + "\n"))
    for start, end, value in reversed(replacements):
        lines[start:end] = [value]
    result = "".join(lines)
    ast.parse(result)
    return result


def update_existing(target_app, source_dir):
    target_app, source_dir = Path(target_app).resolve(), Path(source_dir).resolve()
    root = target_app.parent
    if root == source_dir:
        raise ValueError("Choose the OLD installation, not the downloaded update folder.")
    new = {}
    for name in FILES:
        text = (source_dir / name).read_text(encoding="utf-8-sig")
        ast.parse(text)
        new[name] = text.encode("utf-8")
    new[FILES[0]] = preserve_config(new[FILES[0]].decode(), target_app.read_text(encoding="utf-8-sig")).encode("utf-8")
    destinations = {name: (target_app if name == FILES[0] else root / name) for name in FILES}
    old = {name: path.read_bytes() if path.exists() else None for name, path in destinations.items()}
    backup = root / ("update_backup_" + datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6])
    backup.mkdir()
    for name, data in old.items():
        if data is not None:
            (backup / destinations[name].name).write_bytes(data)
    try:
        for name, path in destinations.items():
            temporary = path.with_name(path.name + ".update-" + uuid.uuid4().hex)
            temporary.write_bytes(new[name])
            temporary.replace(path)
    except Exception:
        for name, path in destinations.items():
            if old[name] is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(old[name])
        raise
    return backup


def main():
    here = Path(__file__).resolve().parent
    source = here / "update_payload" if (here / "update_payload").is_dir() else here
    if len(sys.argv) > 1:
        target = sys.argv[1]
    else:
        from tkinter import Tk, filedialog
        dialog = Tk()
        dialog.withdraw()
        target = filedialog.askopenfilename(title="기존 agent_origin2020_openai.py 파일을 선택하세요", filetypes=[("Python app", "*.py")])
        dialog.destroy()
    if not target:
        print("Cancelled. No files were changed.")
        return
    backup = update_existing(target, source)
    print("Update completed. API key, defaults, .venv and lab data were preserved.")
    print("Backup:", backup)
    print("Start the existing app with its 02_start.bat.")


if __name__ == "__main__":
    main()
