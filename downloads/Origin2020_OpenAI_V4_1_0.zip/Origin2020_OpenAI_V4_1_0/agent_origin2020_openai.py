"""Run with: streamlit run agent_origin2020_openai.py"""
from __future__ import annotations

import json
import copy
import os
import sqlite3
import uuid
from collections import defaultdict
from contextlib import closing
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from lab_core import (
    META_FIELDS, NUMBER_FIELDS, GROUP_FIELDS, ai_interpret, ai_plan, curve_color,
    default_plan, digest, export_excel, group_key, load_tables, materialize,
    numeric_blocks, points_frame, query_curves, save_run, stable_json, summary_frame,
    prepare_plan, ai_plot_options, apply_plot_options,
)
from origin_adapter import plot_origin
from chat_agent import chat_turn, curve_context
from lab_features import (COLOR_DEFAULTS, colors_for_curves, output_stem, load_library,
                          save_library, add_template, template_routes)
from curve_integrity import source_point_audit
from v4_selection import (APP_VERSION, constrain_plan, layouts, load_profiles,
                          save_profiles, profile_mappings)
from plot_rules import request_options, axis_info, matching_voltage_column
from analysis_core import analysis_evidence, analysis_intent, numeric_markdown, interpretation_payload
from db_compare import (METRICS as COMPARISON_METRICS, DEFAULT_SETTINGS as COMPARISON_DEFAULTS,
    catalog as comparison_catalog, filter_catalog, compare_database, save_comparison,
    comparison_markdown, comparison_excel, comparison_intent, comparison_history,
    load_comparison, update_comparison_report)
from comparison_agent import comparison_plan, explain_comparison


if __name__ == "__main__" and not st.runtime.exists():
    import sys
    from streamlit.web import cli as stcli
    sys.argv = ["streamlit", "run", __file__]
    raise SystemExit(stcli.main())


# ================= 사용자 설정 =================
# 새 OpenAI API 키를 이 따옴표 안에 넣으세요. 이전 Gemini 키는 사용하지 않습니다.
OPENAI_API_KEY = "여기에_새_OpenAI_API_키_입력"
DEFAULT_MODEL = "gpt-4.1-mini"  # Responses API + Structured Outputs 지원 모델
DEFAULT_WORKSPACE = Path(__file__).resolve().parent / "lab_workspace"
DEFAULT_TEMPLATE = ""  # 예: r"C:\Users\이지호\Desktop\Graph Template\P-V Curve.otpu"
DEFAULT_TEMPLATE_PV = r"C:\Users\이지호\Desktop\UNIST\실험\Python\Graph Template\P-V Curve.otpu"
DEFAULT_TEMPLATE_IV = r"C:\Users\이지호\Desktop\UNIST\실험\Python\Graph Template\I-V Curve.otpu"
USE_SAVED_SETTINGS = False  # False: 상단 코드값 우선 / True: 저장된 UI 기본값 사용
ORIGIN_PROG_ID = "Origin.Application"  # V4: 새 Origin 인스턴스에 이번 요청만 출력
# ================================================
SETTINGS_FILE = Path(__file__).resolve().parent / "local_settings.json"


def load_settings() -> dict:
    try:
        value = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def get_key() -> str:
    key = os.environ.get("OPENAI_API_KEY", "").strip() or OPENAI_API_KEY.strip()
    if not key or key.startswith("여기에_"):
        raise ValueError("코드 상단 OPENAI_API_KEY에 새 키를 입력하거나 환경변수를 설정하세요.")
    return key


def clear_results():
    for key in ("result", "interpretation", "origin_result"):
        st.session_state.pop(key, None)


def set_plan(plan: dict):
    st.session_state.plan = plan
    st.session_state.plan_revision = st.session_state.get("plan_revision", 0) + 1
    clear_results()


def plan_editor(plan: dict) -> dict:
    revision = st.session_state.plan_revision
    with st.expander("고급: 전체 계획 JSON 확인", expanded=False):
        st.code(json.dumps(plan, ensure_ascii=False, indent=2), language="json")
    plot_modes = {"combined": "한 그래프에 겹치기", "separate": "곡선마다 따로", "grouped": "측정 조건별로 묶기"}
    mode = st.selectbox("그래프 구성", list(plot_modes),
        index=list(plot_modes).index(plan.get("plot_mode", "combined")),
        format_func=plot_modes.get, key=f"plot_mode_{revision}")
    measurements = {"PV": "P–V: X=전압, Y=분극", "IV": "I–V: X=전압, Y=전류", "auto": "PV와 IV 모두 (명시적 선택)", "manual": "열 지정 그대로"}
    measurement = st.selectbox("측정 그래프", list(measurements),
        index=list(measurements).index(plan.get("measurement", "auto")),
        format_func=measurements.get, key=f"measurement_{revision}")
    if measurement == "manual":
        st.caption("열 지정 그대로 모드는 자동 축 교정과 반전 채널 선택 검사를 생략합니다.")
    legend_presets = {"곡선별 직접 입력": "", "파일명 + 시트명": "{stem} · {sheet}", "시트명만": "{sheet}",
                      "인가전압": "{voltage_v:g} V", "온도": "{temperature_c:g} °C", "처리 조건 + 전압": "{treatment} · {voltage_v:g} V"}
    current_format = plan.get("legend_format", "")
    default_legend = next((key for key, value in legend_presets.items() if value == current_format), "사용자 정의 형식")
    legend_choice = st.selectbox("범례 작성 방식", list(legend_presets) + ["사용자 정의 형식"],
        index=(list(legend_presets) + ["사용자 정의 형식"]).index(default_legend), key=f"legend_choice_{revision}")
    legend_format = (st.text_input("범례 형식", value=current_format or "{stem} · {voltage_v:g} V", key=f"legend_format_{revision}")
                     if legend_choice == "사용자 정의 형식" else legend_presets[legend_choice])
    if legend_format:
        st.caption("선택한 형식으로 범례를 만듭니다. {stem}, {sheet}, {voltage_v:g}, {frequency_hz:g}, {temperature_c:g}, {split_condition}, {device_id}를 사용할 수 있습니다.")
    rows = []
    for spec in plan["curves"]:
        rows.append({"선택": True, **{k: v for k, v in spec.items() if k != "metadata"}, **spec["metadata"]})
    if not rows:
        st.warning("인식된 곡선이 없습니다. 요청을 구체화하거나 아래 JSON 계획을 직접 입력하세요.")
    else:
        st.caption("행 번호는 원본 기준 1부터 시작하며 끝 행을 포함합니다. 공통 X를 사용하는 여러 Y는 행을 추가해 지정할 수 있습니다. 중복·불필요 곡선은 행을 삭제하세요.")
        edited = st.data_editor(
            pd.DataFrame(rows), key=f"curve_editor_{revision}", hide_index=True,
            num_rows="dynamic", width="stretch",
            disabled=["label"] if legend_format else [],
            column_config={
                "선택": st.column_config.CheckboxColumn("이번 요청에 포함", default=True),
                "label": st.column_config.TextColumn("범례 (직접 입력)"),
                "source_id": st.column_config.TextColumn("원본 ID"),
                "start_row": st.column_config.NumberColumn("시작 행 (1-based)", min_value=1, step=1),
                "end_row": st.column_config.NumberColumn("끝 행 (포함)", min_value=1, step=1),
                "voltage_v": st.column_config.NumberColumn("인가전압 조건 (V)"),
                "frequency_hz": st.column_config.NumberColumn("주파수 (Hz)"),
                "temperature_c": st.column_config.NumberColumn("온도 (°C)"),
            },
        )
        new_specs = []
        for row in edited.to_dict(orient="records"):
            if not row.pop("선택", True):
                continue
            cleaned = {key: None if pd.isna(value) else value for key, value in row.items()}
            metadata = {key: cleaned.pop(key) for key in META_FIELDS}
            for key in ("start_row", "end_row"):
                value = cleaned[key]
                if value is not None and float(value).is_integer():
                    cleaned[key] = int(value)
            for key in ("x_unit", "y_unit"):
                if cleaned[key] is None:
                    cleaned[key] = ""
            for key in META_FIELDS:
                if key not in NUMBER_FIELDS and metadata[key] is not None:
                    metadata[key] = str(metadata[key])
            cleaned["metadata"] = metadata
            new_specs.append(cleaned)
        plan = dict(plan, curves=new_specs)
    group = st.multiselect("그래프를 나눌 측정 조건", GROUP_FIELDS, default=plan["group_by"],
                          disabled=mode != "grouped", key=f"groups_{revision}")
    color = st.selectbox("색상을 구분할 조건", GROUP_FIELDS, index=GROUP_FIELDS.index(plan["color_by"]), key=f"color_{revision}")
    use_target = st.checkbox("특정 X 값에서 Y 비교 (모든 스윕 교차점 유지)", value=plan["compare_at_x"] is not None, key=f"target_on_{revision}")
    target = st.number_input("비교할 X 값 — 원본 X 단위", value=float(plan["compare_at_x"] or 0), key=f"target_{revision}") if use_target else None
    st.caption("한 그래프 모드는 조건이 비어 있거나 달라도 모든 호환 곡선을 겹칩니다. P와 I, 서로 다른 단위는 별도 그래프로 표시합니다. 원본 순서·스윕 분지는 유지합니다.")
    return dict(plan, group_by=group, color_by=color, compare_at_x=target,
                plot_mode=mode, measurement=measurement, legend_format=legend_format)


def preview(curves, plan):
    color_map, _ = colors_for_curves(curves, plan, group_key)
    if plan.get("color_settings", {}).get("mode") == "origin":
        st.caption("Origin 전용 팔레트는 실제 Origin에서 적용합니다. 웹에서는 곡선 위치를 회색으로 미리 표시합니다.")
    grouped = defaultdict(list)
    for curve in curves:
        grouped[group_key(curve, plan)].append(curve)
    st.caption(f"총 {len(grouped)}개 그래프 그룹. 화면에는 처음 20개를 표시하며, 내보내기에는 전체를 포함합니다.")
    for key, members in list(grouped.items())[:20]:
        info = json.loads(key)
        title = (members[0].spec["label"] if plan.get("plot_mode") == "separate" else
                 ", ".join(f"{k}={v}" for k, v in info["conditions"].items()) or "전체 곡선 겹치기")
        spec = members[0].spec
        figure = go.Figure()
        for curve in members:
            indexed = curve.data.set_index("source_row")[["x", "y"]]
            full = indexed.reindex(range(int(indexed.index.min()), int(indexed.index.max()) + 1))
            # No sorting or downsampling; gaps remain visible.
            figure.add_trace(go.Scattergl(
                x=full.x, y=full.y, mode="lines", name=curve.spec["label"],
                line={"color": color_map[curve.curve_id] if plan.get("color_settings", {}).get("mode") != "condition" else curve_color(curve, plan), "width": 2}, connectgaps=False,
            ))
        figure.update_layout(title=title,
            xaxis_title=f"{spec['x_name']} [{spec['x_unit'] or '단위 미확인'}]",
            yaxis_title=f"{spec['y_name']} [{spec['y_unit'] or '단위 미확인'}]")
        st.plotly_chart(figure, width="stretch")


def csv_bytes(frame):
    safe = frame.map(lambda v: "'" + v if isinstance(v, str) and v.startswith(("=", "+", "-", "@")) else v)
    return safe.to_csv(index=False).encode("utf-8-sig")


def configure_plan(plan):
    plan = copy.deepcopy(plan)
    plan["color_settings"] = dict(color_settings)
    if color_field != "request":
        plan["color_by"] = color_field
    plan["filename_format"] = filename_format
    plan["template_routes"] = template_routes(library)
    return plan


def selection_for(request, tables):
    existing = st.session_state.get("result")
    fallback = existing["plan"].get("measurement", measurement_choice) if existing else measurement_choice
    return {"request": request, "measurement": fallback, "channel_mode": channel_mode,
            "mappings": profile_mappings(tables, column_profiles)}


def save_analysis_values(result):
    summaries, records = analysis_evidence(result["curves"])
    folder = Path(result["run_dir"])
    (folder / "analysis_values.csv").write_bytes(csv_bytes(records))
    (folder / "analysis_summary.json").write_text(interpretation_payload(summaries), encoding="utf-8")
    return summaries, records


def analyze_result(result, request, model):
    summaries, _ = save_analysis_values(result)
    try:
        interpretation = ai_interpret(result["curves"], request, get_key(), model)
    except Exception as exc:
        interpretation = numeric_markdown(summaries) + "\n\n수치 계산은 완료했지만 AI 해석에 실패했습니다: " + str(exc)
    (Path(result["run_dir"]) / "analysis.md").write_text(interpretation, encoding="utf-8")
    return interpretation


@st.cache_data(show_spinner=False)
def cached_comparison_catalog(path, signature):
    return comparison_catalog(Path(path))


def comparison_catalog_for(path):
    files = [Path(path), Path(str(path) + "-wal")]
    signature = tuple((p.stat().st_mtime_ns, p.stat().st_size) if p.exists() else None for p in files)
    return cached_comparison_catalog(str(Path(path).resolve()), signature)


def execute_comparison(request, target_source, target_filters, reference_filters, settings,
                       explain=False, save_to_db=True, target_ids=None):
    current = st.session_state.get("result")
    compared = compare_database(db_path, current["curves"] if current else [], target_filters,
        reference_filters, settings, target_source=target_source, target_ids=target_ids)
    compared.update(request=request, db_path=str(db_path.resolve()))
    try:
        save_comparison(db_path, workspace, request, compared, save_to_db=save_to_db)
    except Exception as exc:
        compared["save_error"] = "비교 수치는 계산했지만 결과 저장에 실패했습니다: " + str(exc)
    report = comparison_markdown(compared)
    if explain and not compared["rows"].empty:
        try:
            report = explain_comparison(compared, request, get_key(), model)
        except Exception as exc:
            report += "\n\n수치 보고서는 유지되며 AI 비교 해석에 실패했습니다: " + str(exc)
    compared["report"] = report
    if compared.get("db_saved"):
        try:
            update_comparison_report(db_path, compared["comparison_id"], report)
        except Exception as exc:
            compared["save_error"] = "수치 기록은 저장했지만 해석 기록 갱신에 실패했습니다: " + str(exc)
    if compared.get("folder"):
        try:
            (Path(compared["folder"]) / "report.md").write_text(report, encoding="utf-8")
        except OSError as exc:
            compared["save_error"] = str(exc)
    st.session_state.comparison_result = compared
    return compared


def render_comparison(compared, key_prefix):
    st.caption(f"마지막 비교 결과 · 대상 후보 {compared['target_count']}개 · 기준 후보 {compared['reference_count']}개 · DB: {compared['db_path']}")
    if compared.get("save_error"):
        st.warning(compared["save_error"])
    if compared.get("historical_snapshot"):
        st.info("저장된 시점의 비교 보고서입니다. 현재 DB 데이터로 다시 계산한 결과와 구분해 보세요.")
    st.markdown(compared["report"])
    frame = compared["rows"]
    if not frame.empty:
        for (metric, unit), group in frame.groupby(["metric", "unit"], sort=False):
            shown = group.head(40)
            labels = [f"{r.target_label[:45]} · {r.reference_group}" for r in shown.itertuples()]
            fig = go.Figure()
            for role, text in (("target", "대상 값 · 하한~상한"), ("reference", "기준 값 · 하한~상한")):
                lo, hi = shown[role + "_min"].tolist(), shown[role + "_max"].tolist()
                fig.add_trace(go.Scatter(y=list(range(len(shown))), x=lo, customdata=labels,
                    error_x={"type": "data", "symmetric": False, "array": [b-a for a, b in zip(lo, hi)], "arrayminus": [0]*len(lo)},
                    mode="markers", name=text, hovertemplate="%{customdata}<br>하한=%{x}<extra>%{fullData.name}</extra>"))
            fig.update_layout(title=COMPARISON_METRICS[metric], xaxis_title=unit,
                height=max(350, min(1000, len(shown)*30+180)),
                yaxis={"tickmode": "array", "tickvals": list(range(len(shown))),
                    "ticktext": [f"{r.voltage_v} V · {r.target_label[:25]}" for r in shown.itertuples()], "title": "조건을 맞춘 비교쌍"})
            st.plotly_chart(fig, width="stretch", key=f"{key_prefix}_{metric}_{unit}")
            if len(group) > 40:
                st.caption(f"그래프에는 {len(group)}개 비교 중 40개를 표시하며 전체는 Excel/CSV에 보관합니다.")
    st.download_button("비교 결과 Excel 받기", comparison_excel(compared), "comparison.xlsx", key=key_prefix + "_excel")
    st.download_button("비교 수치 CSV 받기", csv_bytes(frame), "comparison.csv", key=key_prefix + "_csv")
    with st.expander("비교 기준 · 단위 변환 · 제외 사유 · 원본 근거"):
        st.json(compared["settings"])
        st.dataframe(compared["excluded"], hide_index=True, width="stretch")
        st.dataframe(compared["features"], hide_index=True, width="stretch")
        st.download_button("계산 근거 CSV 받기", csv_bytes(compared["features"]), "comparison_features.csv", key=key_prefix + "_features")


def store_result(plan, tables, workspace, db_path, request, intent_request=None, preserve_channels=False):
    plan = configure_plan(plan)
    plan = constrain_plan(plan, tables, request if intent_request is None else intent_request,
        measurement=plan.get("measurement", measurement_choice), channel_mode="all" if preserve_channels else channel_mode,
        mappings=profile_mappings(tables, column_profiles))
    plan = prepare_plan(plan, tables)
    curves = materialize(plan, tables)
    audited = source_point_audit(curves)
    run_id = uuid.uuid4().hex
    stem = output_stem(curves, plan.get("filename_format", ""))
    run_dir = workspace / "runs" / (stem + "_" + run_id[:8])
    run_dir.mkdir(parents=True, exist_ok=False)
    (run_dir / "plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "cleaned.xlsx").write_bytes(export_excel(curves))
    (run_dir / "summary.csv").write_bytes(csv_bytes(summary_frame(curves)))
    (run_dir / "points.csv").write_bytes(csv_bytes(points_frame(curves)))
    (run_dir / "source_point_audit.csv").write_bytes(csv_bytes(audited))
    colors, positions = colors_for_curves(curves, plan, group_key)
    native = plan.get("color_settings", {}).get("mode") == "origin"
    appearance = [{"curve_id": c.curve_id, "label": c.spec["label"], "state_position": positions[c.curve_id],
                   "rgb": None if native else colors[c.curve_id], "group": json.loads(group_key(c, plan))} for c in curves]
    (run_dir / "appearance.json").write_text(json.dumps(appearance, ensure_ascii=False, indent=2), encoding="utf-8")
    (run_dir / "execution_manifest.json").write_text(json.dumps({"version": APP_VERSION,
        "intent_request": request if intent_request is None else intent_request,
        "measurement": plan["measurement"], "curve_count": len(curves),
        "graph_count": len({group_key(c, plan) for c in curves}),
        "source_columns": [{"file": c.source.filename, "sheet": c.source.sheet,
            "x": c.spec["x_column"], "y": c.spec["y_column"], "label": c.spec["label"]} for c in curves]},
        ensure_ascii=False, indent=2), encoding="utf-8")
    return {"run_id": run_id, "run_dir": str(run_dir.resolve()), "db_path": str(db_path.resolve()),
            "request": request, "plan": plan, "curves": curves, "db_saved": False, "output_stem": stem}


st.set_page_config(page_title="Lab 데이터 분석 · DB 비교 V4.1", layout="wide")
st.title("측정 데이터 분석 · DB 비교 에이전트 V4")
st.caption(f"v{APP_VERSION} · 측정 특성 분석 · DB 기준군과 조건별 비교 · 원본 검증 · Origin 플롯")
st.caption("새 측정 파일을 추가하거나, DB 비교 분석 탭에서 저장된 데이터끼리 비교할 수 있습니다.")
if st.session_state.get("app_version") != APP_VERSION:
    if st.session_state.get("app_version") in ("4.0.1", "4.0.2"):
        # Compatible live update: keep the points already plotted for analysis.
        st.session_state.pop("interpretation", None)
    else:
        for state_key in ("plan", "result", "origin_result", "interpretation"):
            st.session_state.pop(state_key, None)
    st.session_state.app_version = APP_VERSION

settings = load_settings() if USE_SAVED_SETTINGS else {}
# Reset the model widget when code-level defaults change during a Streamlit rerun.
defaults_id = (DEFAULT_MODEL, str(DEFAULT_WORKSPACE), DEFAULT_TEMPLATE, USE_SAVED_SETTINGS)
if st.session_state.get("code_defaults_id") != defaults_id:
    st.session_state.pop("openai_model_choice", None)
    st.session_state.pop("openai_manual_model", None)
    st.session_state["code_defaults_id"] = defaults_id
with st.sidebar:
    st.header("설정")
    workspace = Path(st.text_input("데이터 보관 폴더", settings.get("workspace", str(DEFAULT_WORKSPACE)))).expanduser()
    measurement_labels = {"PV": "PV — Polarization만", "IV": "IV — Current만", "auto": "PV + IV 모두"}
    measurement_choice = st.selectbox("요청에 종류가 없을 때", list(measurement_labels), format_func=measurement_labels.get)
    st.caption("‘PV만’, ‘IV만’ 같은 대화 요청이 위 기본값보다 우선합니다.")
    channel_mode = st.selectbox("반복 측정 채널 기본값", ["first", "all"],
        format_func=lambda v: "파일마다 첫 측정 채널 1개" if v == "first" else "파일마다 모든 반복 채널")
    st.caption("전압별 파일은 모두 유지합니다. P2, 마지막 사이클, 모든 사이클 등 요청하면 해당 선택을 우선합니다.")
    # MODEL_SELECTOR_START
    saved_model = str(settings.get("model", DEFAULT_MODEL)).strip() or DEFAULT_MODEL
    if st.button("API 모델 목록 불러오기"):
        try:
            from openai import OpenAI
            with OpenAI(api_key=get_key(), timeout=20, max_retries=1) as api:
                catalog = [item.id for item in api.models.list()]
            # Exclude obvious image/audio/embedding models. Listing a model does
            # not prove Responses API or Structured Outputs compatibility.
            excluded = ("audio", "realtime", "transcrib", "tts", "image", "search", "instruct")
            candidates = sorted({name for name in catalog
                if name.startswith(("gpt-", "o1", "o3", "o4"))
                and not any(word in name.lower() for word in excluded)})
            if not candidates:
                raise ValueError("계정에서 텍스트 분석 모델을 찾지 못했습니다.")
            st.session_state["api_model_ids"] = candidates
            st.success(f"API 모델 {len(candidates)}개를 불러왔습니다.")
        except Exception as exc:
            st.warning(f"목록 조회 실패: {exc}. 기본 후보나 직접 입력을 사용할 수 있습니다.")
    choices = list(dict.fromkeys([
        saved_model, DEFAULT_MODEL, "gpt-4.1-nano", "gpt-4.1",
        *st.session_state.get("api_model_ids", []),
    ]))
    manual_option = "직접 입력…"
    selected_model = st.selectbox(
        "OpenAI 모델", choices + [manual_option], key="openai_model_choice",
        help="실제 OpenAI API 모델 ID를 선택하세요. Codex 표시명은 API ID와 다를 수 있습니다.",
    )
    model = (st.text_input("모델 ID 직접 입력", value=saved_model,
             key="openai_manual_model") if selected_model == manual_option else selected_model).strip()
    if not model:
        st.warning("사용할 모델 ID를 입력하세요.")
    st.caption("기본 후보의 계정 접근 권한은 다를 수 있습니다. API 목록에 표시돼도 이 앱의 분석 형식 지원 여부는 모델마다 다릅니다.")
    # MODEL_SELECTOR_END
    template = st.text_input("Origin 2020 템플릿 경로 (.otpu, 선택)", settings.get("template", DEFAULT_TEMPLATE))
    line_width = st.number_input("Origin 선 두께", min_value=.1, max_value=10., value=float(settings.get("line_width", 3.)), step=.1)
    auto_db = st.checkbox("데이터 정리 시 SQLite에도 자동 저장", value=settings.get("auto_db", True))
    with st.expander("멀티스테이트 색상 · 결과 이름", expanded=True):
        color_modes = {"rainbow": "1. 무지개", "colormap": "2. 공통 컬러맵", "origin": "2. Origin 전용 팔레트", "custom": "3. 시작색 → 끝색", "condition": "조건별 고정색"}
        color_mode = st.selectbox("컬러 모드", list(color_modes), format_func=color_modes.get)
        color_settings = dict(COLOR_DEFAULTS, mode=color_mode)
        if color_mode == "colormap":
            color_settings["colormap"] = st.selectbox("컬러맵", ["Viridis", "Plasma", "Cividis", "Turbo", "Jet", "Blues", "RdBu", "Rainbow"])
        if color_mode == "origin":
            color_settings["origin_palette"] = st.text_input("Origin 팔레트 이름/경로", "Maple.pal")
            st.caption("설치된 Origin의 .pal/.xml을 사용합니다. 웹 색상 미리보기는 회색입니다.")
        if color_mode == "custom":
            color_settings["start"] = st.color_picker("시작 색", COLOR_DEFAULTS["start"])
            color_settings["end"] = st.color_picker("끝 색", COLOR_DEFAULTS["end"])
        color_settings["reverse"] = st.checkbox("색상 순서 뒤집기")
        color_settings["scope"] = "global" if st.checkbox("그래프 간 동일 상태값은 동일 색", value=True) else "graph"
        color_field = st.selectbox("색상을 나눌 상태값", ["request", *GROUP_FIELDS], format_func=lambda value: "요청에 따라 (기본: 인가전압)" if value == "request" else value)
        st.caption("선택된 서로 다른 상태 N개를 수치 순서로 정렬해 색상 범위를 N등분합니다. X축 데이터는 정렬하지 않습니다.")
        filename_format = st.text_input("결과 파일명 형식 (선택)", "", placeholder="{measurement}_{device}_{frequency}_{voltage}")
    library_path = workspace / "template_library.json"
    try:
        seeds = {kind: path for kind, path in {"PV": DEFAULT_TEMPLATE_PV, "IV": DEFAULT_TEMPLATE_IV}.items() if path and Path(path).is_file()}
        library = load_library(library_path, seeds)
    except Exception as exc:
        st.error(f"템플릿 라이브러리 읽기 실패: {exc}")
        library = {"templates": [], "defaults": {}}
    with st.expander("IV/PV 템플릿 라이브러리"):
        st.caption("종류별 기본 템플릿을 한 번 등록하면 다음 실행에도 사용합니다. 미등록 종류는 위 공통 경로 또는 Origin 기본 그래프를 사용합니다.")
        for kind in ("PV", "IV", "other"):
            names = [item["name"] for item in library["templates"] if item["kind"] == kind]
            options = ["Origin 기본 / 공통 경로", *names]
            selected = st.selectbox(f"{kind} 기본 템플릿", options, index=options.index(library["defaults"].get(kind)) if library["defaults"].get(kind) in options else 0)
            if selected in names:
                library["defaults"][kind] = selected
            else:
                library["defaults"].pop(kind, None)
        if st.button("종류별 기본 템플릿 저장"):
            try:
                save_library(library_path, library)
                st.success("템플릿 기본값을 저장했습니다.")
            except Exception as exc:
                st.error(str(exc))
        with st.form("add_template", clear_on_submit=True):
            new_template_name = st.text_input("추가할 템플릿 이름")
            new_template_kind = st.selectbox("사용할 그래프 종류", ["PV", "IV", "other"])
            new_template_path = st.text_input("기존 .otpu/.otp 경로")
            new_template_file = st.file_uploader("또는 템플릿 파일 업로드", type=["otpu", "otp"])
            make_default = st.checkbox("추가 후 해당 종류 기본값으로 사용", value=True)
            if st.form_submit_button("템플릿 추가"):
                try:
                    if new_template_file:
                        folder = workspace / "templates"
                        folder.mkdir(parents=True, exist_ok=True)
                        saved_template = folder / (digest(new_template_file.getvalue()) + Path(new_template_file.name).suffix.lower())
                        saved_template.write_bytes(new_template_file.getvalue())
                        new_template_path = str(saved_template)
                    add_template(library, new_template_name, new_template_kind, new_template_path, make_default)
                    save_library(library_path, library)
                except Exception as exc:
                    st.error(f"템플릿 추가 실패: {exc}")
                else:
                    st.rerun()
    if not USE_SAVED_SETTINGS:
        st.caption("코드 상단 기본값을 사용 중입니다. UI 기본값을 저장·복원하려면 USE_SAVED_SETTINGS를 True로 바꾸세요.")
    if st.button("경로·모델·선 두께 기본값 저장", disabled=not USE_SAVED_SETTINGS):
        try:
            if not model:
                raise ValueError("모델 ID를 입력한 뒤 저장하세요.")
            SETTINGS_FILE.write_text(json.dumps({"workspace": str(workspace), "model": model,
                "template": template, "line_width": line_width, "auto_db": auto_db}, ensure_ascii=False, indent=2), encoding="utf-8")
            st.success("다음 실행에도 사용할 기본값을 저장했습니다. API 키는 저장하지 않습니다.")
        except (OSError, ValueError) as exc:
            st.error(f"기본값 저장 실패: {exc}")
    st.caption("API 키는 코드 상단 또는 OPENAI_API_KEY 환경변수에 입력합니다. OpenAI API 사용료는 ChatGPT 구독과 별개입니다.")
    st.info("AI 구조 분석에는 파일명·원본 일부·수치 범위가, AI 해석에는 계산된 요약이 전송됩니다. DB 비교 요청에는 조건 목록과 계산된 비교값을 OpenAI로 보냅니다. 원본 측정점과 SQLite는 이 PC에 저장됩니다.")

db_path = workspace / "experiments.sqlite3"
uploads = st.file_uploader("측정 파일 여러 개 업로드", type=["xlsx", "xls", "csv", "txt", "dat", "tsv"], accept_multiple_files=True, key="measurement_uploads")
all_tables = None
if uploads:
    signature = digest(stable_json([str(workspace.resolve())] + [(f.name, digest(f.getvalue())) for f in uploads]).encode())
    if st.session_state.get("upload_signature") != signature:
        try:
            st.session_state.tables = load_tables([(f.name, f.getvalue()) for f in uploads], workspace / "raw")
            st.session_state.upload_signature = signature
            st.session_state.pop("plan", None)
            clear_results()
        except Exception as exc:
            st.session_state.pop("tables", None)
            st.error(f"파일 읽기 실패: {exc}")
    all_tables = st.session_state.get("tables")
tables = None
if all_tables:
    by_id = {table.source_id: table for table in all_tables}
    scoped = st.multiselect("이번 요청에 사용할 파일 · 시트", list(by_id), default=list(by_id),
        format_func=lambda sid: f"{by_id[sid].filename} / {by_id[sid].sheet}", key="source_scope_" + signature)
    tables = [by_id[sid] for sid in scoped]
try:
    column_profiles = load_profiles(workspace / "column_profiles.json")
except (OSError, ValueError) as exc:
    column_profiles = {}
    st.error(f"열 대응 프로필을 읽지 못했습니다: {exc}")
if tables:
    with st.expander("원본 측정열 자동 인식 · 고급 열 대응", expanded=False):
        st.caption("Polarization/Current와 전압은 원본 이름으로 선택합니다. 번호가 있으면 V1–P1/I1처럼 연결합니다. 부호를 바꾸거나 대칭 복사하지 않습니다.")
        shown = set()
        pending = copy.deepcopy(column_profiles)
        from openpyxl.utils import get_column_letter
        for layout in layouts(tables):
            sig = layout["signature"]
            if sig in shown:
                continue
            shown.add(sig)
            headers = layout["headers"]
            voltage_cols = [get_column_letter(i + 1) for i, h in enumerate(headers) if axis_info(h)[0] == "voltage"]
            response_cols = [i for i, h in enumerate(headers) if axis_info(h)[0] in ("polarization", "current", "current_density")]
            st.write(layout["table"].filename + " / " + layout["table"].sheet)
            for index in response_cols:
                y = get_column_letter(index + 1)
                try:
                    auto_x = matching_voltage_column(layout["table"], layout["start"], index)
                    auto_label = get_column_letter(auto_x + 1) if auto_x is not None else "미인식"
                except ValueError:
                    auto_label = "대응 정보 확인 필요"
                choices = ["자동", "제외"] + voltage_cols
                saved = column_profiles.get(sig, {}).get(y, "자동")
                selected = st.selectbox(f"{y}: {headers[index]} → X (자동: {auto_label})", choices,
                    index=choices.index("제외" if saved == "" else saved) if (saved in choices or saved == "") else 0,
                    format_func=lambda v, hs=headers: v if v in ("자동", "제외") else f"{v}: {hs[__import__('openpyxl').utils.column_index_from_string(v) - 1]}",
                    key=f"mapping_{sig}_{y}")
                pending.setdefault(sig, {})
                if selected == "자동":
                    pending[sig].pop(y, None)
                else:
                    pending[sig][y] = "" if selected == "제외" else selected
        if st.button("고급 열 대응 저장 · 같은 형식 파일에 재사용"):
            save_profiles(workspace / "column_profiles.json", pending)
            column_profiles = pending
            st.success("원본 헤더 구성이 같은 파일에 적용합니다.")
chat_tab, compare_tab, work_tab, db_tab = st.tabs(["AI 대화", "DB 비교 분석", "수동 계획 · 플롯", "누적 실험 DB"])
with chat_tab:
    st.caption("질문은 바로 답변하고, 그려 달라는 요청에만 플롯을 실행합니다. 파일·시트·전압·주파수·소자 조건을 함께 지정하세요.")
    chat_origin = st.checkbox("대화에서 플롯을 요청하면 Origin에도 실행", value=True)
    messages = st.session_state.setdefault("chat_messages", [])
    for message in messages:
        st.chat_message(message["role"]).write(message["content"])
    chat_request = st.chat_input("예: Bottom UV와 Pristine의 PV만, 1~3V 멀티스테이트를 조건별로 그리고 범례는 전압으로 해줘")
    if chat_request:
        history = list(messages)
        messages.append({"role": "user", "content": chat_request})
        st.chat_message("user").write(chat_request)
        try:
            existing = st.session_state.get("result")
            context = {"selected_sources": [{"source_id": t.source_id, "filename": t.filename, "sheet": t.sheet, "rows": len(t.frame)} for t in (tables or [])],
                       "current_curves": curve_context(existing["curves"]) if existing else [],
                       "last_data_request": existing["request"][-8000:] if existing else "",
                       "database_available": db_path.is_file(),
                       "color_mode": color_settings["mode"]}
            with st.spinner("요청을 확인하고 있습니다..."):
                decision = chat_turn(history, chat_request, context, get_key(), model)
                action, task = decision["action"], decision["task"]
                if comparison_intent(chat_request):
                    action, task = "compare", chat_request
                    decision["reply"] = "DB에서 조건을 맞춘 기준군을 찾아 실제 수치로 비교하겠습니다."
                elif existing and analysis_intent(chat_request, True):
                    action, task = "analyze", chat_request
                    decision["reply"] = "현재 플롯의 실제 계산값으로 분석하겠습니다."
                requested_kind = request_options(chat_request).get("measurement")
                if action == "style" and requested_kind and existing and requested_kind != existing["plan"].get("measurement"):
                    action = "plot"
                answer = decision["reply"]
                if action in ("plan", "plot"):
                    if not tables:
                        raise ValueError("측정 파일을 업로드하고 사용할 파일/시트를 선택해 주세요.")
                    proposed = ai_plan(tables, task + "\n이번 사용자 원문: " + chat_request, get_key(), model,
                        selection=selection_for(chat_request, tables))
                    proposed = constrain_plan(proposed, tables, **selection_for(chat_request, tables))
                    if not proposed.get("curves"):
                        answer += "\n" + "\n".join(proposed.get("notes", ["그릴 대상을 더 구체적으로 지정해 주세요."]))
                    elif action == "plan":
                        set_plan(configure_plan(proposed))
                        answer += f"\n요청에 맞는 곡선 {len(proposed['curves'])}개를 선택했습니다. 수동 계획 탭에서 확인할 수 있습니다."
                    else:
                        changed = store_result(proposed, tables, workspace, db_path, chat_request)
                        if auto_db:
                            save_run(db_path, changed["run_id"], task, changed["plan"], changed["curves"])
                            changed["db_saved"] = True
                        set_plan(changed["plan"])
                        st.session_state.result = changed
                        groups = {group_key(c, changed["plan"]) for c in changed["curves"]}
                        answer += f"\n요청한 곡선 {len(changed['curves'])}개, 그래프 {len(groups)}개로 정리했습니다."
                        if chat_origin:
                            try:
                                output = Path(changed["run_dir"]) / (changed["output_stem"] + ".opju")
                                st.session_state.origin_result = plot_origin(changed["curves"], changed["plan"], output, template, line_width, prog_id=ORIGIN_PROG_ID)
                                answer += "\nOrigin 저장 완료: " + str(output)
                            except Exception as exc:
                                answer += "\n데이터 정리는 완료했지만 Origin 실행 실패: " + str(exc)
                elif action == "style":
                    if not existing or not tables:
                        raise ValueError("먼저 데이터를 정리하거나 플롯해 주세요.")
                    options = ai_plot_options(existing["curves"], existing["plan"], task, get_key(), model)
                    proposed = apply_plot_options(existing["plan"], existing["curves"], options)
                    changed = store_result(proposed, st.session_state.tables, workspace, db_path,
                        existing["request"] + "\n보기 요청: " + chat_request, intent_request=chat_request, preserve_channels=True)
                    if auto_db:
                        save_run(db_path, changed["run_id"], changed["request"], changed["plan"], changed["curves"])
                        changed["db_saved"] = True
                    set_plan(changed["plan"])
                    st.session_state.result = changed
                    answer += "\n현재 곡선의 보기 설정을 적용했습니다."
                    if chat_origin:
                        try:
                            output = Path(changed["run_dir"]) / (changed["output_stem"] + ".opju")
                            st.session_state.origin_result = plot_origin(changed["curves"], changed["plan"], output, template, line_width, prog_id=ORIGIN_PROG_ID)
                            answer += "\nOrigin 저장 완료: " + str(output)
                        except Exception as exc:
                            answer += "\nOrigin 실행 실패: " + str(exc)
                elif action == "analyze":
                    if not existing:
                        raise ValueError("먼저 분석할 데이터를 정리해 주세요.")
                    interpretation = analyze_result(existing, chat_request, model)
                    st.session_state.interpretation = interpretation
                    answer += "\n" + interpretation
                elif action == "compare":
                    planned = comparison_plan(db_path, existing["curves"] if existing else [], chat_request, get_key(), model)
                    compared = execute_comparison(chat_request, planned["target_source"], planned["target_filters"],
                        planned["reference_filters"], planned["settings"], explain=True, save_to_db=True)
                    answer += "\n" + compared["report"]
                    if planned["notes"]:
                        answer += "\n" + "\n".join(planned["notes"])
        except Exception as exc:
            answer = "요청 처리 중 오류가 발생했습니다: " + str(exc)
        messages.append({"role": "assistant", "content": answer})
        st.chat_message("assistant").write(answer)
        try:
            chat_id = st.session_state.setdefault("chat_id", uuid.uuid4().hex)
            chat_dir = workspace / "chats"
            chat_dir.mkdir(parents=True, exist_ok=True)
            (chat_dir / (chat_id + ".json")).write_text(json.dumps(messages, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError as exc:
            st.warning(f"대화 기록 저장 실패: {exc}")
    current = st.session_state.get("result")
    if current and tables:
        st.caption("마지막 요청의 결과입니다. 파일/시트 범위나 색상 설정을 바꾼 뒤에는 새 요청을 보내 적용하세요.")
        preview(current["curves"], current["plan"])
        st.download_button("대화 결과 Excel 받기", (Path(current["run_dir"]) / "cleaned.xlsx").read_bytes(), current["output_stem"] + ".xlsx", key="chat_excel")
        with st.expander("현재 플롯의 P(0)·Pr 후보와 수치 분석", expanded=False):
            numerical, values = save_analysis_values(current)
            st.markdown(numeric_markdown(numerical))
            st.download_button("전체 교차점·분지 수치 CSV 받기", csv_bytes(values), "analysis_values.csv", key="chat_analysis_values")
            st.download_button("분석 수치 요약 JSON 받기", interpretation_payload(numerical), "analysis_summary.json", key="chat_analysis_summary")
with compare_tab:
    st.subheader("현재 측정과 DB 기준군 비교")
    st.caption("동일 전압·주파수의 기준 측정을 찾고, 단위를 통일해 분지별 차이와 크기 변화율을 계산합니다. DB의 원본 파일 경로가 바뀌어도 저장된 측정점으로 계산합니다.")
    if db_path.is_file():
        try:
            stored_comparison = comparison_catalog_for(db_path)
            current_comparison = st.session_state.get("result")
            treatments = sorted(stored_comparison.treatment.dropna().astype(str).unique().tolist())
            sources = {"current": "현재 정리·플롯한 데이터", "db": "DB에 저장된 데이터"}
            source_choice = st.radio("비교 대상 데이터", list(sources), index=0 if current_comparison else 1,
                format_func=sources.get, key="cmp_source")
            options = [None] + treatments
            labels = {None: "전체 처리 조건", "pristine": "Pristine", "bottom_uv": "Bottom UV", "top_uv": "Top UV", "both_uv": "Both UV"}
            reference_treatment = st.selectbox("기준군 처리 조건", options,
                index=options.index("pristine") if "pristine" in options else 0,
                format_func=lambda value: labels.get(value, str(value)), key="cmp_reference_treatment")
            reference_filters = {"treatment": reference_treatment} if reference_treatment else {}
            target_filters, selected_targets = {}, []
            if source_choice == "db":
                default_target = next((t for t in treatments if t != reference_treatment), None)
                target_treatment = st.selectbox("대상군 처리 조건", options, index=options.index(default_target),
                    format_func=lambda value: labels.get(value, str(value)), key="cmp_target_treatment")
                target_filters = {"treatment": target_treatment} if target_treatment else {}
                target_catalog = filter_catalog(stored_comparison, target_filters)
                names = dict(zip(target_catalog.curve_id, target_catalog.label))
                selected_targets = st.multiselect("DB 대상 곡선 선택 (비우면 해당 조건 전체)", list(names),
                    format_func=lambda cid: names[cid] + " · " + cid[:8], key="cmp_target_ids")
            defaults = ["p0_desc", "p0_asc"]
            if current_comparison and source_choice == "current" and all(axis_info(c.spec["y_name"], c.spec["y_unit"])[0] in ("current", "current_density") for c in current_comparison["curves"]):
                defaults = ["i_v_desc", "i_v_asc"]
            metrics = st.multiselect("비교할 특성", list(COMPARISON_METRICS), default=defaults,
                format_func=COMPARISON_METRICS.get, key="cmp_metrics_" + defaults[0])
            condition_labels = {"voltage_v": "인가전압 (V)", "frequency_hz": "주파수 (Hz)", "temperature_c": "온도 (°C)",
                "device_id": "소자 ID", "measurement_type": "측정 종류", "cycle": "사이클", "split_condition": "공정 split",
                "device_stack": "소자 구조", "treatment": "처리 조건"}
            fixed = st.multiselect("같게 맞출 측정 조건", list(META_FIELDS), default=["voltage_v", "frequency_hz"],
                format_func=condition_labels.get, key="cmp_fixed")
            group_options = [f for f in META_FIELDS if f not in fixed]
            group = st.multiselect("별도 기준군으로 구분할 조건", group_options,
                default=[f for f in ("treatment", "split_condition") if f in group_options], format_func=condition_labels.get, key="cmp_groups")
            value_mode = st.selectbox("한 곡선에 교차점이 여러 개일 때", ["range", "unique", "last"],
                format_func={"range": "전체 범위 유지", "unique": "하나의 값으로 정해질 때만", "last": "분지의 마지막 값 사용"}.get, key="cmp_value_mode")
            reference_mode = st.selectbox("여러 기준 측정의 대표 기준", ["range", "median"],
                format_func={"range": "기준 측정 전체 범위", "median": "측정별 단일 값의 중앙값"}.get, key="cmp_reference_mode")
            probe = st.number_input("전류 비교 전압 (V)", value=1., disabled=not any(m.startswith("i_v_") for m in metrics), key="cmp_probe")
            st.caption("단위 미확인·고정 조건 누락·자기 비교·중복 원본은 제외합니다. 기준에 0이 포함되면 변화율을 계산하지 않습니다. 다른 전압/주파수를 비교하려면 고정 조건에서 빼세요. 기준 데이터의 온도·소자구조·사이클이 다르면 별도 기준군으로 나눕니다.")
            explain = st.checkbox("AI로 비교 결과도 설명", value=False, key="cmp_explain")
            save_record = st.checkbox("비교 결과를 DB에도 기록", value=True, key="cmp_save_record")
            if st.button("조건을 맞춰 DB 비교 분석", type="primary", disabled=not metrics):
                try:
                    with st.spinner("저장된 측정점에서 특성을 계산하고 기준군과 비교 중..."):
                        settings_comparison = {"metrics": metrics, "fixed_fields": fixed, "group_by": group,
                            "value_mode": value_mode, "reference_mode": reference_mode, "probe_voltage_v": probe}
                        execute_comparison("DB 비교 분석 화면의 선택 조건", source_choice, target_filters,
                            reference_filters, settings_comparison, explain=explain, save_to_db=save_record, target_ids=selected_targets)
                except Exception as exc:
                    st.error(f"DB 비교 실패: {exc}")
        except Exception as exc:
            st.error(f"비교용 DB 조회 실패: {exc}")
    else:
        st.info("기존 측정 DB가 들어 있는 데이터 보관 폴더를 선택하거나 측정 데이터를 먼저 저장하세요. DB 데이터끼리 비교할 때는 새 파일 업로드가 필요 없습니다.")
    if db_path.is_file():
        try:
            history = comparison_history(db_path)
            if not history.empty:
                with st.expander("저장된 비교 보고서 다시 보기 · 최근 100건"):
                    names = {r.comparison_id: f"{r.created_at} · {r.request[:80]}" for r in history.itertuples()}
                    saved_id = st.selectbox("저장된 비교 기록", list(names), format_func=names.get, key="cmp_history")
                    if st.button("저장된 비교 보고서 불러오기"):
                        st.session_state.comparison_result = load_comparison(db_path, saved_id)
        except Exception as exc:
            st.error(f"비교 이력 조회 실패: {exc}")
    compared_current = st.session_state.get("comparison_result")
    if compared_current and compared_current.get("db_path") == str(db_path.resolve()):
        render_comparison(compared_current, "db_comparison")

with work_tab:
    request = st.text_area("어떻게 정리할까요?", value="PV만 그려줘. 전압별 데이터를 한 그래프에 겹치고 범례는 전압으로 해줘.", height=110)
    if tables:
        if st.button("1. 파일 읽기 · 데이터 구간 탐색", type="primary"):
            try:
                with st.spinner("원본 보관 및 전체 시트 탐색 중..."):
                    draft = constrain_plan(default_plan(tables), tables, **selection_for(request, tables))
                    set_plan(draft)
                st.success(f"{len(tables)}개 시트/텍스트를 읽었습니다. 원본은 SHA-256 이름으로 보관했습니다.")
            except Exception as exc:
                st.error(f"파일 읽기 실패: {exc}")
    if tables:
        st.dataframe(pd.DataFrame([{
            "source_id": t.source_id, "파일": t.filename, "시트": t.sheet,
            "행": len(t.frame), "열": t.frame.shape[1], "수치구간(원본 행)": str(numeric_blocks(t.frame)),
        } for t in tables]), hide_index=True, width="stretch")
        with st.expander("원본 시트 확인 (처음 100행)"):
            from openpyxl.utils import get_column_letter
            chosen = st.selectbox("시트 선택", list(range(len(tables))), format_func=lambda i: f"{tables[i].filename} / {tables[i].sheet}")
            frame = tables[chosen].frame.head(100).copy()
            frame.columns = [get_column_letter(i + 1) for i in range(frame.shape[1])]
            frame.index = frame.index + 1
            st.dataframe(frame.fillna("").astype(str), width="stretch")
        if st.button("2. OpenAI로 요청에 맞게 행·열·측정 조건 찾기", disabled=not model):
            try:
                with st.spinner("파일 구조를 분석 중입니다. DB 저장이나 Origin 실행은 아직 하지 않습니다..."):
                    proposed = ai_plan(tables, request, get_key(), model, selection=selection_for(request, tables))
                    proposed = constrain_plan(proposed, tables, **selection_for(request, tables))
                    # Validate before handing an AI plan to widgets; allow an empty
                    # selection only to display a reason and let the user re-plan.
                    from lab_core import validate_plan
                    validate_plan(proposed, tables, allow_empty=True)
                    set_plan(proposed)
                st.success("정리 계획을 만들었습니다. 아래 표에서 확인·수정하세요.")
            except Exception as exc:
                st.error(f"OpenAI 분석 실패: {exc}")
        if "plan" in st.session_state:
            st.subheader("3. 정리 계획 확인 · 수정")
            for note in st.session_state.plan["notes"]:
                st.info(note)
            edited_plan = plan_editor(st.session_state.plan)
            with st.expander("계획 JSON 직접 교체 (다른 블록 추가 등)"):
                manual = st.text_area("source_id는 위 표의 값을 사용하세요.", json.dumps(st.session_state.plan, ensure_ascii=False, indent=2), height=200, key=f"manual_{st.session_state.plan_revision}")
                if st.button("JSON 계획 적용"):
                    try:
                        from lab_core import validate_plan
                        candidate = validate_plan(json.loads(manual), tables)
                        set_plan(candidate)
                        st.rerun()
                    except Exception as exc:
                        st.error(f"계획 오류: {exc}")
            if st.button("4. 이 계획으로 데이터 정리 · 저장", type="primary"):
                try:
                    with st.spinner("유효한 X-Y 쌍 추출, 교차점 계산, 파일 저장 중..."):
                        result = store_result(edited_plan, tables, workspace, db_path, request)
                        curves, edited_plan = result["curves"], result["plan"]
                        run_id, run_dir = result["run_id"], Path(result["run_dir"])
                        clear_results()
                        st.session_state.result = result
                    st.success(f"{len(curves)}개 곡선 정리 완료: {run_dir}")
                    if auto_db:
                        try:
                            count = save_run(db_path, run_id, request, edited_plan, curves)
                            result["db_saved"] = True
                            st.success(f"SQLite 저장 완료: 새 곡선 {count}개. 동일 원본·설정은 중복 저장하지 않습니다.")
                        except Exception as exc:
                            st.error(f"파일 정리는 완료했지만 DB 저장 실패: {exc}. 아래 버튼으로 재시도할 수 있습니다.")
                            result["db_error"] = str(exc)
                    result["view_note"] = f"요청한 곡선 {len(curves)}개를 저장했습니다. AI 대화 탭에서 그래프를 볼 수 있습니다."
                    st.rerun()
                except Exception as exc:
                    st.error(f"데이터 정리 실패: {exc}")

    result = st.session_state.get("result") if tables else None
    if result:
        curves, plan = result["curves"], result["plan"]
        run_dir = Path(result["run_dir"])
        st.subheader("저장된 결과")
        if result.get("view_note"):
            st.success(result["view_note"])
        if result.get("origin_error"):
            st.error(result["origin_error"])
        if result.get("db_error"):
            st.error(result["db_error"])
        st.caption("아래는 마지막 '데이터 정리 · 저장'에서 확정한 결과입니다. 위 설정을 바꿨다면 다시 정리 버튼을 눌러 적용하세요.")
        st.dataframe(summary_frame(curves), hide_index=True, width="stretch")
        excluded = sum(c.excluded_rows for c in curves)
        if excluded:
            st.warning(f"선택한 구간에서 숫자가 아니거나 X/Y가 비어 제외된 행이 곡선별 합계 {excluded}개 있습니다. 제외 구간 사이로 보간하지 않습니다.")
        st.caption("교차점의 point는 정리된 곡선의 1-based 위치입니다. exact는 실측점, linear는 인접 유효점 사이 선형 보간입니다. 이를 자동으로 Pr/Ec로 판정하지 않습니다.")
        st.caption("그래프 미리보기는 AI 대화 탭에 표시합니다.")
        st.subheader("현재 곡선에 추가 요청")
        view_request = st.text_input("합치기 · 따로 그리기 · 범례 변경 요청",
            placeholder="예: 전부 한 그래프에 겹치고 범례는 시트명만 / 각각 따로 그려줘", key="view_request")
        also_origin = st.checkbox("요청 적용 후 Origin에도 바로 플롯", value=False)
        if st.button("보기 요청 적용", disabled=not model or not view_request.strip()):
            try:
                with st.spinner("현재 곡선의 그래프 구성과 범례를 변경 중..."):
                    requested_kind = request_options(view_request).get("measurement")
                    if requested_kind and requested_kind != plan.get("measurement"):
                        updated = ai_plan(tables, view_request, get_key(), model, selection=selection_for(view_request, tables))
                    else:
                        options = ai_plot_options(curves, plan, view_request, get_key(), model)
                        updated = apply_plot_options(plan, curves, options)
                    changed = store_result(updated, tables, workspace, Path(result["db_path"]),
                        result["request"] + "\n추가 보기 요청: " + view_request, intent_request=view_request,
                        preserve_channels=not bool(requested_kind))
                    if auto_db:
                        try:
                            save_run(Path(changed["db_path"]), changed["run_id"], changed["request"], changed["plan"], changed["curves"])
                            changed["db_saved"] = True
                        except Exception as exc:
                            changed["db_error"] = f"보기 변경은 완료했지만 DB 저장 실패: {exc}"
                    set_plan(changed["plan"])
                    st.session_state.result = changed
                    changed["view_note"] = "보기 요청을 적용했습니다. 기존 실행 결과는 보관하고 새 실행에 저장했습니다."
                    if also_origin:
                        try:
                            output = Path(changed["run_dir"]) / (changed["output_stem"] + ".opju")
                            st.session_state.origin_result = plot_origin(changed["curves"], changed["plan"], output, template, line_width, prog_id=ORIGIN_PROG_ID)
                        except Exception as exc:
                            changed["origin_error"] = f"보기 변경은 완료했지만 Origin 실행 실패: {exc}"
            except Exception as exc:
                st.error(f"보기 변경 실패: {exc}")
            else:
                st.rerun()
        st.download_button("정리 Excel 다운로드", (run_dir / "cleaned.xlsx").read_bytes(), result["output_stem"] + ".xlsx")
        st.download_button("정리 계획 JSON 다운로드", (run_dir / "plan.json").read_bytes(), "plan.json")
        st.download_button("전체 데이터 CSV 다운로드", (run_dir / "points.csv").read_bytes(), "points.csv")
        if st.button("이 결과를 DB에 저장 / 재확인"):
            try:
                count = save_run(Path(result["db_path"]), result["run_id"], result["request"], plan, curves)
                result["db_saved"] = True
                st.success(f"DB 저장 완료: 새 곡선 {count}개")
            except Exception as exc:
                st.error(f"DB 저장 실패: {exc}")
        if st.button("5. Origin 2020으로 플롯 · OPJU 저장"):
            try:
                output = run_dir / (result["output_stem"] + "_" + uuid.uuid4().hex[:6] + ".opju")
                with st.spinner("Windows의 Origin을 제어 중..."):
                    st.session_state.origin_result = plot_origin(curves, plan, output, template, line_width, prog_id=ORIGIN_PROG_ID)
                st.success(f"Origin 저장 완료: {output}")
            except Exception as exc:
                st.error(f"Origin 실행 실패: {exc}")
                st.caption("표시된 실패 단계와 오류 문구를 복사해 알려주세요. 정리 Excel/DB는 유지됩니다.")
        if "origin_result" in st.session_state:
            st.json(st.session_state.origin_result)
        if st.button("6. 계산 결과를 OpenAI로 해석", disabled=not model):
            try:
                with st.spinner("계산된 수치 요약을 해석 중..."):
                    st.session_state.interpretation = analyze_result(result, "현재 플롯 데이터를 분석해줘. " + result["request"], model)
            except Exception as exc:
                st.error(f"AI 해석 실패: {exc}")
        if "interpretation" in st.session_state:
            st.markdown(st.session_state.interpretation)

with db_tab:
    st.caption(f"DB 위치: {db_path}")
    if db_path.is_file():
        try:
            a, b = st.columns(2)
            filter_voltage = a.text_input("인가전압 조건 (V, 정확히 일치 / 빈칸=전체)")
            filter_split = b.text_input("공정 split (정확히 일치 / 빈칸=전체)")
            filters = {"split_condition": filter_split}
            if filter_voltage.strip():
                filters["voltage_v"] = float(filter_voltage)
            stored = query_curves(db_path, filters)
            visible = ["curve_id", "filename", "sheet", "label", *META_FIELDS]
            st.dataframe(stored[visible], hide_index=True, width="stretch")
            st.download_button("검색 결과 CSV", csv_bytes(stored), "db_search.csv")
            chosen_ids = st.multiselect("저장된 곡선 다시 보기", stored.curve_id.tolist(), format_func=lambda cid: stored.loc[stored.curve_id == cid, "label"].iloc[0])
            if chosen_ids:
                fig = go.Figure()
                with closing(sqlite3.connect(db_path)) as con:
                    for cid in chosen_ids:
                        frame = pd.read_sql_query("SELECT source_row,x,y FROM points WHERE curve_id=? ORDER BY point_index", con, params=(cid,))
                        spec = json.loads(stored.loc[stored.curve_id == cid, "spec_json"].iloc[0])
                        data = frame.set_index("source_row").reindex(range(int(frame.source_row.min()), int(frame.source_row.max()) + 1))
                        fig.add_trace(go.Scattergl(x=data.x, y=data.y, mode="lines", connectgaps=False, name=f"{spec['label']} | {spec['y_name']} [{spec['y_unit']}]"))
                st.warning("DB 재보기는 선택한 곡선을 그대로 겹칩니다. 축 물리량·단위·측정 조건이 같은지 확인하세요.")
                st.plotly_chart(fig, width="stretch")
        except Exception as exc:
            st.error(f"DB 조회 실패: {exc}")
    else:
        st.info("데이터 정리 후 DB 저장을 실행하면 검색할 수 있습니다.")
