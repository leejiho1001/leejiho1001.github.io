"""V4 regressions using anonymous synthetic data; no real Origin or API call."""
import copy
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from streamlit.testing.v1 import AppTest

from lab_core import ai_plan, default_plan, load_tables, materialize, prepare_plan, group_key
from plot_rules import request_options
from v4_selection import constrain_plan, export_preflight, layouts, profile_mappings, save_profiles, load_profiles
from curve_integrity import source_point_audit


def mixed_data(scale=1):
    # Opposite response channels reproduce unwanted mirrored additions without
    # changing signs in the plotter. The intended first channel is asymmetric.
    rows = ["Time [s]\tV+ [V]\tCurrent [A]\tPolarization [uC/cm2]\tI2 [A]\tP2 [uC/cm2]"]
    points = [(-1.9, -4.8), (-.8, -3.6), (.1, -1.3), (1.2, 3.4), (2.1, 5.3), (.9, 4.2), (-.1, 1.4), (-1.9, -4.8)]
    for index, (v, p) in enumerate(points):
        rows.append(f"{index/1000}\t{v}\t{p*scale/1000}\t{p*scale}\t{-p*scale/1000}\t{-p*scale}")
    return "\n".join(rows).encode()


class V4SelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.tables = load_tables([("pristine_1V.dat", mixed_data()), ("pristine_2V.dat", mixed_data(2))], self.root / "raw")
        self.plan = default_plan(self.tables)

    def tearDown(self):
        self.temp.cleanup()

    def test_exclusive_korean_and_hyphenated_requests(self):
        for request in ("PV만 그려", "PV 그려줘 IV는 빼고", "IV 말고 P-V로", "전류는 제외하고 분극만 그려", "PV만, IV는 그리지 말아줘"):
            with self.subTest(request=request):
                self.assertEqual(request_options(request)["measurement"], "PV")
        self.assertEqual(request_options("PV는 빼고 IV만")["measurement"], "IV")
        self.assertEqual(request_options("PV와 IV 둘 다")["measurement"], "auto")

    def test_pv_only_picks_polarization_preserves_multistates_and_original_xy(self):
        plan = prepare_plan(constrain_plan(self.plan, self.tables, "PV만 한 그래프에 그려줘"), self.tables)
        curves = materialize(plan, self.tables)
        self.assertEqual(len(curves), 2)
        self.assertEqual({c.spec["y_column"] for c in curves}, {"D"})
        self.assertEqual({c.spec["x_column"] for c in curves}, {"B"})
        self.assertEqual({c.spec["metadata"]["measurement_type"] for c in curves}, {"PV"})
        self.assertEqual(len({group_key(c, plan) for c in curves}), 1)
        self.assertEqual(curves[0].data.x.tolist(), [-1.9, -.8, .1, 1.2, 2.1, .9, -.1, -1.9])
        self.assertEqual(curves[0].data.y.tolist(), [-4.8, -3.6, -1.3, 3.4, 5.3, 4.2, 1.4, -4.8])
        self.assertEqual(len(source_point_audit(curves)), 16)
        export_preflight(curves, plan)

    def test_iv_only_excludes_every_polarization_column(self):
        plan = constrain_plan(self.plan, self.tables, "PV 말고 IV만 그려줘")
        curves = materialize(plan, self.tables)
        self.assertEqual(len(curves), 2)
        self.assertEqual({c.spec["y_column"] for c in curves}, {"C"})
        self.assertEqual({c.spec["metadata"]["measurement_type"] for c in curves}, {"IV"})

    def test_whitespace_dat_keeps_quantity_and_units_in_the_same_column(self):
        content = b"Time [s]   V+ [V]  Current density [A/cm2]   Polarization [uC/cm2]\n0 -1 -.1 -2\n1 0 .1 1\n2 1 .2 3"
        tables = load_tables([("spaces.dat", content)], self.root / "spaces")
        plan = constrain_plan(default_plan(tables), tables, "PV만")
        curve = materialize(plan, tables)[0]
        self.assertEqual((curve.spec["x_column"], curve.spec["y_column"]), ("B", "D"))
        self.assertEqual(curve.data.y.tolist(), [-2, 1, 3])

    def test_separate_label_and_unit_rows_keep_numbered_voltage_pairing(self):
        tables = load_tables([("unitrows.csv", b"V1,P1,V2,P2\nV,uC/cm2,V,uC/cm2\n-1,-2,1,2\n0,1,0,-1\n1,2,-1,-2")], self.root / "unitrows")
        plan = constrain_plan(default_plan(tables), tables, "P2만", measurement="PV")
        curve = materialize(plan, tables)[0]
        self.assertEqual((curve.spec["x_column"], curve.spec["y_column"]), ("C", "D"))

    def test_explicit_last_cycle_and_p2_are_selected_instead_of_first(self):
        for request in ("PV 마지막 사이클만", "P2만 그려줘"):
            plan = constrain_plan(self.plan, self.tables, request, measurement="PV")
            curves = materialize(plan, self.tables)
            self.assertEqual({c.spec["y_column"] for c in curves}, {"F"})
            self.assertEqual(len(curves), 2)

    def test_explicit_all_cycles_uses_real_channels_without_creating_extra_kinds(self):
        plan = constrain_plan(self.plan, self.tables, "PV만 모든 사이클 그려줘")
        curves = materialize(plan, self.tables)
        self.assertEqual(len(curves), 4)
        self.assertEqual({c.spec["y_column"] for c in curves}, {"D", "F"})
        self.assertEqual({c.spec["metadata"]["measurement_type"] for c in curves}, {"PV"})
        self.assertEqual(len(source_point_audit(curves)), 32)

    def test_original_request_overrides_mixed_ai_output_and_rewritten_task(self):
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text=json.dumps(self.plan)))))
        for wanted in ("PV", "IV"):
            result = ai_plan(self.tables, "PV와 IV 모두 그려", "offline", "test", client=client,
                selection={"request": wanted + "만 그려", "measurement": "auto"})
            self.assertEqual(result["measurement"], wanted)
            self.assertEqual(len(result["curves"]), 2)
            self.assertEqual({c.spec["metadata"]["measurement_type"] for c in materialize(result, self.tables)}, {wanted})

    def test_unrelated_ambiguous_iv_columns_cannot_block_pv(self):
        tables = load_tables([("mixed.csv", b"V+ [V],V- [V],P+ [uC/cm2],Current [A]\n-1,1,-2,-.1\n0,0,1,.1\n1,-1,2,.2")], self.root / "extra")
        plan = constrain_plan(default_plan(tables), tables, "PV만")
        self.assertEqual(len(materialize(plan, tables)), 1)
        self.assertEqual(plan["curves"][0]["x_column"], "A")

    def test_ambiguous_polarity_voltage_is_not_guessed_or_sign_flipped(self):
        tables = load_tables([("ambiguous.csv", b"V+ [V],V- [V],Polarization [uC/cm2]\n-1,1,-2\n0,0,1\n1,-1,2")], self.root / "ambiguous")
        plan = constrain_plan(default_plan(tables), tables, "PV만")
        with self.assertRaisesRegex(ValueError, "전압열 대응 불명확"):
            materialize(plan, tables)
        signature = layouts(tables)[0]["signature"]
        profiles = {signature: {"C": "B"}}
        path = self.root / "column_profiles.json"
        save_profiles(path, profiles)
        plan = constrain_plan(plan, tables, "PV만", mappings=profile_mappings(tables, load_profiles(path)))
        curves = materialize(plan, tables)
        self.assertEqual(curves[0].data.x.tolist(), [1, 0, -1])
        self.assertEqual(curves[0].data.y.tolist(), [-2, 1, 2])

    def test_origin_preflight_rejects_stale_mixed_curves_before_com(self):
        mixed = constrain_plan(self.plan, self.tables, "PV와 IV 모두")
        curves = materialize(mixed, self.tables)
        pv_plan = constrain_plan(mixed, self.tables, "PV만")
        with self.assertRaisesRegex(ValueError, "요청 계획과 출력 곡선"):
            export_preflight(curves, pv_plan)

    def test_zero_matching_measurements_produces_no_graph(self):
        tables = load_tables([("iv.csv", b"Voltage (V),Current (A)\n-1,-.1\n0,0\n1,.1")], self.root / "onlyiv")
        plan = constrain_plan(default_plan(tables), tables, "PV만")
        self.assertEqual(plan["curves"], [])
        with self.assertRaisesRegex(ValueError, "곡선이 없습니다"):
            materialize(plan, tables)


class V4WebTests(unittest.TestCase):
    def test_user_pv_only_wins_even_when_both_ai_stages_return_iv_too(self):
        upload = io.BytesIO(mixed_data())
        upload.name = "device_2V.dat"
        decision = {"action": "plot", "task": "PV와 IV 둘 다", "reply": "요청을 처리합니다."}
        def wrong_plan(tables, *args, **kwargs):
            return default_plan(tables)  # deliberately ignores selection and returns every column
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("streamlit.file_uploader", return_value=[upload]), patch("chat_agent.chat_turn", return_value=decision), patch("lab_core.ai_plan", side_effect=wrong_plan), patch("origin_adapter.plot_origin", return_value={}) as origin:
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(directory).run()
            app.chat_input[0].set_value("PV만 한 그래프에 그려줘. IV는 빼고").run(timeout=30)
            self.assertFalse(app.exception)
            result = app.session_state["result"]
            self.assertEqual(len(result["curves"]), 1)
            self.assertEqual(result["curves"][0].spec["y_column"], "D")
            self.assertEqual(result["plan"]["measurement"], "PV")
            self.assertEqual(len(app.get("plotly_chart")), 1)
            origin.assert_called_once()
            self.assertEqual(len(origin.call_args.args[0]), 1)
            self.assertEqual(origin.call_args.kwargs["prog_id"], "Origin.Application")
            manifest = json.loads((Path(result["run_dir"]) / "execution_manifest.json").read_text())
            self.assertEqual((manifest["version"], manifest["measurement"], manifest["graph_count"]), ("4.2.1", "PV", 1))
            # A mislabeled style action still reselects IV from the original upload.
            decision.update(action="style", task="IV만 그려줘")
            app.chat_input[0].set_value("이제 IV만 그려줘").run(timeout=30)
            self.assertFalse(app.exception)
            result = app.session_state["result"]
            self.assertEqual(result["plan"]["measurement"], "IV")
            self.assertEqual(result["curves"][0].spec["y_column"], "C")
            self.assertEqual(len(app.get("plotly_chart")), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
