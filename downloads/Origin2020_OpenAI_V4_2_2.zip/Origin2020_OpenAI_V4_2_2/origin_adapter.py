"""Origin 2020 COM adapter. Import pywin32 only when plotting on Windows."""
from __future__ import annotations

import sys
import uuid
from collections import defaultdict
from pathlib import Path
from time import perf_counter

from lab_core import Curve, curve_color, group_key
from lab_features import COLOR_DEFAULTS, colors_for_curves, validate_features
from plot_rules import axis_info, source_header
from openpyxl.utils import column_index_from_string
from v4_selection import export_preflight


def plot_origin(curves: list[Curve], plan: dict, output_path: Path,
                template_file: str = "", line_width: float = 3,
                prog_id: str = "Origin.Application", *, on_progress=None) -> dict:
    started, stage_started = perf_counter(), perf_counter()
    timings, execute_calls = {}, 0
    stage = "원본 검증"
    def enter_stage(label):
        nonlocal stage, stage_started
        now = perf_counter()
        timings[stage] = timings.get(stage, 0) + now - stage_started
        stage, stage_started = label, now
        if on_progress:
            try:
                on_progress(label)
            except Exception:
                pass
    if sys.platform != "win32":
        raise RuntimeError("Origin COM 플롯은 Origin 2020이 설치된 Windows에서 실행하세요.")
    if output_path.exists():
        raise FileExistsError("기존 Origin 파일은 덮어쓰지 않습니다. 새 출력명을 사용하세요.")
    if not .1 <= line_width <= 10:
        raise ValueError("선 두께는 0.1~10 범위여야 합니다.")
    if not curves:
        raise ValueError("플롯할 곡선이 없습니다.")
    export_preflight(curves, plan)
    validate_features(plan)
    if prog_id not in ("Origin.ApplicationSI", "Origin.Application"):
        raise ValueError("Origin COM 이름은 Origin.ApplicationSI 또는 Origin.Application이어야 합니다.")
    grouped = defaultdict(list)
    for curve in curves:
        grouped[group_key(curve, plan)].append(curve)
    templates, requested_templates, warnings = {}, {}, []
    for key, members in grouped.items():
        kind = members[0].spec["metadata"].get("measurement_type", "other")
        if kind not in ("PV", "IV", "XRD"):
            spec = members[0].spec
            x = axis_info(spec["x_name"], spec["x_unit"])[0]
            y = axis_info(spec["y_name"], spec["y_unit"])[0]
            kind = "PV" if x == "voltage" and y == "polarization" else "IV" if x == "voltage" and y in ("current", "current_density") else "other"
        chosen = plan.get("template_routes", {}).get(kind, template_file)
        requested_templates[key] = chosen
        if chosen and not Path(chosen).is_file():
            warnings.append(f"{kind} 템플릿 파일이 없어 Origin 기본 그래프로 출력했습니다: {chosen}")
            chosen = ""
        templates[key] = chosen or "origin"
    config = {**COLOR_DEFAULTS, **plan.get("color_settings", {})}
    native = "color_settings" in plan and config["mode"] == "origin"
    colors, positions = colors_for_curves(curves, plan, group_key)

    try:
        import pythoncom
        import win32com.client
    except ImportError as exc:
        raise RuntimeError(f"pywin32 불러오기 실패. 앱을 실행하는 Python에 pywin32를 설치하세요. 실행 Python: {sys.executable}") from exc

    pythoncom.CoInitialize()
    origin = wks = col = None
    enter_stage(f"COM 연결 ({prog_id})")
    try:
        # Match the user's original SI connection when requested. Never reset or
        # close an existing project; the new pages are appended to that project.
        origin = (win32com.client.Dispatch(prog_id) if prog_id.endswith("SI")
                  else win32com.client.DispatchEx(prog_id))
        enter_stage("Origin 준비")
        origin.Visible = 3 if prog_id.endswith("SI") else 0
        graphs = []

        def lt(command):
            nonlocal execute_calls
            execute_calls += 1
            if not origin.Execute(command):
                raise RuntimeError(f"LabTalk 실행 실패: {command}")

        def lt_many(commands):
            for offset in range(0, len(commands), 16):
                lt("\n".join(commands[offset:offset + 16]))

        def quoted(text):
            return str(text).replace("\\", "\\\\").replace('"', '\\"').replace("\r", "").replace("\n", "\\n")

        for key, members in grouped.items():
            enter_stage("워크시트 생성")
            token = uuid.uuid4().hex[:10]
            wks_name = origin.CreatePage(2, f"D{token}", "origin")
            if not wks_name:
                raise RuntimeError("Origin 워크시트 생성 실패")
            wks = origin.FindWorksheet(wks_name)
            stride = 3 if native else 2
            wks.Cols = len(members) * stride
            for i, curve in enumerate(members):
                enter_stage("X/Y 입력")
                # Insert explicit gaps for excluded source rows, so neither Origin
                # nor the web preview silently bridges a missing data interval.
                indexed = curve.data.set_index("source_row")[["x", "y"]]
                full = indexed.reindex(range(int(indexed.index.min()), int(indexed.index.max()) + 1))
                x_idx, y_idx = i * stride, i * stride + 1
                origin.PutWorksheet(wks_name, full.x.astype(float).tolist(), 0, x_idx)
                origin.PutWorksheet(wks_name, full.y.astype(float).tolist(), 0, y_idx)
                if native:
                    origin.PutWorksheet(wks_name, [positions[curve.curve_id]] * len(full), 0, y_idx + 1)
                for col_idx, axis, col_type in ((x_idx, "x", 3), (y_idx, "y", 0)):
                    enter_stage("열 속성 설정")
                    col = wks.Columns(col_idx)
                    col.Type = col_type
                    original_col = curve.spec[f"{axis}_column"]
                    original_header = source_header(curve.source, curve.spec["start_row"], column_index_from_string(original_col) - 1)
                    col.LongName = curve.spec["label"] if axis == "y" else original_header
                    col.Units = curve.spec[f"{axis}_unit"]
                    col.Comments = (f"{curve.source.filename} | {curve.source.sheet} | source {original_col}: {original_header} | "
                                    f"rows {curve.spec['start_row']}-{curve.spec['end_row']} | {curve.curve_id}")
            enter_stage("그래프 생성 / 템플릿 적용")
            try:
                graph = origin.CreatePage(3, f"G{token}", templates[key])
            except Exception:
                if templates[key] == "origin":
                    raise
                graph = None
            if not graph and templates[key] != "origin":
                warnings.append(f"선택한 템플릿을 불러오지 못해 Origin 기본 그래프로 출력했습니다: {templates[key]}")
                templates[key] = "origin"
                graph = origin.CreatePage(3, f"G{token}", "origin")
            if not graph:
                raise RuntimeError("Origin 기본 그래프 생성 실패: Origin 설치와 COM 연결을 확인하세요.")
            enter_stage("LabTalk 플롯 생성")
            lt(f"win -a {graph};")
            lt_many([f"plotxy iy:=[{wks_name}]1!({stride*i+1},{stride*i+2}) plot:=200 ogl:=[{graph}]1!;"
                     for i in range(len(members))])
            lt_many([f"win -a {graph};", "layer -s 1;", "layer -gu;"])
            enter_stage("곡선 색상 / 선 두께 설정")
            settings = []
            for i, curve in enumerate(members, 1):
                color = (colors[curve.curve_id] if "color_settings" in plan and config["mode"] != "condition" else curve_color(curve, plan)).lstrip("#")
                r, g, b = (int(color[j:j+2], 16) for j in (0, 2, 4))
                settings.append(f"range jihoPlot = !{i};")
                if native:
                    settings.append("set jihoPlot -c color(1,m);")
                    settings.append(f'jihoPlot.cmap.palette$ = "{quoted(config["origin_palette"])}";')
                    settings.append("jihoPlot.cmap.stretchpal=1; jihoPlot.cmap.linkpal=1;")
                    settings.append("jihoPlot.cmap.zmin=0; jihoPlot.cmap.zmax=1;")
                else:
                    settings.append("set jihoPlot -cue 1;")
                    settings.append(f"set jihoPlot -c color({r},{g},{b});")
                settings.append(f"set jihoPlot -w {line_width * 500:g};")
            lt_many(settings)
            enter_stage("축 / 범례 설정")
            settings = ["layer -a;", "legend -u;"]
            # LongName is written through COM, not interpolated into LabTalk.
            # Dataset references retain custom text and the correct line symbols.
            legend = r"\n".join(rf"\l({i}) %({i},@LL)" for i in range(1, len(members) + 1))
            settings.append(f'legend.text$ = "{legend}";')
            axes = members[0].spec
            for object_name, axis in (("xb", "x"), ("yl", "y")):
                title = axes[f"{axis}_name"] + (f" ({axes[f'{axis}_unit']})" if axes[f"{axis}_unit"] else "")
                settings.append(f'{object_name}.text$ = "{quoted(title)}";')
            lt_many(settings)
            graphs.append(graph)
        enter_stage("OPJU 파일 저장")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        if not origin.Save(str(output_path.resolve())):
            raise RuntimeError("Origin 프로젝트 저장 실패")
        if not output_path.is_file() or output_path.stat().st_size == 0:
            raise RuntimeError("Origin 저장 호출 후 결과 파일을 확인하지 못했습니다.")
        enter_stage("Origin 창 표시")
        origin.Visible = 3
        enter_stage("완료")
        return {"path": str(output_path.resolve()), "graphs": graphs, "graph_count": len(graphs), "curve_count": len(curves),
                "seconds": round(perf_counter() - started, 3), "execute_calls": execute_calls,
                "timings": {label: round(seconds, 3) for label, seconds in timings.items()},
                "warnings": list(dict.fromkeys(warnings)),
                "template_usage": [{"group": key, "requested": requested_templates[key] or "Origin 기본",
                                    "used": value} for key, value in templates.items()]}
    except Exception as exc:
        raise RuntimeError(f"[{stage}] {type(exc).__name__}: {exc}") from exc
    finally:
        if origin is not None:
            try:
                origin.Visible = 3
            except Exception:
                pass
        col = wks = origin = None
        pythoncom.CoUninitialize()
