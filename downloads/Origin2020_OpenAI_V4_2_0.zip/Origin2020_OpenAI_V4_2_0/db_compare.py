"""Condition-matched, unit-aware comparison of stored or current measurements."""
from __future__ import annotations

import copy
import io
import json
import math
from numbers import Real
import re
import sqlite3
import statistics
import uuid
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

from analysis_core import crossing_evidence
from plot_rules import axis_info, unit_text
from ferroelectric_metrics import feature_rows

ENGINE_VERSION = "db-comparison-1.1"
METRICS = {
    "p0_desc": "P(0) 하강 분지 · Pr+ 후보", "p0_asc": "P(0) 상승 분지 · Pr− 후보",
    "vc_desc": "Vc 하강 분지", "vc_asc": "Vc 상승 분지",
    "two_pr": "2Pr · 인접 반대 스윕쌍", "imprint": "임프린트 전압", "p_offset": "분극 수직 오프셋",
    "i_v_desc": "지정 전압 전류 · 하강 분지", "i_v_asc": "지정 전압 전류 · 상승 분지",
}
DEFAULT_SETTINGS = {"metrics": ["p0_desc", "p0_asc"], "fixed_fields": ["voltage_v", "frequency_hz"],
    "group_by": ["treatment", "split_condition"], "value_mode": "range", "reference_mode": "range", "probe_voltage_v": 1.0}
PREFIX = {"": 1., "p": 1e-12, "n": 1e-9, "u": 1e-6, "m": 1e-3, "k": 1e3, "M": 1e6}


def comparison_intent(request):
    db = bool(re.search(r"(?<![A-Za-z])DB(?![A-Za-z])|데이터베이스|디비|기준군|대조군|저장된|지난\s*(?:데이터|측정)|기존\s*(?:데이터|측정)|이전\s*(?:데이터|측정)", request, re.I))
    return db and bool(re.search(r"비교|차이|대비|얼마|변화|compare", request, re.I))


def _open_readonly(path):
    path = Path(path).resolve()
    if not path.is_file():
        raise ValueError("비교할 측정 DB가 없습니다. 먼저 측정 데이터를 저장하세요.")
    return sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=30)


def catalog(path):
    """No raw-file access and no schema mutation during a search."""
    from lab_core import META_FIELDS
    columns = ["curve_id", "source_sha256", "filename", "sheet", "label", "spec_json"]
    with closing(_open_readonly(path)) as con:
        frame = pd.read_sql_query("SELECT " + ",".join(columns) + " FROM curves ORDER BY rowid DESC", con)
    for field in META_FIELDS:
        frame[field] = [json.loads(text)["metadata"].get(field) for text in frame.spec_json]
    return frame


def _missing(value):
    return value is None or isinstance(value, float) and math.isnan(value) or value == ""


def _equal(a, b):
    if _missing(a) or _missing(b):
        return False
    if isinstance(a, Real) and isinstance(b, Real):
        return math.isclose(float(a), float(b), rel_tol=1e-6, abs_tol=1e-12)
    return str(a) == str(b)


def filter_catalog(frame, filters=None):
    from lab_core import META_FIELDS
    result = frame
    for key, value in (filters or {}).items():
        if key not in META_FIELDS:
            raise ValueError("지원하지 않는 DB 조건: " + str(key))
        if value is not None:
            result = result[result[key].map(lambda actual: _equal(actual, value))]
    return result


def load_db_curves(path, ids):
    """Reconstruct from ordered DB points even after the original files moved."""
    from lab_core import Curve, safe_crossings
    ids = list(dict.fromkeys(ids))
    result = []
    with closing(_open_readonly(path)) as con:
        con.row_factory = sqlite3.Row
        for cid in ids:
            row = con.execute("SELECT * FROM curves WHERE curve_id=?", (cid,)).fetchone()
            if row is None:
                raise ValueError("DB에서 선택한 곡선을 찾지 못했습니다: " + str(cid))
            spec = json.loads(row["spec_json"])
            data = pd.read_sql_query("SELECT source_row,x,y FROM points WHERE curve_id=? ORDER BY point_index", con, params=(cid,))
            if len(data) < 2:
                raise ValueError("저장된 유효 점이 2개 미만입니다: " + row["label"])
            metrics = {"n_points": len(data), "x_min": float(data.x.min()), "x_max": float(data.x.max()),
                "y_min": float(data.y.min()), "y_max": float(data.y.max()),
                "y_at_x_zero": safe_crossings(data, 0), "x_at_y_zero": safe_crossings(data, 0, invert=True),
                "comparison_x": None, "y_at_comparison_x": []}
            source = SimpleNamespace(sha256=row["source_sha256"], filename=row["filename"], sheet=row["sheet"],
                path=row["source_path"], source_id=spec["source_id"])
            result.append(Curve(cid, spec, source, data, row["excluded_rows"], metrics))
    return result


def measurement_identity(curve):
    s = curve.spec
    return (curve.source.sha256, curve.source.sheet, s["start_row"], s["end_row"], s["x_column"], s["y_column"])


def axis_conversion(name, unit):
    kind, unit = axis_info(name, unit)
    unit = unit_text(unit)
    if kind in ("voltage", "current"):
        match = re.fullmatch(r"([pnumkM]?)(V|A)", unit)
        if match and match[2] == ("V" if kind == "voltage" else "A"):
            return kind, match[2], PREFIX[match[1]]
    if kind in ("polarization", "current_density"):
        match = re.fullmatch(r"([pnumkM]?)(C|A)/(cm|m)2", unit)
        if match and match[2] == ("C" if kind == "polarization" else "A"):
            area_factor = 1. if match[3] == "cm" else 1e-4
            return ((kind, "uC/cm2", PREFIX[match[1]] * 1e6 * area_factor) if kind == "polarization"
                    else (kind, "A/cm2", PREFIX[match[1]] * area_factor))
    raise ValueError("단위 미확인 또는 지원하지 않는 물리량/단위: " + kind + " / " + unit)


def validate_settings(settings):
    from lab_core import META_FIELDS
    s = copy.deepcopy(DEFAULT_SETTINGS)
    s.update(settings or {})
    if set(s) != set(DEFAULT_SETTINGS) or not isinstance(s["metrics"], list) or not s["metrics"] or any(m not in METRICS for m in s["metrics"]):
        raise ValueError("비교 지표 설정을 확인하세요.")
    for key in ("fixed_fields", "group_by"):
        if not isinstance(s[key], list) or any(f not in META_FIELDS for f in s[key]):
            raise ValueError("비교 조건 필드를 확인하세요.")
        s[key] = list(dict.fromkeys(s[key]))
    s["metrics"] = list(dict.fromkeys(s["metrics"]))
    if set(s["fixed_fields"]) & set(s["group_by"]):
        raise ValueError("고정 조건과 기준군 구분 조건은 겹칠 수 없습니다.")
    if s["value_mode"] not in ("range", "last", "unique") or s["reference_mode"] not in ("range", "median"):
        raise ValueError("교차점/기준군 집계 방식을 확인하세요.")
    if type(s["probe_voltage_v"]) not in (int, float) or not math.isfinite(s["probe_voltage_v"]):
        raise ValueError("비교 전압은 유한한 수여야 합니다.")
    return s


def feature(curve, metric, settings):
    from lab_core import safe_crossings
    xkind, xunit, xf = axis_conversion(curve.spec["x_name"], curve.spec["x_unit"])
    ykind, yunit, yf = axis_conversion(curve.spec["y_name"], curve.spec["y_unit"])
    if xkind != "voltage":
        raise ValueError("현재 비교 지표는 전압 X축이 필요합니다.")
    if (metric.startswith(("p0_", "vc_")) or metric in ("two_pr", "imprint", "p_offset")) and ykind != "polarization":
        raise ValueError("Pr/Vc 후보는 분극 데이터가 필요합니다.")
    if metric.startswith("i_v_") and ykind not in ("current", "current_density"):
        raise ValueError("전류 비교 지표는 전류 또는 전류밀도 데이터가 필요합니다.")
    derived = metric in ("two_pr", "imprint", "p_offset")
    if derived:
        rows = [r for r in feature_rows(curve) if r["metric"] == metric and r["quality"] == "measured"]
        if settings["value_mode"] == "last":
            rows = rows[-1:]
        factor, unit = (xf, xunit) if metric == "imprint" else (yf, yunit)
        values = [value * factor for r in rows for value in (r["low"], r["high"])]
    else:
        target = settings["probe_voltage_v"] / xf if metric.startswith("i_v_") else 0.
        inverse = metric.startswith("vc_")
        events = safe_crossings(curve.data, target, invert=inverse)
        view = copy.copy(curve)
        if target and not inverse:
            view.data = curve.data.assign(x=curve.data.x - target)
        direction = "ascending" if metric.endswith("asc") else "descending"
        evidence = [crossing_evidence(view, e, "x_at_y_zero" if inverse else "y_at_x_zero") for e in events]
        rows = [r for r in evidence if r["direction"] == direction]
        factor, unit = (xf, xunit) if inverse else (yf, yunit)
        values = [r["value"] * factor for r in rows]
    if not values:
        if derived:
            raise ValueError("엄격 비교에 필요한 인접 반대 스윕쌍의 영점 근거가 부족합니다. 끝점·근접점 추정치는 현재 분석표에서 별도로 확인하세요.")
        raise ValueError("해당 전압/분지의 유효 교차점이 없습니다.")
    if any(not math.isfinite(value) for value in values):
        raise ValueError("단위 변환 결과가 유한한 수가 아닙니다.")
    if settings["value_mode"] == "unique" and min(values) != max(values):
        raise ValueError("교차점이 여러 값입니다. 사이클을 선택하거나 범위/마지막 값 모드를 사용하세요.")
    selected = values[-1:] if settings["value_mode"] == "last" and not derived else values
    return {"curve_id": curve.curve_id, "filename": curve.source.filename, "label": curve.spec["label"],
        "source_sha256": curve.source.sha256, "sheet": curve.source.sheet,
        "x_column": curve.spec["x_column"], "y_column": curve.spec["y_column"],
        "metric": metric, "unit": unit, "min": min(selected), "max": max(selected), "crossing_count": len(rows) if derived else len(values),
        "scale_factor": factor,
        "raw_x_unit": curve.spec["x_unit"], "raw_y_unit": curve.spec["y_unit"],
        "measured_voltage_min": float(curve.data.x.min()) * xf,
        "measured_voltage_max": float(curve.data.x.max()) * xf, "point_count": len(curve.data),
        "evidence_json": json.dumps(rows, ensure_ascii=False)}


def _abs_bounds(lo, hi):
    return (0. if lo <= 0 <= hi else min(abs(lo), abs(hi))), max(abs(lo), abs(hi))


def compare_measurements(targets, references, settings=None):
    from lab_core import META_FIELDS
    s = validate_settings(settings)
    group_fields = list(dict.fromkeys(s["group_by"] + [f for f in ("voltage_v", "frequency_hz", "temperature_c", "device_stack", "cycle") if f not in s["fixed_fields"]]))
    excluded, rows, features = [], [], []
    unique_targets, unique_refs = [], []
    for collection, destination, role in ((targets, unique_targets, "target"), (references, unique_refs, "reference")):
        seen = set()
        for c in collection:
            identity = measurement_identity(c)
            if identity in seen:
                excluded.append({"role": role, "curve_id": c.curve_id, "metric": "", "reason": "동일 원본 측정의 재사용/자기 비교 제외"})
                continue
            seen.add(identity)
            destination.append(c)
    cache = {}
    for role, collection in (("target", unique_targets), ("reference", unique_refs)):
        for c in collection:
            for metric in s["metrics"]:
                try:
                    f = feature(c, metric, s)
                    cache[(c.curve_id, metric)] = f
                    features.append({"role": role, **f})
                except ValueError as exc:
                    excluded.append({"role": role, "curve_id": c.curve_id, "metric": metric, "reason": str(exc)})
    for target in unique_targets:
        tm = target.spec["metadata"]
        eligible_refs = []
        for ref in unique_refs:
            if measurement_identity(ref) == measurement_identity(target):
                excluded.append({"role": "reference", "curve_id": ref.curve_id, "target_id": target.curve_id,
                    "metric": "", "reason": "동일 원본 측정의 자기 비교 제외"})
            else:
                eligible_refs.append(ref)
        missing = [f for f in s["fixed_fields"] if _missing(tm.get(f))]
        if missing:
            excluded.append({"role": "target", "curve_id": target.curve_id, "metric": "", "reason": "고정 조건 미확인: " + ", ".join(missing)})
            continue
        for metric in s["metrics"]:
            tf = cache.get((target.curve_id, metric))
            if not tf:
                continue
            groups = {}
            for ref in eligible_refs:
                rm = ref.spec["metadata"]
                rf = cache.get((ref.curve_id, metric))
                if not rf or not all(_equal(tm.get(f), rm.get(f)) for f in s["fixed_fields"]):
                    continue
                if rf["unit"] != tf["unit"]:
                    excluded.append({"role": "reference", "curve_id": ref.curve_id, "metric": metric, "reason": "대상과 물리량/단위가 다름"})
                    continue
                key = json.dumps({f: rm.get(f) for f in group_fields}, sort_keys=True, ensure_ascii=False)
                groups.setdefault(key, []).append((ref, rf))
            if not groups:
                excluded.append({"role": "target", "curve_id": target.curve_id, "metric": metric, "reason": "같은 고정 조건·단위의 별도 기준 측정이 없음"})
            for group, members in groups.items():
                baseline_lo = min(f["min"] for _, f in members)
                baseline_hi = max(f["max"] for _, f in members)
                if s["reference_mode"] == "median":
                    if any(f["min"] != f["max"] for _, f in members):
                        excluded.append({"role": "reference_group", "curve_id": target.curve_id, "metric": metric, "reason": "교차점 범위의 임의 중앙값 집계 금지: unique/last 모드가 필요함"})
                        continue
                    baseline_lo = baseline_hi = statistics.median(f["min"] for _, f in members)
                ta, tb = _abs_bounds(tf["min"], tf["max"])
                ra, rb = _abs_bounds(baseline_lo, baseline_hi)
                percent_lo = (ta / rb - 1) * 100 if ra > 0 else None
                percent_hi = (tb / ra - 1) * 100 if ra > 0 else None
                other = {}
                unknown = []
                for field in META_FIELDS:
                    values = [r.spec["metadata"].get(field) for r, _ in members]
                    if _missing(tm.get(field)) or any(_missing(v) for v in values):
                        unknown.append(field)
                    if field not in s["fixed_fields"] + s["group_by"] + ["measurement_type"] and any(not _equal(tm.get(field), v) for v in values if not _missing(v)):
                        other[field] = {"target": tm.get(field), "references": list(dict.fromkeys(values))}
                measured_range = [tf["measured_voltage_min"], tf["measured_voltage_max"]]
                reference_ranges = [[f["measured_voltage_min"], f["measured_voltage_max"]] for _, f in members]
                if any(not all(_equal(a, b) for a, b in zip(measured_range, ref_range)) for ref_range in reference_ranges):
                    other["measured_voltage_range_v"] = {"target": measured_range, "references": reference_ranges}
                rows.append({"target_id": target.curve_id, "target_label": target.spec["label"],
                    "target_filename": target.source.filename, "reference_group": group,
                    "reference_ids": json.dumps([r.curve_id for r, _ in members]), "reference_count": len(members),
                    "metric": metric, "metric_label": METRICS[metric], "unit": tf["unit"],
                    "probe_voltage_v": s["probe_voltage_v"] if metric.startswith("i_v_") else None,
                    "target_min": tf["min"], "target_max": tf["max"], "reference_min": baseline_lo, "reference_max": baseline_hi,
                    "delta_min": tf["min"] - baseline_hi, "delta_max": tf["max"] - baseline_lo,
                    "magnitude_change_percent_min": percent_lo, "magnitude_change_percent_max": percent_hi,
                    "status": "compared" if ra > 0 else "baseline_includes_zero_percent_undefined",
                    "fixed_conditions": json.dumps({f: tm.get(f) for f in s["fixed_fields"]}, ensure_ascii=False),
                    "other_condition_differences": json.dumps(other, ensure_ascii=False),
                    "unknown_condition_fields": json.dumps(unknown),
                    "voltage_v": tm.get("voltage_v"), "frequency_hz": tm.get("frequency_hz"),
                    "target_treatment": tm.get("treatment")})
    return {"comparison_id": uuid.uuid4().hex, "engine_version": ENGINE_VERSION, "settings": s, "effective_group_by": group_fields,
        "rows": pd.DataFrame(rows), "excluded": pd.DataFrame(excluded), "features": pd.DataFrame(features),
        "target_count": len(unique_targets), "reference_count": len(unique_refs)}


def compare_database(path, current, target_filters=None, reference_filters=None, settings=None, target_source="current", target_ids=None):
    frame = catalog(path)
    targets = current if target_source == "current" else load_db_curves(path,
        target_ids if target_ids else filter_catalog(frame, target_filters).curve_id.tolist())
    if target_source == "current" and target_filters:
        targets = [c for c in targets if all(v is None or _equal(c.spec["metadata"].get(k), v) for k, v in target_filters.items())]
    if not targets:
        raise ValueError("선택한 조건의 비교 대상 데이터가 없습니다.")
    refs = filter_catalog(frame, reference_filters)
    s = validate_settings(settings)
    catalog_excluded = []
    if len(refs):
        matches = refs.apply(lambda row: any(all(_equal(c.spec["metadata"].get(f), row[f]) for f in s["fixed_fields"]) for c in targets), axis=1)
        catalog_excluded = [{"role": "reference_catalog", "curve_id": row.curve_id, "metric": "",
            "reason": "대상과 고정 조건이 다르거나 미확인: " + ", ".join(s["fixed_fields"])} for row in refs[~matches].itertuples()]
        refs = refs[matches]
    result = compare_measurements(targets, load_db_curves(path, refs.curve_id.tolist()), s)
    if catalog_excluded:
        result["excluded"] = pd.concat([result["excluded"], pd.DataFrame(catalog_excluded)], ignore_index=True)
    result.update(target_source=target_source, target_filters=target_filters or {}, reference_filters=reference_filters or {})
    return result


def records(frame):
    """Keep tiny currents and full float precision, while serializing NaN as null."""
    result = frame.astype(object).where(frame.notna(), None).to_dict("records")
    for row in result:
        for key, value in row.items():
            if hasattr(value, "item"):
                value = value.item()
            if isinstance(value, Real) and not math.isfinite(value):
                value = None
            row[key] = value
    return result


def result_payload(result):
    return {key: result[key] for key in ("comparison_id", "engine_version", "settings", "effective_group_by", "target_count", "reference_count")} | {
        key: records(result[key]) for key in ("rows", "excluded", "features")}


def comparison_markdown(result, max_rows=30):
    if result["rows"].empty:
        return f"비교 가능한 측정을 찾지 못했습니다. 제외 사유 {len(result['excluded'])}건을 확인하세요. 조건·단위 미확인 값을 임의로 연결하지 않았습니다."
    def interval(a, b):
        if a is None or pd.isna(a):
            return "정의 불가"
        return f"{a:.6g}" if a == b else f"{a:.6g} ~ {b:.6g}"
    lines = ["| 대상 | 지표 | 기준군 | 대상 값 | 기준 값 | 차이(대상−기준) | 크기 변화율(%) | 단위 |",
        "|---|---|---|---:|---:|---:|---:|---|"]
    for row in result["rows"].head(max_rows).to_dict("records"):
        label = row["target_label"].replace("|", "\\|").replace("\n", " ")[:90]
        group_values = json.loads(row["reference_group"])
        group = " · ".join(f"{k}={v}" for k, v in group_values.items() if v is not None).replace("|", "\\|") or "조건 미기록"
        lines.append(f"| {label} | {row['metric_label']} | {group} | {interval(row['target_min'], row['target_max'])} | {interval(row['reference_min'], row['reference_max'])} | {interval(row['delta_min'], row['delta_max'])} | {interval(row['magnitude_change_percent_min'], row['magnitude_change_percent_max'])} | {row['unit']} |")
    lines += ["", "차이는 부호를 유지한 대상−기준입니다. 크기 변화율은 (|대상|/|기준|−1)×100이며, 기준 범위에 0이 있으면 정의하지 않습니다. "
        "범위는 보수적 차이 구간이며 통계적 신뢰구간이 아닙니다. Pr/Vc는 후보값이며 수치 변화가 곧 공정 효과의 인과적 증거는 아닙니다."]
    if len(result["rows"]) > max_rows:
        lines.append(f"전체 {len(result['rows'])}개 비교 중 {max_rows}개 표시. 전체 결과는 Excel/CSV에 보관합니다.")
    return "\n".join(lines)


def comparison_excel(result):
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        for key, sheet in (("rows", "Comparison"), ("features", "Features"), ("excluded", "Excluded")):
            safe = result[key].map(lambda v: "'" + v if isinstance(v, str) and v.startswith(("=", "+", "-", "@")) else v)
            safe.to_excel(writer, sheet_name=sheet, index=False)
        pd.DataFrame([{"field": k, "value": json.dumps(v, ensure_ascii=False)} for k, v in result["settings"].items()]).to_excel(writer, sheet_name="Settings", index=False)
    return output.getvalue()


def save_comparison(path, workspace, request, result, save_to_db=True):
    payload = result_payload(result)
    payload.update(request=request, target_source=result.get("target_source"),
        target_filters=result.get("target_filters", {}), reference_filters=result.get("reference_filters", {}))
    payload["report"] = comparison_markdown(result)
    folder = Path(workspace) / "comparisons" / result["comparison_id"]
    folder.mkdir(parents=True, exist_ok=False)
    for key in ("rows", "features", "excluded"):
        safe = result[key].map(lambda v: "'" + v if isinstance(v, str) and v.startswith(("=", "+", "-", "@")) else v)
        (folder / (key + ".csv")).write_bytes(safe.to_csv(index=False).encode("utf-8-sig"))
    (folder / "comparison.json").write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2), encoding="utf-8")
    (folder / "comparison.xlsx").write_bytes(comparison_excel(result))
    (folder / "report.md").write_text(comparison_markdown(result), encoding="utf-8")
    result["folder"] = str(folder)
    result["db_saved"] = False
    if save_to_db:
        with closing(sqlite3.connect(path, timeout=30)) as con, con:
            con.execute("CREATE TABLE IF NOT EXISTS comparison_runs (comparison_id TEXT PRIMARY KEY, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, engine_version TEXT NOT NULL, request TEXT NOT NULL, payload_json TEXT NOT NULL)")
            con.execute("INSERT INTO comparison_runs(comparison_id,engine_version,request,payload_json) VALUES(?,?,?,?)",
                (result["comparison_id"], ENGINE_VERSION, request, json.dumps(payload, ensure_ascii=False, allow_nan=False)))
    result["db_saved"] = save_to_db
    return folder


def comparison_history(path):
    with closing(_open_readonly(path)) as con:
        if con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='comparison_runs'").fetchone() is None:
            return pd.DataFrame(columns=["comparison_id", "created_at", "request", "engine_version"])
        return pd.read_sql_query("SELECT comparison_id,created_at,request,engine_version FROM comparison_runs ORDER BY created_at DESC,rowid DESC LIMIT 100", con)


def load_comparison(path, comparison_id):
    with closing(_open_readonly(path)) as con:
        row = con.execute("SELECT payload_json FROM comparison_runs WHERE comparison_id=?", (comparison_id,)).fetchone()
    if row is None:
        raise ValueError("저장된 비교 기록을 찾지 못했습니다.")
    payload = json.loads(row[0])
    for field in ("rows", "features", "excluded"):
        payload[field] = pd.DataFrame(payload[field])
    payload["db_path"] = str(Path(path).resolve())
    payload["db_saved"] = True
    payload["historical_snapshot"] = True
    payload.setdefault("report", comparison_markdown(payload))
    return payload


def update_comparison_report(path, comparison_id, report):
    with closing(sqlite3.connect(path, timeout=30)) as con, con:
        row = con.execute("SELECT payload_json FROM comparison_runs WHERE comparison_id=?", (comparison_id,)).fetchone()
        if row is None:
            raise ValueError("저장된 비교 기록을 찾지 못했습니다.")
        payload = json.loads(row[0])
        payload["report"] = report
        con.execute("UPDATE comparison_runs SET payload_json=? WHERE comparison_id=?", (json.dumps(payload, ensure_ascii=False, allow_nan=False), comparison_id))
