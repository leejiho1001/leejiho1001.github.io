"""Persistent user template choices, including deferred Windows paths."""
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from lab_features import (load_library, save_library, add_template, template_routes,
    STANDARD_TEMPLATES, TEMPLATE_AUTO, TEMPLATE_ORIGIN, common_template)


class TemplateOptionsTests(unittest.TestCase):
    def test_three_provided_windows_paths_register_exactly_once_without_linux_rewriting(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "template_library.json"
            library = load_library(path, STANDARD_TEMPLATES)
            self.assertEqual([t["name"] for t in library["templates"]], ["P-V Curve", "I-V Curve", "XRD_2"])
            self.assertEqual(template_routes(library), STANDARD_TEMPLATES)
            save_library(path, library)
            self.assertEqual(load_library(path, STANDARD_TEMPLATES), library)

    def test_origin_and_disabled_role_choices_survive_seed_reload(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "library.json"
            library = load_library(path, STANDARD_TEMPLATES)
            library["defaults"].pop("PV")
            library["selected"] = TEMPLATE_ORIGIN
            save_library(path, library)
            restored = load_library(path, STANDARD_TEMPLATES)
            self.assertNotIn("PV", restored["defaults"])
            self.assertEqual(template_routes(restored), {})
            restored["selected"] = "XRD_2"
            self.assertEqual(common_template(restored), STANDARD_TEMPLATES["XRD"])
            self.assertEqual(set(template_routes(restored).values()), {STANDARD_TEMPLATES["XRD"]})

    def test_later_template_addition_infers_kind_and_is_available_after_reload(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "library.json"
            library = load_library(path, STANDARD_TEMPLATES)
            added = add_template(library, "", "auto", '"C:\\Lab\\New P-V.otpu"')
            self.assertEqual(added, "New P-V")
            save_library(path, library)
            restored = load_library(path, STANDARD_TEMPLATES)
            self.assertEqual(template_routes(restored)["PV"], r"C:\Lab\New P-V.otpu")
            self.assertEqual(len(restored["templates"]), 4)
            with self.assertRaises(ValueError):
                add_template(restored, "New P-V", "PV", r"C:\Other\sample.otpu")


class TemplateSidebarTests(unittest.TestCase):
    def open(self, folder):
        app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
        app.sidebar.text_input[0].set_value(folder).run(timeout=30)
        self.assertFalse(app.exception)
        return app

    def test_selection_addition_and_role_defaults_persist_with_code_settings_mode(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "template_library.json"
            app = self.open(folder)
            next(s for s in app.selectbox if s.label == "사용할 템플릿").set_value("XRD_2").run(timeout=30)
            self.assertEqual(json.loads(path.read_text())["selected"], "XRD_2")
            app = self.open(folder)
            self.assertEqual(next(s for s in app.selectbox if s.label == "사용할 템플릿").value, "XRD_2")
            next(t for t in app.text_input if t.label == "새 템플릿 이름 (선택)").set_value("Custom PV")
            next(t for t in app.text_input if t.label == "새 템플릿 경로").set_value(r"C:\Lab\New P-V.otpu")
            next(b for b in app.button if b.label == "템플릿 추가").click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            self.assertEqual(next(s for s in app.selectbox if s.label == "사용할 템플릿").value, "Custom PV")
            self.assertEqual(json.loads(path.read_text())["defaults"]["PV"], "Custom PV")
            next(s for s in app.selectbox if s.label == "사용할 템플릿").set_value(TEMPLATE_AUTO).run(timeout=30)
            app = self.open(folder)
            self.assertEqual(json.loads(path.read_text())["defaults"]["PV"], "Custom PV")
            self.assertEqual(len(json.loads(path.read_text())["templates"]), 4)
            next(s for s in app.selectbox if s.label == "PV 자동 선택 기본값").set_value(TEMPLATE_ORIGIN).run(timeout=30)
            app = self.open(folder)
            self.assertNotIn("PV", json.loads(path.read_text())["defaults"])

    def test_new_choice_is_applied_to_existing_result_at_origin_call(self):
        upload = io.BytesIO(b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\n0,2\n-2,-5")
        upload.name = "sample_3V_1kHz.csv"
        def uploaded(label, *args, **kwargs):
            return [upload] if label == "측정 파일 여러 개 업로드" else None
        with tempfile.TemporaryDirectory() as folder, patch("streamlit.file_uploader", side_effect=uploaded), patch("origin_adapter.plot_origin", return_value={}) as origin:
            app = self.open(folder)
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            result = app.session_state["result"]
            previous = result["curves"][0].data.copy()
            next(s for s in app.selectbox if s.label == "사용할 템플릿").set_value("XRD_2").run(timeout=30)
            next(b for b in app.button if b.label.startswith("5.")).click().run(timeout=30)
            origin.assert_called_once()
            self.assertEqual(origin.call_args.args[1]["template_routes"]["PV"], STANDARD_TEMPLATES["XRD"])
            self.assertEqual(origin.call_args.args[3], STANDARD_TEMPLATES["XRD"])
            self.assertTrue(previous.equals(app.session_state["result"]["curves"][0].data))


if __name__ == "__main__":
    unittest.main(verbosity=2)
