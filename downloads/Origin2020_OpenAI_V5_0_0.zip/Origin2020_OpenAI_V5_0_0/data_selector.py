"""Generic XY discovery and original-row selection reports; no point transformation."""
import re
import copy

import pandas as pd
from openpyxl.utils import get_column_letter, column_index_from_string
from plot_rules import axis_info, source_header, measurement_kind, AXIS_NAMES


X_KINDS = {"diffraction_angle", "angle", "wavelength", "wavenumber", "frequency", "time", "voltage", "field", "temperature", "distance"}


def infer_xy_pairs(table, start, end):
    from lab_core import numeric
    block = numeric(table.frame.iloc[start - 1:end])
    cols = [i for i in range(block.shape[1]) if block.iloc[:, i].notna().sum() >= 2]
    headers = {i: source_header(table, start, i) for i in cols}
    kinds = {i: axis_info(headers[i])[0] for i in cols}
    axes = [i for i in cols if kinds[i] in X_KINDS or re.fullmatch(r"\s*X\s*\d*\s*", re.sub(r"[\[(].*", "", headers[i]), re.I)]
    electrical = [i for i in cols if kinds[i] in ("polarization", "current", "current_density")]
    voltages = [i for i in axes if kinds[i] == "voltage"]
    if electrical and voltages:
        return [(voltages[0], y) for y in electrical]
    if not axes and cols:
        axes = [cols[0]]
    pairs = []
    for y in cols:
        if y in axes:
            continue
        preceding = [x for x in axes if x < y]
        x = preceding[-1] if preceding else axes[0]
        if x != y:
            pairs.append((x, y))
    return pairs


def restore_all_channels(plan, tables):
    """An explicit all-channel command includes real channels in selected blocks.

    Do not expand source/file scope or row intervals chosen for the request.
    No numerical values are generated or altered.
    """
    sources = {t.source_id: t for t in tables}
    blocks = {}
    seen = {(s['source_id'], s['start_row'], s['end_row'], s['y_column']) for s in plan['curves']}
    for spec in list(plan['curves']):
        table = sources[spec['source_id']]
        key = (spec['source_id'], spec['start_row'], spec['end_row'])
        if key not in blocks:
            blocks[key] = infer_xy_pairs(table, spec['start_row'], spec['end_row'])
        raw_x, raw_y = (axis_info(source_header(table, spec['start_row'], column_index_from_string(spec[f'{a}_column'])-1))[0] for a in ('x', 'y'))
        family = measurement_kind(raw_x, raw_y)
        for x, y in blocks[key]:
            identity = (*key, get_column_letter(y+1))
            if identity in seen:
                continue
            x_header, y_header = (source_header(table, spec['start_row'], c) for c in (x, y))
            xkind, xunit = axis_info(x_header)
            ykind, yunit = axis_info(y_header)
            if measurement_kind(xkind, ykind) != family:
                continue
            added = copy.deepcopy(spec)
            added.update(x_column=get_column_letter(x+1), y_column=get_column_letter(y+1),
                         x_name=AXIS_NAMES.get(xkind, x_header), y_name=AXIS_NAMES.get(ykind, y_header),
                         x_unit=xunit, y_unit=yunit, label=f'{table.filename} / {table.sheet} / {y_header}')
            plan['curves'].append(added)
            seen.add(identity)
    return plan


def selection_report(curves):
    rows = []
    for curve in curves:
        spec = curve.spec
        rows.append({"파일": curve.source.filename, "시트": curve.source.sheet,
            "측정 유형": spec["metadata"].get("measurement_type") or "XY",
            "X 열": spec["x_column"], "X 원본 헤더": source_header(curve.source, spec["start_row"], column_index_from_string(spec["x_column"]) - 1),
            "Y 열": spec["y_column"], "Y 원본 헤더": source_header(curve.source, spec["start_row"], column_index_from_string(spec["y_column"]) - 1),
            "시작 행": spec["start_row"], "끝 행": spec["end_row"], "선택 점": len(curve.data),
            "앞에서 스킵한 행": spec["start_row"] - 1, "뒤에서 스킵한 행": len(curve.source.frame) - spec["end_row"],
            "선택 구간 비수치·빈 행": curve.excluded_rows,
            "선택하지 않은 열": ", ".join(get_column_letter(i + 1) for i in range(curve.source.frame.shape[1])
                                      if get_column_letter(i + 1) not in (spec["x_column"], spec["y_column"]))})
    return pd.DataFrame(rows)
