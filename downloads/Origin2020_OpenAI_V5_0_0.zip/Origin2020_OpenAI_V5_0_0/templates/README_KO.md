이 폴더에 실제 Origin 그래프 템플릿을 넣으면 프로그램과 함께 이동할 수 있습니다.

- P-V Curve.otpu — PV
- I-V Curve.otpu — IV
- XRD_2.otpu — XRD

파일이 실제로 있을 때만 내장 템플릿으로 등록합니다. 저장된 상대 위치는
templates/파일명이며, 실행 중인 프로그램 폴더를 기준으로 불러옵니다.
03_update_existing.bat도 이 파일들을 기존 설치의 templates 폴더에 복사합니다.
기존 파일을 교체하면 update_backup_* 아래에 이전 파일을 보관합니다.

현재 세 템플릿의 실제 바이너리 파일은 아직 전달되지 않았습니다.
경로 문자열이나 OPJU 프로젝트는 해당 OTPU 파일을 대신하지 않습니다.
파일이 없는 경우에는 Origin 기본 그래프로 플롯합니다.
