import copy
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

from lab_core import (ai_plot_options, apply_plot_options, default_plan, group_key,
                      load_tables, materialize, prepare_plan, validate_plan)
from plot_rules import request_options


class PlotRulesTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.tables = load_tables([
            ("sampleA.csv", "P (µC/cm²),Voltage (V)\n-5,-2\n-1,0\n5,2\n1,0\n-5,-2\n".encode()),
            ("sampleB.csv", b"Voltage (V),Polarization (uC/cm2)\n-3,-7\n0,-2\n3,7\n0,2\n-3,-7\n"),
        ], self.root / "raw")
        self.plan = default_plan(self.tables)

    def tearDown(self):
        self.temp.cleanup()

    def test_default_combines_pv_with_different_headers_and_missing_metadata(self):
        curves = materialize(self.plan, self.tables)
        self.assertEqual(len(curves), 2)
        self.assertEqual(len({group_key(c, self.plan) for c in curves}), 1)
        self.assertEqual(curves[0].data.x.tolist(), [-2, 0, 2, 0, -2])
        self.assertEqual(curves[0].data.y.tolist(), [-5, -1, 5, 1, -5])
        self.assertEqual(curves[0].spec["x_name"], "Voltage")
        self.assertEqual(curves[0].spec["y_name"], "Polarization")

    def test_reversed_ai_pair_is_corrected_from_raw_headers(self):
        plan = copy.deepcopy(self.plan)
        spec = plan["curves"][0]
        for key in ("column", "name", "unit"):
            spec[f"x_{key}"], spec[f"y_{key}"] = spec[f"y_{key}"], spec[f"x_{key}"]
        normalized = prepare_plan(plan, self.tables)
        self.assertEqual(normalized["curves"][0]["x_column"], "B")
        self.assertEqual(normalized["curves"][0]["y_column"], "A")
        self.assertTrue(any("바로잡" in n for n in normalized["notes"]))
        self.assertEqual(materialize(plan, self.tables)[0].data.x.tolist(), [-2, 0, 2, 0, -2])

    def test_manual_mode_preserves_intentional_axis_choice(self):
        plan = copy.deepcopy(self.plan)
        plan["measurement"] = "manual"
        plan["curves"][0].update(x_column="A", y_column="B", x_name="P", y_name="V")
        self.assertEqual(materialize(plan, self.tables)[0].data.x.tolist(), [-5, -1, 5, 1, -5])

    def test_separate_mode_creates_one_group_per_curve(self):
        self.plan["plot_mode"] = "separate"
        curves = materialize(self.plan, self.tables)
        self.assertEqual(len({group_key(c, self.plan) for c in curves}), 2)

    def test_explicit_grouped_mode_uses_conditions(self):
        self.plan.update(plot_mode="grouped", group_by=["temperature_c"])
        for spec, temperature in zip(self.plan["curves"], (400, 500)):
            spec["metadata"]["temperature_c"] = temperature
        curves = materialize(self.plan, self.tables)
        self.assertEqual(len({group_key(c, self.plan) for c in curves}), 2)
        self.plan["plot_mode"] = "combined"
        self.assertEqual(len({group_key(c, self.plan) for c in curves}), 1)

    def test_iv_voltage_is_x_and_pv_is_not_mixed_with_current(self):
        more = load_tables([("iv.csv", b"Current (A),Voltage (V)\n-0.1,-2\n0,0\n0.2,2\n")], self.root / "raw")
        tables = self.tables + more
        plan = default_plan(tables)
        curves = materialize(plan, tables)
        self.assertEqual(len(curves), 3)
        self.assertEqual(len({group_key(c, plan) for c in curves}), 2)
        self.assertEqual(curves[-1].data.x.tolist(), [-2, 0, 2])
        self.assertEqual(curves[-1].data.y.tolist(), [-.1, 0, .2])
        plan["measurement"] = "PV"
        self.assertEqual(len(materialize(plan, tables)), 2)
        plan["measurement"] = "IV"
        self.assertEqual(len(materialize(plan, tables)), 1)

    def test_legend_format_is_idempotent_and_matches_selected_metadata(self):
        self.plan["legend_format"] = "{stem} / {temperature_c:g} °C"
        for spec, temperature in zip(self.plan["curves"], (400, 500)):
            spec["metadata"]["temperature_c"] = temperature
        once = prepare_plan(self.plan, self.tables)
        twice = prepare_plan(once, self.tables)
        self.assertEqual(once, twice)
        self.assertEqual([c.spec["label"] for c in materialize(twice, self.tables)],
                         ["sampleA / 400 °C", "sampleB / 500 °C"])

    def test_legend_rejects_attribute_access_and_missing_condition_is_explicit(self):
        self.plan["legend_format"] = "{filename.__class__}"
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.tables)
        self.plan["legend_format"] = "{temperature_c:g} °C"
        self.assertEqual(materialize(self.plan, self.tables)[0].spec["label"], "미확인 °C")

    def test_followup_changes_only_mode_and_labels_preserving_data(self):
        curves = materialize(self.plan, self.tables)
        options = {"plot_mode": "separate", "group_by": [], "legend_format": "",
                   "labels": [{"curve_id": curves[0].curve_id, "label": "Baseline"}], "notes": []}
        updated = apply_plot_options(self.plan, curves, options)
        after = materialize(updated, self.tables)
        self.assertEqual(after[0].spec["label"], "Baseline")
        for a, b in zip(curves, after):
            self.assertTrue(a.data.equals(b.data))
        options["labels"][0]["curve_id"] = "not-in-selected-data"
        with self.assertRaises(ValueError):
            apply_plot_options(self.plan, curves, options)

    def test_natural_followup_uses_small_model_call_and_explicit_overlay_wins(self):
        curves = materialize(self.plan, self.tables)
        options = {"plot_mode": "grouped", "group_by": ["voltage_v"], "legend_format": "{stem}", "labels": [], "notes": []}
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text=json.dumps(options)))))
        answer = ai_plot_options(curves, self.plan, "전부 한 그래프에 합쳐줘. 범례는 파일명만.", "fake", "fake", client=client)
        self.assertEqual(answer["plot_mode"], "combined")
        self.assertEqual(client.responses.create.call_count, 1)
        self.assertNotIn("sample_rows", client.responses.create.call_args.kwargs["input"])
        self.assertEqual(request_options("각각 따로 그려줘")["plot_mode"], "separate")


if __name__ == "__main__":
    unittest.main(verbosity=2)
