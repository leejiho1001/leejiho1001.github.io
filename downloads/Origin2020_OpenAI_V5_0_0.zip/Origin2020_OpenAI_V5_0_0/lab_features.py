"""Lab-specific classification, multistate colors, templates and output names."""
from __future__ import annotations

import json
import copy
import math
import re
from collections import defaultdict
from pathlib import Path, PureWindowsPath
from string import Formatter

from plotly.colors import get_colorscale, sample_colorscale


COLOR_DEFAULTS = {"mode": "rainbow", "colormap": "Viridis", "reverse": False,
                  "start": "#FF69B4", "end": "#00FF00", "scope": "global", "origin_palette": "Maple.pal"}
FEATURE_DEFAULTS = {"color_settings": COLOR_DEFAULTS, "filename_format": "", "template_routes": {}}
TREATMENTS = {"pristine": "Pristine", "bottom_uv": "Bottom UV", "top_uv": "Top UV", "both_uv": "Bottom + Top UV"}
TEMPLATE_KINDS = ("PV", "IV", "XRD", "other")
TEMPLATE_AUTO = "__auto__"
TEMPLATE_ORIGIN = "__origin__"
STANDARD_TEMPLATES = {
    "PV": r"C:\Users\이지호\Desktop\UNIST\실험\Python\Graph Template\P-V Curve.otpu",
    "IV": r"C:\Users\이지호\Desktop\UNIST\실험\Python\Graph Template\I-V Curve.otpu",
    "XRD": r"C:\Users\이지호\Desktop\UNIST\실험\Python\Graph Template\XRD_2.otpu",
}
BUNDLED_TEMPLATE_NAMES = {"PV": "P-V Curve.otpu", "IV": "I-V Curve.otpu", "XRD": "XRD_2.otpu"}


def register_bundled_templates(library, app_dir=None):
    """Register actual bundled assets; saved paths remain portable across PCs."""
    app_dir = Path(app_dir) if app_dir is not None else Path(__file__).resolve().parent
    for kind, filename in BUNDLED_TEMPLATE_NAMES.items():
        if not (app_dir / "templates" / filename).is_file():
            continue
        relative = (Path("templates") / filename).as_posix()
        existing = next((t for t in library["templates"] if t["kind"] == kind and (
            t.get("bundled") == filename or str(PureWindowsPath(t["path"])).casefold()
            == str(PureWindowsPath(STANDARD_TEMPLATES[kind])).casefold())), None)
        if existing:
            existing.update(path=relative, bundled=filename)
            continue
        base, suffix = PureWindowsPath(filename).stem, 1
        name = base
        while any(t["name"] == name for t in library["templates"]):
            name = f"{base} (내장 {suffix})"
            suffix += 1
        had_kind = any(t["kind"] == kind for t in library["templates"])
        library["templates"].append(dict(name=name, kind=kind, path=relative, bundled=filename))
        if kind not in library["defaults"] and not had_kind:
            library["defaults"][kind] = name
    return library


def requested_subset(plan, request):
    """Hard limits for explicit multistate ranges/frequencies; never trim X samples."""
    result = copy.deepcopy(plan)
    predicates = []
    if re.search(r"멀티|state|인가|조건", request, re.I):
        match = re.search(r"([+-]?\d+(?:\.\d+)?)\s*(?:V|볼트)?\s*(?:~|～|–|-|부터|to)\s*([+-]?\d+(?:\.\d+)?)\s*(?:V|볼트)", request, re.I)
        if match:
            low, high = sorted(map(float, match.groups()))
            predicates.append(lambda meta: meta.get("voltage_v") is not None and low <= meta["voltage_v"] <= high)
    frequencies = {float(value) * {"hz": 1, "khz": 1000, "mhz": 1e6}[unit.lower()]
                   for value, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(MHz|kHz|Hz)", request, re.I)}
    if frequencies and re.search(r"만|only|조건|주파수", request, re.I):
        predicates.append(lambda meta: meta.get("frequency_hz") in frequencies)
    treatment = None
    for pattern, value in ((r"(?:pristine|프리스틴)\s*만|only\s+pristine", "pristine"),
                           (r"(?:bottom\s*uv|바텀\s*uv|하부\s*uv)\s*만", "bottom_uv"),
                           (r"(?:top\s*uv|상부\s*uv)\s*만", "top_uv")):
        if re.search(pattern, request, re.I):
            treatment = value
    if treatment:
        predicates.append(lambda meta: meta.get("treatment") == treatment)
    if predicates:
        before = len(result["curves"])
        result["curves"] = [s for s in result["curves"] if all(rule(s["metadata"]) for rule in predicates)]
        if len(result["curves"]) != before:
            result["notes"].append(f"명시한 상태/주파수/처리 조건 밖의 곡선 {before - len(result['curves'])}개를 제외했습니다.")
    return result


def classify_treatment(text: str):
    text = text.casefold()
    uv = r"(?:uv|ultraviolet|자외선)"
    bottom = r"(?:bottom|bot(?:tom)?|\bbe\b|바텀|하부)"
    top = r"(?:top|\bte\b|상부|탑)"
    lower = bool(re.search(bottom + r".{0,16}" + uv + "|" + uv + r".{0,16}" + bottom, text))
    upper = bool(re.search(top + r".{0,16}" + uv + "|" + uv + r".{0,16}" + top, text))
    pristine = bool(re.search(r"pristine|프리스틴|무처리|미처리", text))
    if pristine and (lower or upper):
        return None
    return "pristine" if pristine else "both_uv" if lower and upper else "bottom_uv" if lower else "top_uv" if upper else None


def validate_features(plan):
    config = plan.get("color_settings", COLOR_DEFAULTS)
    if not isinstance(config, dict) or set(config) - set(COLOR_DEFAULTS):
        raise ValueError("색상 설정 필드를 확인하세요.")
    config = {**COLOR_DEFAULTS, **config}
    if config["mode"] not in ("rainbow", "colormap", "custom", "origin", "condition"):
        raise ValueError("색상 모드를 확인하세요.")
    if type(config["reverse"]) is not bool or config["scope"] not in ("global", "graph"):
        raise ValueError("색상 순서/범위를 확인하세요.")
    for name in ("start", "end"):
        if not isinstance(config[name], str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", config[name]):
            raise ValueError("시작/끝 색은 #RRGGBB 형식이어야 합니다.")
    if config["mode"] == "colormap":
        try:
            get_colorscale(config["colormap"])
        except Exception as exc:
            raise ValueError("지원하지 않는 공통 컬러맵입니다.") from exc
    palette = config["origin_palette"]
    if not isinstance(palette, str) or len(palette) > 500 or any(ch in palette for ch in ('"', '\n', '\r', ';')) or not palette.lower().endswith((".pal", ".xml")):
        raise ValueError("Origin 팔레트는 .pal/.xml 이름 또는 경로를 입력하세요.")
    routes = plan.get("template_routes", {})
    if not isinstance(routes, dict) or any(k not in TEMPLATE_KINDS or not isinstance(v, str) for k, v in routes.items()):
        raise ValueError("템플릿 연결 정보를 확인하세요.")
    pattern = plan.get("filename_format", "")
    if not isinstance(pattern, str) or len(pattern) > 180:
        raise ValueError("파일명 형식은 180자 이하여야 합니다.")
    for _, field, spec, conversion in Formatter().parse(pattern):
        if field is not None and (field not in ("measurement", "device", "treatment", "frequency", "voltage") or spec or conversion):
            raise ValueError("파일명에는 {measurement}, {device}, {treatment}, {frequency}, {voltage}를 사용할 수 있습니다.")


def state_positions(curves, plan):
    """N distinct condition values -> N evenly spaced palette samples, sorted numerically."""
    field = plan["color_by"]
    values = {}
    for curve in curves:
        value = curve.spec["metadata"].get(field)
        if value is None:
            value = curve.spec["label"]
        values[curve.curve_id] = value
    unique = sorted(set(values.values()), key=lambda v: (0, float(v)) if isinstance(v, (int, float)) else (1, str(v)))
    rank = {value: i for i, value in enumerate(unique)}
    return {cid: rank[value] / (len(unique) - 1) if len(unique) > 1 else 0.0 for cid, value in values.items()}


def rgb_hex(value):
    if value.startswith("#"):
        return value.upper()
    channels = [int(round(float(v))) for v in re.findall(r"[\d.]+", value)[:3]]
    return "#" + "".join(f"{v:02X}" for v in channels)


def colors_for_curves(curves, plan, group_key):
    config = {**COLOR_DEFAULTS, **plan.get("color_settings", {})}
    groups = defaultdict(list)
    for curve in curves:
        groups[group_key(curve, plan) if config["scope"] == "graph" else "all"].append(curve)
    colors, positions = {}, {}
    rainbow = [[i / 6, rgb] for i, rgb in enumerate(("#FF0000", "#FF7F00", "#FFFF00", "#00FF00", "#00FFFF", "#0000FF", "#9400D3"))]
    scale = ([[0, config["start"]], [1, config["end"]]] if config["mode"] == "custom" else
             get_colorscale(config["colormap"]) if config["mode"] == "colormap" else rainbow)
    for members in groups.values():
        for cid, position in state_positions(members, plan).items():
            position = 1 - position if config["reverse"] else position
            positions[cid] = position
            colors[cid] = "#808080" if config["mode"] == "origin" else rgb_hex(sample_colorscale(scale, [position])[0])
    return colors, positions


def safe_name(text):
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(text)).strip(" .")[:64]
    if not text or re.fullmatch(r"(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])", text, re.I):
        text = "measurement_" + text
    return text


def output_stem(curves, pattern=""):
    def one(field, fallback):
        values = {c.spec["metadata"].get(field) for c in curves} - {None, ""}
        return next(iter(values)) if len(values) == 1 else fallback
    frequency = one("frequency_hz", None)
    voltages = sorted({c.spec["metadata"].get("voltage_v") for c in curves} - {None})
    context = {"measurement": one("measurement_type", "measurement"), "device": one("device_id", "devices"),
               "treatment": one("treatment", "conditions"),
               "frequency": (f"{frequency / 1000:g}kHz" if frequency >= 1000 else f"{frequency:g}Hz") if frequency is not None else "frequency_unknown",
               "voltage": (f"{voltages[0]:g}V" if len(voltages) == 1 else f"{voltages[0]:g}-{voltages[-1]:g}V") if voltages else "voltage_unknown"}
    return safe_name((pattern or "{measurement}_{device}_{treatment}_{frequency}_{voltage}").format(**context))


def template_path(value):
    value = str(value).strip().strip('"').strip("'").strip()
    if not value or PureWindowsPath(value).suffix.lower() not in (".otpu", ".otp") or any(c in value for c in ("\n", "\r", "\0")):
        raise ValueError(".otpu 또는 .otp 템플릿 경로를 입력하세요.")
    if PureWindowsPath(value).is_absolute():
        return value  # Keep Windows/UNC paths intact even when configured in Linux.
    return str(Path(value).expanduser().resolve())


def infer_template_kind(path, name=""):
    for text in (PureWindowsPath(str(path)).stem, name):
        if re.search(r"xrd|diffraction", text, re.I):
            return "XRD"
        if re.search(r"(?<![A-Za-z])P[ _-]*V(?![A-Za-z])|polarization", text, re.I):
            return "PV"
        if re.search(r"(?<![A-Za-z])I[ _-]*V(?![A-Za-z])|current", text, re.I):
            return "IV"
    return "other"


def load_library(path, seeds=None):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("templates"), list) or not isinstance(data.get("defaults"), dict):
            raise ValueError("템플릿 라이브러리 형식이 잘못되었습니다.")
    except FileNotFoundError:
        data = {"templates": [], "defaults": {}}
    for item in data["templates"]:
        if not isinstance(item, dict) or not all(isinstance(item.get(k), str) for k in ("name", "kind", "path")) or item["kind"] not in TEMPLATE_KINDS:
            raise ValueError("등록된 템플릿 이름·종류·경로를 확인하세요.")
    for kind, value in (seeds or {}).items():
        if not value:
            continue
        if kind not in TEMPLATE_KINDS:
            raise ValueError("지원하지 않는 템플릿 종류입니다.")
        value = template_path(value)
        existing = next((item for item in data["templates"] if item["kind"] == kind and (
            str(PureWindowsPath(item["path"])).casefold() == str(PureWindowsPath(value)).casefold()
            or (item.get("bundled") == BUNDLED_TEMPLATE_NAMES.get(kind)
                and str(PureWindowsPath(value)).casefold() == str(PureWindowsPath(STANDARD_TEMPLATES.get(kind, ""))).casefold()))), None)
        if existing:
            preferred_name = PureWindowsPath(value).stem
            if existing["name"] == f"코드 기본값 {kind}" and not any(item["name"] == preferred_name for item in data["templates"]):
                previous = existing["name"]
                existing["name"] = preferred_name
                data["defaults"] = {k: preferred_name if v == previous else v for k, v in data["defaults"].items()}
                if data.get("selected") == previous:
                    data["selected"] = preferred_name
            continue  # Preserve a saved 'no role default' instead of reseeding it.
        had_kind = any(item["kind"] == kind for item in data["templates"])
        base = PureWindowsPath(value).stem
        name, index = base, 2
        names = {item["name"] for item in data["templates"]}
        while name in names:
            name = f"{base} ({index})"
            index += 1
        data["templates"].append({"name": name, "kind": kind, "path": value})
        if kind not in data["defaults"] and not had_kind:
            data["defaults"][kind] = name
    data.setdefault("selected", TEMPLATE_AUTO)
    if data["selected"] not in {TEMPLATE_AUTO, TEMPLATE_ORIGIN, *(item["name"] for item in data["templates"])}:
        data["selected"] = TEMPLATE_AUTO
    return data


def save_library(path, library):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(library, ensure_ascii=False, indent=2)
    if path.is_file() and path.read_text(encoding="utf-8") == serialized:
        return
    temporary = path.with_suffix(".json.new")
    temporary.write_text(serialized, encoding="utf-8")
    temporary.replace(path)


def add_template(library, name, kind, path, make_default=True):
    path = template_path(path)
    name = name.strip() or PureWindowsPath(path).stem
    kind = infer_template_kind(path, name) if kind == "auto" else kind
    if kind not in TEMPLATE_KINDS or name in (TEMPLATE_AUTO, TEMPLATE_ORIGIN):
        raise ValueError("템플릿 이름/그래프 종류를 확인하세요.")
    if any(item["name"] == name for item in library["templates"]):
        raise ValueError("같은 이름의 템플릿이 있습니다. 다른 이름으로 추가하세요.")
    library["templates"].append({"name": name, "kind": kind, "path": path})
    if make_default:
        library["defaults"][kind] = name
    return name


def template_routes(library, app_dir=None):
    by_name = {item["name"]: item for item in library["templates"]}
    selected = library.get("selected", TEMPLATE_AUTO)
    if selected == TEMPLATE_ORIGIN:
        # Empty entries explicitly override an old common template_file fallback.
        return {kind: "" for kind in TEMPLATE_KINDS}
    def resolved(item):
        if item.get("bundled"):
            filename = item["bundled"]
            if filename not in BUNDLED_TEMPLATE_NAMES.values() or PureWindowsPath(filename).name != filename:
                raise ValueError("내장 템플릿 파일명을 확인하세요.")
            root = Path(app_dir) if app_dir is not None else Path(__file__).resolve().parent
            return str((root / "templates" / filename).resolve())
        return item["path"]
    if selected in by_name:
        return {kind: resolved(by_name[selected]) for kind in TEMPLATE_KINDS}
    return {kind: resolved(by_name[name]) for kind, name in library["defaults"].items() if name in by_name}


def common_template(library, app_dir=None):
    return template_routes(library, app_dir).get("other", "")
