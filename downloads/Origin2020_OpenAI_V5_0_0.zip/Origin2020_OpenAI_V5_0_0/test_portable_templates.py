"""Template-free output and portable asset registration/update (mock COM only)."""
import json
import io
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest

from apply_plot_update import FILES, update_existing
from lab_features import (BUNDLED_TEMPLATE_NAMES, STANDARD_TEMPLATES, TEMPLATE_KINDS,
    TEMPLATE_ORIGIN, load_library, save_library, register_bundled_templates, template_routes)
import test_origin_adapter


class TemplateFreeOriginTests(unittest.TestCase):
    def setUp(self):
        self.case = test_origin_adapter.OriginProtocolTests()
        self.case.setUp()

    def tearDown(self):
        self.case.tearDown()

    def test_missing_office_template_falls_back_and_preserves_every_xy_value(self):
        self.case.plan["template_routes"] = {"IV": str(self.case.root / "absent-office-template.otpu")}
        result = self.case.run_plot()
        self.assertEqual((result["graph_count"], result["curve_count"]), (1, 1))
        self.assertTrue(result["warnings"])
        graphs = [c.args for c in self.case.origin.CreatePage.call_args_list if c.args[0] == 3]
        self.assertEqual(graphs[0][2], "origin")
        self.assertEqual(result["template_usage"][0]["used"], "origin")
        self.assertEqual(self.case.origin.PutWorksheet.call_args_list[0].args[1], [-1., 0., 1.])
        self.assertEqual(self.case.origin.PutWorksheet.call_args_list[1].args[1], [-2., 1., 2.])
        self.case.origin.Save.assert_called_once()

    def test_origin_choice_overrides_a_stale_common_template_even_if_file_exists(self):
        stale = self.case.root / "old-common.otpu"
        stale.write_bytes(b"synthetic-template")
        library = load_library(self.case.root / "library.json", STANDARD_TEMPLATES)
        library["selected"] = TEMPLATE_ORIGIN
        self.case.plan["template_routes"] = template_routes(library)
        result = self.case.run_plot(template_file=str(stale))
        self.assertEqual(set(self.case.plan["template_routes"]), set(TEMPLATE_KINDS))
        self.assertEqual(result["warnings"], [])
        self.assertEqual(result["template_usage"][0]["used"], "origin")

    def test_unloadable_custom_template_retries_default_graph_once(self):
        chosen = self.case.root / "unsupported.otpu"
        chosen.write_bytes(b"synthetic-not-a-real-template")
        attempts = []
        def create(page_type, name, template):
            if page_type == 3:
                attempts.append(template)
                if template == str(chosen):
                    raise RuntimeError("synthetic template load failure")
            return name
        self.case.origin.CreatePage.side_effect = create
        result = self.case.run_plot(template_file=str(chosen))
        self.assertEqual(attempts, [str(chosen), "origin"])
        self.assertTrue(result["warnings"])
        self.assertEqual(result["graph_count"], 1)

    def test_default_graph_failure_is_reported_and_com_is_cleaned_up(self):
        self.case.origin.CreatePage.side_effect = lambda page_type, name, template: name if page_type == 2 else ""
        with self.assertRaisesRegex(RuntimeError, "Origin 기본 그래프 생성 실패"):
            self.case.run_plot()
        self.case.origin.Save.assert_not_called()
        self.case.com.CoUninitialize.assert_called_once()


class PortableAssetTests(unittest.TestCase):
    def test_relocated_app_uses_its_own_assets_and_keeps_no_template_choice_after_restart(self):
        upload = io.BytesIO(b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\n0,2\n-2,-5")
        upload.name = "anonymous_3V.csv"
        def uploaded(label, *args, **kwargs):
            return [upload] if label == "측정 파일 여러 개 업로드" else None
        with tempfile.TemporaryDirectory() as folder, patch("streamlit.file_uploader", side_effect=uploaded), patch("origin_adapter.plot_origin", return_value={}) as origin:
            root = Path(folder)
            for name in FILES:
                shutil.copy2(Path(__file__).with_name(name), root / name)
            (root / "templates").mkdir()
            for name in BUNDLED_TEMPLATE_NAMES.values():
                (root / "templates" / name).write_bytes(b"synthetic-asset")
            app_file = root / FILES[0]
            app = AppTest.from_file(str(app_file)).run(timeout=30)
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("5.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(origin.call_args.args[1]["template_routes"]["PV"], str(root / "templates" / BUNDLED_TEMPLATE_NAMES["PV"]))
            next(s for s in app.selectbox if s.label == "사용할 템플릿").set_value(TEMPLATE_ORIGIN).run(timeout=30)
            next(b for b in app.button if b.label.startswith("5.")).click().run(timeout=30)
            self.assertEqual(set(origin.call_args.args[1]["template_routes"].values()), {""})
            self.assertEqual(origin.call_args.args[3], "")
            app = AppTest.from_file(str(app_file)).run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(next(s for s in app.selectbox if s.label == "사용할 템플릿").value, TEMPLATE_ORIGIN)
            library = json.loads((root / "lab_workspace" / "template_library.json").read_text())
            self.assertEqual(len(library["templates"]), 3)

    def test_assets_register_relative_and_rebase_after_moving_to_another_computer(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            first, second = root / "computer-one", root / "computer-two"
            (first / "templates").mkdir(parents=True)
            for name in BUNDLED_TEMPLATE_NAMES.values():
                (first / "templates" / name).write_bytes(b"synthetic-asset-bytes")
            path = root / "template_library.json"
            library = load_library(path, STANDARD_TEMPLATES)
            register_bundled_templates(library, first)
            self.assertEqual(len(library["templates"]), 3)
            self.assertTrue(all(t["path"].startswith("templates/") for t in library["templates"]))
            save_library(path, library)
            shutil.copytree(first, second)
            restored = load_library(path, STANDARD_TEMPLATES)
            register_bundled_templates(restored, second)
            self.assertEqual(len(restored["templates"]), 3)
            self.assertEqual(template_routes(restored, second), {kind: str((second / "templates" / name).resolve())
                              for kind, name in BUNDLED_TEMPLATE_NAMES.items()})
            self.assertNotIn(str(first), json.dumps(restored))

    def test_absent_assets_are_not_invented_and_disabled_defaults_stay_disabled(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            library = load_library(root / "library.json", STANDARD_TEMPLATES)
            original = json.dumps(library)
            register_bundled_templates(library, root)
            self.assertEqual(json.dumps(library), original)
            library["defaults"].pop("PV")
            library["selected"] = TEMPLATE_ORIGIN
            (root / "templates").mkdir()
            (root / "templates" / BUNDLED_TEMPLATE_NAMES["PV"]).write_bytes(b"synthetic-asset")
            register_bundled_templates(library, root)
            self.assertNotIn("PV", library["defaults"])
            self.assertEqual(set(template_routes(library, root).values()), {""})

    def test_updater_copies_binary_assets_and_backs_up_existing_files_without_touching_data(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            source, target = root / "new", root / "existing"
            source.mkdir()
            target.mkdir()
            runtime = Path(__file__).resolve().parent
            for name in FILES:
                shutil.copy2(runtime / name, source / name)
            (source / "templates").mkdir()
            for name in BUNDLED_TEMPLATE_NAMES.values():
                (source / "templates" / name).write_bytes(b"synthetic-new-asset")
            old_app = target / FILES[0]
            old_app.write_bytes((runtime / FILES[0]).read_bytes())
            (target / "templates").mkdir()
            original = target / "templates" / BUNDLED_TEMPLATE_NAMES["PV"]
            original.write_bytes(b"old-asset")
            extra = target / "templates" / "Personal.otpu"
            extra.write_bytes(b"personal-asset")
            workspace = target / "lab_workspace"
            workspace.mkdir()
            db = workspace / "experiments.sqlite3"
            db.write_bytes(b"keep-database")
            backup = update_existing(old_app, source)
            self.assertEqual(original.read_bytes(), b"synthetic-new-asset")
            self.assertEqual((backup / "templates" / original.name).read_bytes(), b"old-asset")
            self.assertEqual(extra.read_bytes(), b"personal-asset")
            self.assertEqual(db.read_bytes(), b"keep-database")
            self.assertTrue(all((target / "templates" / name).is_file() for name in BUNDLED_TEMPLATE_NAMES.values()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
