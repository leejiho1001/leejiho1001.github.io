"""Explicit target/reference cohorts, independent of inferred treatment labels."""
import hashlib
import json
from collections import Counter

import pandas as pd
import streamlit as st

from db_compare import _equal, _missing
from lab_core import META_FIELDS, stable_json


def current_catalog(curves):
    rows = [{"curve_id": c.curve_id, "source_sha256": c.source.sha256, "filename": c.source.filename,
             "sheet": c.source.sheet, "label": c.spec["label"], "spec_json": stable_json(c.spec),
             **c.spec["metadata"]} for c in curves]
    return pd.DataFrame(rows, columns=["curve_id", "source_sha256", "filename", "sheet", "label", "spec_json", *META_FIELDS])


def file_groups(frame):
    groups = {}
    for row in frame.itertuples():
        key = hashlib.sha256(stable_json([row.source_sha256, row.sheet]).encode()).hexdigest()[:16]
        group = groups.setdefault(key, {"filename": row.filename, "sheet": row.sheet,
                                        "sha": row.source_sha256, "ids": []})
        group["ids"].append(row.curve_id)
    names = Counter((g["filename"], g["sheet"]) for g in groups.values())
    for group in groups.values():
        duplicate = names[(group["filename"], group["sheet"])] > 1
        suffix = f" · 원본 {group['sha'][:8]}" if duplicate else ""
        group["label"] = f"{group['filename']} / {group['sheet']} · {len(group['ids'])}곡선{suffix}"
    return groups


def preview_frame(frame):
    columns = {"filename": "파일", "sheet": "시트", "label": "범례", "treatment": "처리 조건",
               "device_id": "소자", "measurement_type": "측정", "frequency_hz": "주파수(Hz)",
               "voltage_v": "인가전압(V)", "curve_id": "곡선 ID"}
    return frame.reindex(columns=list(columns)).rename(columns=columns)


def choose_cohort(frame, role, prefix, *, default_all=True):
    signature = hashlib.sha256(stable_json(frame.curve_id.tolist()).encode()).hexdigest()[:12]
    key = prefix + "_" + signature
    groups = file_groups(frame)
    mode = st.radio(f"{role} 파일 선택 방식", ["all", "selected"], index=0 if default_all else 1,
                    format_func={"all": "전체 파일·시트", "selected": "직접 선택"}.get, horizontal=True, key=key + "_mode")
    if mode == "selected":
        files = st.multiselect(f"{role} 파일·시트 선택", list(groups), format_func=lambda fid: groups[fid]["label"],
                               placeholder="파일명으로 검색해서 선택하세요", key=key + "_files")
    else:
        files = list(groups)
    ids = {cid for fid in files for cid in groups[fid]["ids"]}
    selected = frame[frame.curve_id.isin(ids)]
    if st.checkbox(f"{role} 곡선도 직접 선택", key=key + "_individual", disabled=selected.empty):
        def label(cid):
            row = selected[selected.curve_id == cid].iloc[0]
            conditions = []
            for field, unit in (("voltage_v", "V"), ("frequency_hz", "Hz")):
                if not _missing(row[field]):
                    conditions.append(f"{float(row[field]):g} {unit}")
            return f"{row.filename} / {row.sheet} · {row.label} · {', '.join(conditions)} · {cid[:8]}"
        ids = st.multiselect(f"{role} 곡선 선택", selected.curve_id.tolist(), format_func=label,
                             placeholder="비교할 곡선을 선택하세요", key=key + "_curves")
        selected = selected[selected.curve_id.isin(ids)]
    st.caption(f"{role} 선택: {len(file_groups(selected))}개 파일·시트 / {len(selected)}개 곡선")
    with st.expander(f"{role} 선택 데이터 미리보기 ({len(selected)}곡선)"):
        st.dataframe(preview_frame(selected), hide_index=True, width="stretch")
    return selected


def _identity(row):
    spec = json.loads(row.spec_json)
    return (row.source_sha256, row.sheet, spec["start_row"], spec["end_row"], spec["x_column"], spec["y_column"])


def selection_summary(targets, references, fixed):
    # Metadata-only preview; numerical extraction and validation remain in the engine.
    target_rows = {_identity(row): row for row in targets.itertuples()}
    reference_rows = {_identity(row): row for row in references.itertuples()}
    overlaps = set(target_rows) & set(reference_rows)
    pairs, missing = 0, 0
    for identity, row in target_rows.items():
        if any(_missing(getattr(row, field)) for field in fixed):
            missing += 1
            continue
        for ref_identity, ref in reference_rows.items():
            if identity != ref_identity and all(_equal(getattr(row, f), getattr(ref, f)) for f in fixed):
                pairs += 1
    return {"target_count": len(target_rows), "reference_count": len(reference_rows),
            "overlap_count": len(overlaps), "candidate_pairs": pairs, "targets_missing_fixed_conditions": missing}
