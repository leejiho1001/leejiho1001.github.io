import ast
import tempfile
import unittest
from pathlib import Path

from update_model_menu import update_file


class UpdateTests(unittest.TestCase):
    def test_preserves_api_key_other_settings_and_backup(self):
        before = ('OPENAI_API_KEY = "SYNTHETIC_NOT_REAL"\n'
                  'with st.sidebar:\n'
                  '    workspace = "my-data"\n'
                  '    model = st.text_input("OpenAI 모델", settings.get("model", DEFAULT_MODEL))\n'
                  '    template = "my-template.otpu"\n')
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory) / "agent_origin2020_openai.py"
            app.write_text(before, encoding="utf-8")
            original = app.read_bytes()
            update_file(app)
            updated = app.read_text(encoding="utf-8")
            self.assertIn('OPENAI_API_KEY = "SYNTHETIC_NOT_REAL"', updated)
            self.assertIn('template = "my-template.otpu"', updated)
            self.assertIn("st.selectbox(", updated)
            self.assertIn("API 모델 목록 불러오기", updated)
            ast.parse(updated)
            backups = list(Path(directory).glob("*.bak"))
            self.assertEqual(len(backups), 1)
            self.assertEqual(backups[0].read_bytes(), original)
            self.assertTrue(update_file(app).startswith("Already updated"))
            self.assertEqual(len(list(Path(directory).glob("*.bak"))), 1)

    def test_unrecognized_file_is_left_unchanged(self):
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory) / "different.py"
            app.write_text('print("unrelated")\n', encoding="utf-8")
            before = app.read_bytes()
            with self.assertRaises(ValueError):
                update_file(app)
            self.assertEqual(app.read_bytes(), before)
            self.assertEqual(list(Path(directory).glob("*.bak")), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
