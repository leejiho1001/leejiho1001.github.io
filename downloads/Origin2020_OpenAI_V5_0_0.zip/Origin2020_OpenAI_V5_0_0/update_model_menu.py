# Save beside your app as update_model_menu.py, then run this file once.
# The update preserves your API key and creates a backup before changing the app.
import ast
import re
import sys
from datetime import datetime
from pathlib import Path

REPLACEMENT = r"""
# MODEL_SELECTOR_START
saved_model = str(settings.get("model", DEFAULT_MODEL)).strip() or DEFAULT_MODEL
if st.button("API 모델 목록 불러오기"):
    try:
        from openai import OpenAI
        with OpenAI(api_key=get_key(), timeout=20, max_retries=1) as api:
            catalog = [item.id for item in api.models.list()]
        # Exclude obvious image/audio/embedding models. Listing a model does
        # not prove Responses API or Structured Outputs compatibility.
        excluded = ("audio", "realtime", "transcrib", "tts", "image", "search", "instruct")
        candidates = sorted({name for name in catalog
            if name.startswith(("gpt-", "o1", "o3", "o4"))
            and not any(word in name.lower() for word in excluded)})
        if not candidates:
            raise ValueError("계정에서 텍스트 분석 모델을 찾지 못했습니다.")
        st.session_state["api_model_ids"] = candidates
        st.success(f"API 모델 {len(candidates)}개를 불러왔습니다.")
    except Exception as exc:
        st.warning(f"목록 조회 실패: {exc}. 기본 후보나 직접 입력을 사용할 수 있습니다.")
choices = list(dict.fromkeys([
    saved_model, DEFAULT_MODEL, "gpt-4.1-nano", "gpt-4.1",
    *st.session_state.get("api_model_ids", []),
]))
manual_option = "직접 입력…"
selected_model = st.selectbox(
    "OpenAI 모델", choices + [manual_option], key="openai_model_choice",
    help="실제 OpenAI API 모델 ID를 선택하세요. Codex 표시명은 API ID와 다를 수 있습니다.",
)
model = (st.text_input("모델 ID 직접 입력", value=saved_model,
         key="openai_manual_model") if selected_model == manual_option else selected_model).strip()
if not model:
    st.warning("사용할 모델 ID를 입력하세요.")
st.caption("기본 후보의 계정 접근 권한은 다를 수 있습니다. API 목록에 표시돼도 이 앱의 분석 형식 지원 여부는 모델마다 다릅니다.")
# MODEL_SELECTOR_END
"""

def update_file(path):
    path = Path(path)
    raw = path.read_bytes()
    text = raw.decode("utf-8-sig").replace("\r\n", "\n")
    if "# MODEL_SELECTOR_START" in text:
        return "Already updated: " + str(path)
    pattern = r'(?m)^([ \t]*)model = st\.text_input\("OpenAI 모델", settings\.get\("model", DEFAULT_MODEL\)\)[ \t]*$'
    match = re.search(pattern, text)
    if not match:
        raise ValueError("Original model input line not found. No files were changed.")
    indent = match.group(1)
    replacement = "\n".join(indent + line if line else "" for line in REPLACEMENT.strip().splitlines())
    updated = text[:match.start()] + replacement + text[match.end():]
    ast.parse(updated)
    backup = path.with_name(path.name + ".model-menu-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f") + ".bak")
    with backup.open("xb") as handle:
        handle.write(raw)
    newline = "\r\n" if b"\r\n" in raw else "\n"
    path.write_bytes(updated.replace("\n", newline).encode("utf-8"))
    return "Updated: " + str(path) + "\nBackup: " + str(backup)


def main():
    if len(sys.argv) > 1:
        target = Path(sys.argv[1])
    else:
        folder = Path(__file__).resolve().parent
        candidates = [folder / name for name in ("agent_origin2020_openai.py", "agent_origin2020.py")]
        target = next((p for p in candidates if p.is_file()), None)
        if target is None:
            raise SystemExit("Put this script in the same folder as agent_origin2020_openai.py.")
    print(update_file(target))
    print("Restart your Streamlit app, then click the API model list button.")

if __name__ == "__main__":
    main()
