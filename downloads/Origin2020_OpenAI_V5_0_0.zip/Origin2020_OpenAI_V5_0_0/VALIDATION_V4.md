# V5 validation — 2026-11-11

Version 5.0.0. Anonymous synthetic fixtures only; no user measurements or real API keys in the release.
The filename is retained for compatibility with existing packaging tooling.

## Automated checks

Full suite: **191 tests passed** with `PYTHONPATH=.test_deps python3 -m unittest discover -q` (Python 3.12).

- XRD shared X with calculated/measured/background signals; independent X/Y pairs with distinct grids;
  unknown XY, spectra, time-current traces, multiple Excel sheets, arbitrary saved X/Y mappings.
- Metadata/header/footer skipping with original row/column coordinates and selection CSV counts.
  Repeated values, repeated X, signed signals and acquisition order remain unchanged.
- General/no-type mode replaces the electrical-only default. An explicit XRD request overrides a stale
  sidebar PV choice and incorrect model metadata. A model can select the requested measured signal alone.
- Fifteen voltage conditions × three PV channels × 400 rows retain **45 curves and 18,000 points**.
  No IV curves enter a PV-only run. Compact inspection, bounded automatic splitting and incomplete-output
  recovery retain all selected files and channels. Explicit first/last/P2 selection still works.
- An explicit all-cycle command recovers real same-block channels omitted by a mocked model proposal,
  without broadening file/sheet/row scope. No points or synthetic mirror curves are generated.
- Original B=V+, C=V−, D=I1, E=P1 export convention and numbered voltage/response pairing remain tested.
  Other ambiguous voltage links require explicit evidence/mapping. Every selected point is audited against
  its source cell; preflight rejects stale/mixed exports before COM.
- Generic analysis covers all selected points, sample maxima, constant-background FWHM candidates, and
  signed acquisition-order integrals that do not bridge missing rows. The ten strongest measured peaks
  carry width candidates in bounded model summaries; all raw plotted points remain stored.
- PV evidence retains measured/estimated Pr±, paired 2Pr, Vc, imprint, vertical offset and explicitly
  separate single-branch/proxy values. Repeated crossings and adjacent sweep pairing are preserved.
  Current/intensity is not interpreted as polarization.
- Generic DB comparison uses matching X/Y quantities and units, without forcing voltage metadata.
  Stored XRD points remain comparable after raw files are removed; a 2× signal produces +100% maximum
  magnitude. Equal Y units with incompatible X quantities are rejected. Unknown quantities retain literal
  axis labels and units, rather than inventing conversions.
- Existing current↔DB/DB↔DB, exact cohort selection, unit conversion, duplicate/self-comparison exclusion,
  repeated-range handling, zero baselines, strict derived electrical metrics and saved history remain tested.
- Streamlit AppTest executes XRD selection despite sidebar PV, produces one overlay with all original
  repeated points, saves selection CSV, and offers generic DB metrics with no fixed voltage requirement.
- Mock Origin COM receives complete X/Y payloads and correct one/separate graph counts. Existing palette,
  legend, template/no-template fallback and diagnostic stage checks remain covered.
- Simple XRD commands bypass a redundant routing API call. Analysis caches survive follow-ups/rerenders.
  Existing production-SDK mock transport and SSE tests retain model/usage/time diagnostics and do not
  accept incomplete streams as completed answers.
- Updater includes both new runtime modules and preserves existing key/configuration, DB, .venv and
  personal templates. Portable-template registration, relocation, backup and absent-template fallback remain tested.

## Limits

Real Windows Origin 2020 is unavailable in this cloud environment. COM tests verify protocol and
payloads using mocks; they do not establish real Origin elapsed-time improvement or compatibility with
every custom OTPU. No actual user OTPU files or XRD raw TXT were supplied. The release contains a
`templates` README, not invented template binaries. No arbitrary model fitting or phase identification
was added. FWHM values are measured-point candidates, not fitted/deconvolved widths.

## V5 real-browser replay

Real Chromium used the production OpenAI Python SDK against a localhost mock Responses endpoint.
An uploaded synthetic XRD text file with three signals and a repeated X value produced one overlaid
web graph. The browser's processed Plotly trace arrays matched all 18 original points, including the
repeat. A stale sidebar PV setting was overridden by the XRD command. Selection CSV and execution
manifest recorded three curves, 18 points and original row/column selections.

A follow-up FWHM/peak question sent numerical generic evidence for all three curves, rendered the
mocked interpretation and generic table, reused the same run, and left cached numerical-file mtime
unchanged after a settings rerender. Exactly one selection request and one interpretation request
were made, with no Origin replot or external API calls. Screenshot/report are kept in the execution
workspace, not packaged as real-user evidence.
