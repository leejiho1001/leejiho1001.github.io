"""Analytical loops and incomplete measured sweeps, without external API calls."""
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as Obj
from unittest.mock import Mock, patch

from streamlit.testing.v1 import AppTest

from analysis_core import analysis_evidence, analysis_intent, numeric_markdown
from chat_agent import chat_turn
from comparison_agent import comparison_plan
from db_compare import compare_measurements, feature, DEFAULT_SETTINGS
from ferroelectric_metrics import feature_rows
from lab_core import default_plan, load_tables, materialize, ai_interpret


EXAMPLE = b"Voltage (V),Polarization (uC/cm2)\n-2,-7\n0,-2.75\n0.42,0\n2,7\n0,3.25\n-0.18,0\n-2,-7"
LOOP = b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\n0,2\n-2,-5"


class FerroelectricFeatureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def curves(self, data=EXAMPLE, name="sample_1kHz_1.4V.csv"):
        tables = load_tables([(name, data)], self.root / "raw")
        return materialize(default_plan(tables), tables)

    def test_analytical_pr_and_vc_give_2pr_6_and_imprint_point_12(self):
        curves = self.curves()
        summaries, roots, rows = analysis_evidence(curves, include_features=True)
        features = summaries[0]["loop_features"]
        self.assertAlmostEqual(features["two_pr"]["measured"]["last"], 6.)
        self.assertAlmostEqual(features["imprint"]["measured"]["last"], .12)
        self.assertAlmostEqual(features["pr_desc"]["measured"]["last"], 3.25)
        self.assertAlmostEqual(features["pr_asc"]["measured"]["last"], -2.75)
        self.assertAlmostEqual(features["vc_asc"]["measured"]["last"], .42)
        self.assertAlmostEqual(features["vc_desc"]["measured"]["last"], -.18)
        self.assertTrue(rows.evidence.map(bool).all())
        self.assertIn("source_row_start", rows)
        self.assertEqual(len(roots[roots.quantity == "y_at_x_zero"]), 2)

    def test_repeated_sweeps_are_paired_before_2pr_ranges_are_formed(self):
        data = b"Voltage (V),Polarization (uC/cm2)\n-2,-15\n0,-10\n2,15\n0,2\n-2,-15\n0,-1\n2,25\n0,20\n-2,-15"
        summaries, _ = analysis_evidence(self.curves(data))
        values = summaries[0]["loop_features"]["two_pr"]["measured"]
        self.assertEqual((values["count"], values["min"], values["max"]), (2, 12, 21))
        self.assertNotIn("mean", values)

    def test_real_zero_endpoint_is_recovered_as_estimate_without_modifying_strict_roots(self):
        data = b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\n0,2"
        summaries, roots, rows = analysis_evidence(self.curves(data), include_features=True)
        self.assertEqual(summaries[0]["y_at_x_zero"]["descending"]["count"], 0)
        value = summaries[0]["loop_features"]["two_pr"]["estimated"]
        self.assertEqual(value["last"], 3)
        self.assertIn("measured_zero_endpoint", value["methods"])
        self.assertIn("≈ 3", numeric_markdown(summaries, request="2Pr 알려줘"))

    def test_complete_sweeps_take_priority_over_unpoled_initial_and_partial_final_values(self):
        data = b"Voltage (V),Polarization (uC/cm2)\n0,99\n2,5\n0,2\n-2,-5\n0,-1\n2,5\n0,3"
        summaries, _ = analysis_evidence(self.curves(data))
        value = summaries[0]["loop_features"]["two_pr"]["measured"]
        self.assertEqual((value["min"], value["max"]), (3, 3))

    def test_near_zero_actual_samples_are_explicit_estimates_with_residuals(self):
        data = b"Voltage (V),Polarization (uC/cm2)\n0.01,-1\n1,2\n2,5\n1,4\n0.01,2"
        summaries, _, rows = analysis_evidence(self.curves(data), include_features=True)
        item = summaries[0]["loop_features"]["two_pr"]["estimated"]
        self.assertEqual(item["last"], 3)
        self.assertEqual(item["max_abs_residual"], .01)
        self.assertEqual(item["methods"], ["nearest_zero_sample"])
        self.assertTrue(all(e["row_start"] == e["row_end"] for r in rows.evidence for e in r if e["method"] == "nearest_zero_sample"))

    def test_single_branch_symmetry_reference_is_separate_and_does_not_invent_imprint(self):
        summaries, _ = analysis_evidence(self.curves(b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5"))
        features = summaries[0]["loop_features"]
        self.assertEqual(features["two_pr"]["measured"]["count"], 0)
        self.assertEqual(features["imprint"]["measured"]["count"], 0)
        self.assertEqual(features["two_pr_symmetry"]["estimated"]["last"], 2)
        self.assertIn("대칭 가정", numeric_markdown(summaries, request="대략 2Pr"))

    def test_near_p_zero_is_an_imprint_proxy_not_a_measured_crossing(self):
        data = b"Voltage (V),Polarization (uC/cm2)\n-2,0.01\n0,1\n2,5\n0,2\n-2,0.02"
        summaries, _ = analysis_evidence(self.curves(data))
        features = summaries[0]["loop_features"]
        self.assertEqual(features["imprint"]["measured"]["count"], 0)
        self.assertEqual(features["imprint_proxy"]["estimated"]["last"], -2)
        self.assertIn("임프린트 근접점 참고값", numeric_markdown(summaries, request="임프린트"))

    def test_positive_only_far_from_zero_and_gaps_do_not_produce_paired_features(self):
        for data in (b"Voltage (V),Polarization (uC/cm2)\n1,2\n2,3\n3,4\n2,3\n1,2",
                     b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\nNA,NA\n2,5\n0,2\n-2,-5"):
            summaries, _ = analysis_evidence(self.curves(data))
            self.assertEqual(summaries[0]["loop_features"]["two_pr"]["measured"]["count"], 0)
            self.assertEqual(summaries[0]["loop_features"]["imprint"]["measured"]["count"], 0)

    def test_current_cannot_produce_pr_2pr_or_imprint(self):
        curves = self.curves(EXAMPLE.replace(b"Polarization (uC/cm2)", b"Current (A)"))
        self.assertEqual(feature_rows(curves[0]), [])

    def test_all_31_curves_reach_interpreter_and_imprint_reply_uses_vc_table(self):
        files = []
        for i in range(31):
            scale = 1 + i / 10
            text = "Voltage (V),Polarization (uC/cm2)\n" + "\n".join(f"{x},{y*scale}" for x, y in ((-2,-5),(0,-1),(2,5),(0,2),(-2,-5)))
            files.append((f"device_{i}_1kHz_{1.2+.2*i:g}V.csv", text.encode()))
        tables = load_tables(files, self.root / "many")
        curves = materialize(default_plan(tables), tables)
        for i, curve in enumerate(curves):
            curve.spec["label"] = f"curve-{i:02d}"
        summaries, _ = analysis_evidence(curves)
        table = numeric_markdown(summaries, request="임프린트 알려줘")
        self.assertIn("전체 31개", table)
        self.assertIn("curve-30", table)
        self.assertIn("Vc− 후보(하강)", table)
        self.assertNotIn("| Pr+ 후보", table)
        client = Obj(responses=Obj(create=Mock(return_value=Obj(status="completed", output_text="모든 조건의 임프린트를 비교했습니다."))))
        ai_interpret(curves, "임프린트 비교", "unused", "test", client=client)
        received = [json.loads(call.kwargs["input"].split("계산된 데이터 요약:\n")[1]) for call in client.responses.create.call_args_list]
        self.assertEqual(sum(len(r["curves"]) for r in received), 31)
        self.assertTrue(all(c["loop_features"]["imprint"]["measured"]["count"] for r in received for c in r["curves"]))

    def test_imprint_requests_route_to_numerical_analysis_without_routing_api(self):
        client = Mock()
        for request in ("임프린트값 분석도 됨?", "정확하지 않아도 됨 임프린트값 줘봐", "imprint 얼마야?", "대략적인 2Pr"):
            self.assertTrue(analysis_intent(request, True))
            self.assertEqual(chat_turn([], request, {"current_curves": [{}]}, "unused", "test", client)["action"], "analyze")
        self.assertFalse(analysis_intent("임프린트의 정의가 뭐야?", True))
        client.responses.create.assert_not_called()

    def test_db_derived_metrics_match_physical_scaling_and_voltage_shift(self):
        reference = self.curves(LOOP, "baseline_1kHz_3V.csv")[0]
        data = b"Voltage (V),Polarization (uC/cm2)\n-1.2,-10\n0.8,-2\n2.8,10\n0.8,4\n-1.2,-10"
        target = self.curves(data, "target_1kHz_3V.csv")[0]
        compared = compare_measurements([target], [reference], {"metrics": ["two_pr", "imprint"]})["rows"].set_index("metric")
        # Shift affects Pr at fixed V=0, so validate imprint independently.
        self.assertAlmostEqual(compared.loc["imprint", "delta_min"], .8)
        doubled = self.curves(LOOP.replace(b"-5",b"-10").replace(b"0,-1",b"0,-2").replace(b"2,5",b"2,10").replace(b"0,2",b"0,4"), "scaled_1kHz_3V.csv")[0]
        result = compare_measurements([doubled], [reference], {"metrics": ["two_pr"]})["rows"].iloc[0]
        self.assertAlmostEqual(result.magnitude_change_percent_min, 100)
        self.assertGreater(feature(target, "imprint", DEFAULT_SETTINGS)["min"], 0)

    def test_web_imprint_question_saves_feature_evidence_without_replot(self):
        upload = io.BytesIO(EXAMPLE)
        upload.name = "synthetic_1kHz_1.4V.csv"
        client = Obj(responses=Obj(create=Mock(return_value=Obj(status="completed", output_text="임프린트는 0.12 V입니다."))))
        with patch.dict(os.environ, {"OPENAI_API_KEY": "offline-only"}), patch("streamlit.file_uploader", return_value=[upload]), patch("openai.OpenAI", return_value=client), patch("origin_adapter.plot_origin") as origin:
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(str(self.root)).run(timeout=30)
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            run_id = app.session_state["result"]["run_id"]
            app.chat_input[0].set_value("임프린트값 분석도 됨?").run(timeout=30)
            self.assertFalse(app.exception)
            answer = app.session_state["chat_messages"][-1]["content"]
            self.assertIn("0.12", answer)
            self.assertIn("Vc− 후보(하강)", answer)
            self.assertNotIn("| Pr+ 후보", answer)
            self.assertEqual(app.session_state["result"]["run_id"], run_id)
            self.assertTrue((Path(app.session_state["result"]["run_dir"]) / "analysis_features.csv").is_file())
            self.assertEqual(client.responses.create.call_count, 1)
            origin.assert_not_called()

    def test_stored_db_points_support_2pr_and_imprint_after_raw_files_are_deleted(self):
        from test_db_comparison import seed_database, planning_response
        from db_compare import compare_database
        db, _, _ = seed_database(self.root)
        for path in (self.root / "raw").iterdir():
            path.unlink()
        compared = compare_database(db, [], {"treatment": "bottom_uv"}, {"treatment": "pristine"},
                                    {"metrics": ["two_pr", "imprint"]}, target_source="db")
        result = compared["rows"].set_index("metric")
        self.assertAlmostEqual(result.loc["two_pr", "magnitude_change_percent_min"], 20)
        self.assertAlmostEqual(result.loc["imprint", "delta_min"], 0)
        client = Obj(responses=Obj(create=Mock(return_value=Obj(status="completed", output_text=json.dumps(planning_response())))))
        plan = comparison_plan(db, [], "DB의 2Pr와 임프린트 비교", "unused", "test", client=client)
        self.assertEqual(set(plan["settings"]["metrics"]), {"two_pr", "imprint"})

    def test_derived_db_metrics_convert_mv_and_polarization_area_units(self):
        from test_db_comparison import measurement
        baseline, _ = measurement(self.root, "baseline")
        converted, _ = measurement(self.root, "converted", x_unit="mV", x_scale=1000., y_unit="mC/m2", scale=10.)
        compared = compare_measurements([converted], [baseline], {"metrics": ["two_pr", "imprint"]})["rows"]
        self.assertTrue((compared.delta_min.abs() < 1e-12).all())


if __name__ == "__main__":
    unittest.main(verbosity=2)
