import copy
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from lab_features import (COLOR_DEFAULTS, add_template, classify_treatment, colors_for_curves,
                          load_library, output_stem, save_library, template_routes, requested_subset)
from lab_core import (SCHEMA, connect_db, default_plan, group_key, load_tables, materialize,
                      prepare_plan, query_curves, save_run)


class LabFeaturesTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        payload = b"Voltage (V),Polarization (uC/cm2)\n-1,-2\n0,1\n1,2\n"
        files = [(f"bottom_uv_10kHz_{state}V.csv", payload + b"\n" * state) for state in (3, 1, 2)]
        self.tables = load_tables(files, self.root / "raw")
        self.plan = default_plan(self.tables)
        self.plan["color_settings"] = dict(COLOR_DEFAULTS, mode="custom", start="#000000", end="#FFFFFF")

    def tearDown(self):
        self.temp.cleanup()

    def test_treatment_uses_explicit_names_and_preserves_unknown_conflicts(self):
        for text, expected in (("bottom_UV", "bottom_uv"), ("상부 UV", "top_uv"),
            ("pristine", "pristine"), ("bottom UV + top UV", "both_uv"),
            ("sample-unknown", None), ("pristine topUV", None)):
            self.assertEqual(classify_treatment(text), expected)
        curves = materialize(self.plan, self.tables)
        self.assertTrue(all(c.spec["metadata"]["treatment"] == "bottom_uv" for c in curves))

    def test_gradient_uses_sorted_unique_states_not_file_order(self):
        curves = materialize(self.plan, self.tables)
        colors, positions = colors_for_curves(curves, self.plan, group_key)
        by_voltage = {c.spec["metadata"]["voltage_v"]: (colors[c.curve_id], positions[c.curve_id]) for c in curves}
        self.assertEqual(by_voltage, {1.: ("#000000", 0.), 2.: ("#808080", .5), 3.: ("#FFFFFF", 1.)})
        self.plan["color_settings"]["reverse"] = True
        reversed_colors, _ = colors_for_curves(curves, self.plan, group_key)
        self.assertEqual(reversed_colors[curves[0].curve_id], "#000000")
        self.assertEqual(curves[0].data.x.tolist(), [-1, 0, 1])

    def test_colormap_and_rainbow_endpoints_and_native_preview(self):
        curves = materialize(self.plan, self.tables)
        self.plan["color_settings"].update(mode="rainbow", reverse=False)
        colors, _ = colors_for_curves(curves, self.plan, group_key)
        self.assertEqual(colors[curves[1].curve_id], "#FF0000")
        self.assertEqual(colors[curves[0].curve_id], "#9400D3")
        self.plan["color_settings"].update(mode="colormap", colormap="Viridis")
        colors, _ = colors_for_curves(curves, self.plan, group_key)
        self.assertEqual(len(set(colors.values())), 3)
        self.plan["color_settings"]["mode"] = "origin"
        colors, positions = colors_for_curves(curves, self.plan, group_key)
        self.assertEqual(set(colors.values()), {"#808080"})
        self.assertEqual(set(positions.values()), {0., .5, 1.})

    def test_same_data_different_condition_names_are_not_discarded(self):
        data = b"V,I\n0,1\n1,2\n"
        tables = load_tables([("pristine.csv", data), ("topUV.csv", data)], self.root / "same")
        self.assertEqual(len(tables), 2)
        self.assertNotEqual(tables[0].source_id, tables[1].source_id)
        self.assertEqual(len(list((self.root / "same").iterdir())), 1)

    def test_template_registry_appends_and_restores_role_defaults(self):
        pv, iv = self.root / "PV.otpu", self.root / "IV.otpu"
        pv.write_bytes(b"template")
        iv.write_bytes(b"template")
        path = self.root / "library.json"
        library = load_library(path)
        add_template(library, "my-PV", "PV", pv)
        add_template(library, "my-IV", "IV", iv)
        save_library(path, library)
        loaded = load_library(path)
        self.assertEqual(len(loaded["templates"]), 2)
        self.assertEqual(template_routes(loaded), {"PV": str(pv), "IV": str(iv)})
        with self.assertRaises(ValueError):
            add_template(loaded, "my-PV", "PV", iv)
        self.assertEqual(len(load_library(path)["templates"]), 2)

    def test_file_name_is_meaningful_safe_and_customizable(self):
        curves = materialize(self.plan, self.tables)
        self.assertIn("10kHz", output_stem(curves))
        self.assertIn("1-3V", output_stem(curves))
        self.assertEqual(output_stem(curves, "{measurement}_{frequency}"), "PV_10kHz")
        for c in curves:
            c.spec["metadata"]["device_id"] = "../../device:1"
        name = output_stem(curves, "{device}")
        self.assertNotIn("/", name)
        self.assertNotIn(":", name)
        self.assertNotIn("\\", name)

    def test_existing_database_migrates_without_losing_records(self):
        path = self.root / "old.sqlite3"
        with sqlite3.connect(path) as con:
            con.executescript(SCHEMA.replace(", treatment TEXT", ""))
            con.execute("INSERT INTO runs(run_id,request,plan_json) VALUES('old','keep','{}')")
        curves = materialize(self.plan, self.tables)
        save_run(path, "new", "PV only", self.plan, curves)
        rows = query_curves(path, {"treatment": "bottom_uv"})
        self.assertEqual(len(rows), 3)
        with sqlite3.connect(path) as con:
            self.assertEqual(con.execute("SELECT request FROM runs WHERE run_id='old'").fetchone()[0], "keep")

    def test_legacy_plan_without_treatment_is_accepted(self):
        for spec in self.plan["curves"]:
            spec["metadata"].pop("treatment")
        prepared = prepare_plan(self.plan, self.tables)
        self.assertTrue(all(s["metadata"]["treatment"] == "bottom_uv" for s in prepared["curves"]))

    def test_explicit_multistate_and_frequency_scope_removes_unrequested_curves(self):
        plan = prepare_plan(self.plan, self.tables)
        extra = copy.deepcopy(plan["curves"][0])
        extra["metadata"]["voltage_v"] = 4.
        plan["curves"].append(extra)
        selected = requested_subset(plan, "10kHz 조건에서 1.0~3.0V 멀티스테이트만 그려줘")
        self.assertEqual(len(selected["curves"]), 3)
        self.assertTrue(all(s["metadata"]["voltage_v"] <= 3 for s in selected["curves"]))
        selected = requested_subset(plan, "20kHz만 그려줘")
        self.assertEqual(selected["curves"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
