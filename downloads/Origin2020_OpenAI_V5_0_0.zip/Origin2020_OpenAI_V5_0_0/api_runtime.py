"""Streaming and bounded API diagnostics; never record prompts, keys or raw data."""
from contextvars import ContextVar
from contextlib import suppress
from datetime import datetime, timezone
from time import perf_counter
from urllib.parse import urlsplit


_observer = ContextVar("lab_api_observer", default=None)


def observe_api(callback):
    return _observer.set(callback)


def _plain(obj, name, expected):
    value = obj.get(name) if isinstance(obj, dict) else getattr(obj, name, None)
    return value if type(value) is expected else None


def response_call(client, operation, *, on_delta=None, **kwargs):
    start, first_text, response, stream = perf_counter(), None, None, None
    record = {"operation": operation, "requested_model": kwargs.get("model"),
              "utc": datetime.now(timezone.utc).isoformat(), "status": "error"}
    host = urlsplit(str(getattr(client, "base_url", ""))).hostname
    if host:
        record["api_host"] = host
    try:
        if on_delta is None:
            response = client.responses.create(**kwargs)
        else:
            stream = client.responses.create(**kwargs, stream=True)
            # A completed response is also supported for injected/offline clients.
            if isinstance(getattr(stream, "output_text", None), str):
                response = stream
                first_text = perf_counter() - start
                on_delta(response.output_text)
            else:
                for event in stream:
                    if event.type == "response.output_text.delta":
                        if first_text is None:
                            first_text = perf_counter() - start
                        on_delta(event.delta)
                    elif event.type in ("response.completed", "response.incomplete", "response.failed"):
                        response = event.response
                    elif event.type == "error":
                        raise RuntimeError("API 스트림 오류가 발생했습니다. 부분 응답은 완료 결과로 저장하지 않습니다.")
                if response is None:
                    raise RuntimeError("API 연결이 완료 응답 없이 끝났습니다. 부분 응답은 완료 결과로 저장하지 않습니다.")
        record.update(status=_plain(response, "status", str) or "received",
                      response_model=_plain(response, "model", str),
                      response_id=_plain(response, "id", str),
                      request_id=_plain(response, "_request_id", str))
        headers = getattr(getattr(stream, "response", None), "headers", None)
        if not record["request_id"] and headers is not None:
            request_id = headers.get("x-request-id")
            if isinstance(request_id, str):
                record["request_id"] = request_id
        usage = getattr(response, "usage", None)
        record["usage"] = {key: _plain(usage, key, int) for key in ("input_tokens", "output_tokens", "total_tokens")}
        return response
    except Exception as exc:
        record["error_type"] = type(exc).__name__
        raise
    finally:
        record.update(seconds=round(perf_counter() - start, 3),
                      first_text_seconds=round(first_text, 3) if first_text is not None else None)
        if stream is not None and callable(getattr(stream, "close", None)):
            with suppress(Exception):
                stream.close()
        observer = _observer.get()
        if observer is not None:
            try:
                observer(record)
            except Exception:
                pass  # Diagnostics must not turn a completed result into an error.
