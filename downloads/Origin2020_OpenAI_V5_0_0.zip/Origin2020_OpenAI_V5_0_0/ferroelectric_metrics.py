"""P-V loop features from ordered measurements, with explicit estimate provenance."""
import math
import re
from plot_rules import axis_info


ENGINE_VERSION = "pv-features-1"
FEATURES = ("pr_desc", "pr_asc", "two_pr", "vc_desc", "vc_asc", "imprint", "p_offset", "two_pr_symmetry", "imprint_proxy")


def sweep_segments(data):
    """Split at actual voltage reversals and missing source rows; never sort points."""
    x, rows = data.x.to_numpy(), data.source_row.to_numpy()
    segments, start, direction, block = [], 0, 0, 0
    tolerance = max(float(max(x) - min(x)) * 1e-12, 1e-15)
    for i in range(1, len(x)):
        if rows[i] - rows[i - 1] != 1:
            if i - 1 > start and direction:
                segments.append(dict(start=start, end=i - 1, direction=direction, block=block))
            start, direction, block = i, 0, block + 1
            continue
        delta = x[i] - x[i - 1]
        sign = 1 if delta > tolerance else -1 if delta < -tolerance else 0
        if sign and direction and sign != direction:
            segments.append(dict(start=start, end=i - 1, direction=direction, block=block))
            start = i - 1
        if sign:
            direction = sign
    if len(x) - 1 > start and direction:
        segments.append(dict(start=start, end=len(x) - 1, direction=direction, block=block))
    for number, segment in enumerate(segments):
        view = data.iloc[segment["start"]:segment["end"] + 1]
        segment.update(number=number, full=float(view.x.min()) < 0 < float(view.x.max()))
    return segments


def _zero_candidate(data, segment, inverse=False):
    start, end = segment["start"], segment["end"]
    view = data.iloc[start:end + 1]
    target = view.y.to_numpy() if inverse else view.x.to_numpy()
    output = view.x.to_numpy() if inverse else view.y.to_numpy()
    direct, approximate = [], []
    def item(value, left, right, method, quality, residual=0.):
        return dict(value=float(value), row_start=int(view.source_row.iloc[left]),
                    row_end=int(view.source_row.iloc[right]), method=method, quality=quality,
                    residual=float(residual))
    for i in range(len(view)):
        if target[i] == 0:
            before, after = i - 1, i + 1
            while before >= 0 and target[before] == 0:
                before -= 1
            while after < len(target) and target[after] == 0:
                after += 1
            if before >= 0 and after < len(target) and target[before] * target[after] < 0:
                direct.append(item(output[i], i, i, "exact_zero", "measured"))
            elif start + i in (0, len(data) - 1):
                approximate.append(item(output[i], i, i, "measured_zero_endpoint", "estimated"))
        if i and target[i - 1] * target[i] < 0:
            fraction = -target[i - 1] / (target[i] - target[i - 1])
            direct.append(item(output[i - 1] + fraction * (output[i] - output[i - 1]),
                               i - 1, i, "adjacent_interpolation", "measured"))
    if direct:
        return direct
    if approximate:
        return approximate
    # A measured near-zero sample is a declared proxy, never an extrapolated root.
    # V-near-zero is admitted only at a real recording endpoint; P-near-zero
    # needs a small residual relative to this sweep's measured P range.
    closest = min(range(len(target)), key=lambda i: abs(float(target[i])))
    span = float(max(target) - min(target))
    near = span > 0 and abs(float(target[closest])) <= .02 * span
    endpoint = start + closest in (0, len(data) - 1)
    if near and (inverse or endpoint):
        return [item(output[closest], closest, closest, "nearest_zero_sample", "estimated", target[closest])]
    return []


def _row(metric, candidates, pair, segments, data, *, reason=""):
    values = [v["value"] for v in candidates]
    return dict(metric=metric, pair=pair, sweeps=[s["number"] + 1 for s in segments],
                source_row_start=int(data.source_row.iloc[segments[0]["start"]]),
                source_row_end=int(data.source_row.iloc[segments[-1]["end"]]),
                low=min(values) if values else None, high=max(values) if values else None,
                quality="estimated" if any(v["quality"] == "estimated" for v in candidates) else "measured" if values else "unavailable",
                reason=reason, evidence=candidates)


def _combine(metric, a, b, pair, segments, data):
    if not a or not b:
        return _row(metric, [], pair, segments, data, reason="반대 스윕의 영점 근거가 부족합니다.")
    a0, a1 = min(v["value"] for v in a), max(v["value"] for v in a)
    b0, b1 = min(v["value"] for v in b), max(v["value"] for v in b)
    if metric == "two_pr":
        lo, hi = a0 - b1, a1 - b0
        low, high = (0. if lo <= 0 <= hi else min(abs(lo), abs(hi))), max(abs(lo), abs(hi))
    else:
        low, high = (a0 + b0) / 2, (a1 + b1) / 2
    row = _row(metric, a + b, pair, segments, data)
    row.update(low=low, high=high)
    if metric == "imprint" and any(e["method"] == "nearest_zero_sample" for e in a + b):
        row.update(metric="imprint_proxy", reason="P=0 교차가 없어 영점 근접 측정점의 전압을 사용한 참고값입니다.")
    return row


def feature_rows(curve):
    xkind = axis_info(curve.spec["x_name"], curve.spec["x_unit"])[0]
    ykind = axis_info(curve.spec["y_name"], curve.spec["y_unit"])[0]
    if xkind not in ("voltage", "field") or ykind != "polarization":
        return []
    data, rows = curve.data, []
    segments = sweep_segments(data)
    candidates = {s["number"]: {"pr": _zero_candidate(data, s), "vc": _zero_candidate(data, s, True)} for s in segments}
    full_pairs, i = [], 0
    while i + 1 < len(segments):
        a, b = segments[i:i + 2]
        if a["full"] and b["full"] and a["block"] == b["block"] and a["end"] == b["start"]:
            full_pairs.append((a, b))
            i += 2
        else:
            i += 1
    pairs = full_pairs
    if not pairs:
        # Prefer the end of the recording over an unpoled initial zero sample.
        adjacent = [(a, b) for a, b in zip(segments, segments[1:])
                    if a["block"] == b["block"] and a["end"] == b["start"]]
        def score(pair):
            evidence = [e for s in pair for values in candidates[s["number"]].values() for e in values]
            return (sum(e["quality"] == "measured" for e in evidence),
                    sum(s["full"] for s in pair), pair[0]["start"] > 0, pair[-1]["end"])
        used, chosen = set(), []
        for pair in sorted(adjacent, key=score, reverse=True):
            if not used.intersection(s["number"] for s in pair):
                chosen.append(pair)
                used.update(s["number"] for s in pair)
        pairs = sorted(chosen, key=lambda p: p[0]["start"])
    used = set()
    for pair_id, pair in enumerate(pairs, 1):
        used.update(s["number"] for s in pair)
        by_direction = {s["direction"]: s for s in pair}
        if set(by_direction) != {-1, 1}:
            continue
        down, up = candidates[by_direction[-1]["number"]], candidates[by_direction[1]["number"]]
        for metric, evidence in (("pr_desc", down["pr"]), ("pr_asc", up["pr"]),
                                 ("vc_desc", down["vc"]), ("vc_asc", up["vc"])):
            rows.append(_row(metric, evidence, pair_id, pair, data))
        for metric, quantity in (("two_pr", "pr"), ("p_offset", "pr"), ("imprint", "vc")):
            rows.append(_combine(metric, down[quantity], up[quantity], pair_id, pair, data))
    for segment in segments:
        if segment["number"] in used:
            continue
        suffix = "desc" if segment["direction"] == -1 else "asc"
        for quantity, prefix in (("pr", "pr"), ("vc", "vc")):
            rows.append(_row(prefix + "_" + suffix, candidates[segment["number"]][quantity], None, [segment], data))
    if not any(r["metric"] == "two_pr" and r["low"] is not None for r in rows):
        pr_rows = [r for r in rows if r["metric"] in ("pr_desc", "pr_asc") and r["low"] is not None]
        if len({r["metric"] for r in pr_rows}) == 1:
            for original in pr_rows:
                proxy = dict(original, metric="two_pr_symmetry", quality="estimated",
                             reason="단일 분지만 존재합니다. 반대 분지가 대칭이라는 가정의 2×|P(0)| 참고값입니다.")
                lo, hi = original["low"], original["high"]
                proxy.update(low=0. if lo <= 0 <= hi else 2 * min(abs(lo), abs(hi)), high=2 * max(abs(lo), abs(hi)))
                rows.append(proxy)
    for row in rows:
        row.update(unit=curve.spec["x_unit"] if row["metric"].startswith(("vc_", "imprint")) else curve.spec["y_unit"],
                   curve_id=curve.curve_id, label=curve.spec["label"], filename=curve.source.filename,
                   sheet=curve.source.sheet, x_column=curve.spec["x_column"], y_column=curve.spec["y_column"],
                   **curve.spec["metadata"])
    return rows


def feature_summary(rows):
    result = {}
    for metric in FEATURES:
        item = {}
        for quality in ("measured", "estimated"):
            selected = [r for r in rows if r["metric"] == metric and r["quality"] == quality and r["low"] is not None]
            last = selected[-1] if selected else None
            if not selected:
                item[quality] = {"count": 0}
                continue
            item[quality] = dict(count=len(selected), min=min(r["low"] for r in selected),
                                 max=max(r["high"] for r in selected) if selected else None,
                                 last=last["low"] if last and last["low"] == last["high"] else None,
                                 methods=sorted({e["method"] for r in selected for e in r["evidence"]}))
            if quality == "estimated":
                item[quality]["max_abs_residual"] = max((abs(e["residual"]) for r in selected for e in r["evidence"]), default=0.)
        result[metric] = item
    return result


def format_stat(stats):
    if not stats or not stats.get("count"):
        return "—"
    if stats["min"] == stats["max"]:
        return f"{stats['min']:.6g}"
    return f"{stats['min']:.6g} ~ {stats['max']:.6g} ({stats['count']}개)"


def display_feature(summary, metric):
    item = summary.get("loop_features", {}).get(metric, {})
    measured, estimated = item.get("measured", {}), item.get("estimated", {})
    if measured.get("count"):
        return format_stat(measured)
    return "≈ " + format_stat(estimated) if estimated.get("count") else "—"


def feature_markdown(summaries, request="", max_rows=None):
    imprint = bool(re.search(r"imprint|임프린|v[_ ]?(?:im|off)|전압\s*(?:오프셋|편이)", request, re.I))
    pr = bool(re.search(r"(?<![a-z])p[_ ]?r(?![a-z])|잔류|분극", request, re.I))
    vc = bool(re.search(r"[ve][_ ]?c|항전|보자력", request, re.I))
    p_offset = bool(re.search(r"분극\s*(?:수직\s*)?오프셋", request))
    if p_offset and not imprint:
        metrics = [("Pr+ 후보", "pr_desc"), ("Pr− 후보", "pr_asc"), ("분극 수직 오프셋", "p_offset")]
    elif imprint and not pr:
        metrics = [("Vc− 후보(하강)", "vc_desc"), ("Vc+ 후보(상승)", "vc_asc"), ("임프린트", "imprint")]
    elif pr and not imprint and not vc:
        metrics = [("Pr+ 후보(하강)", "pr_desc"), ("Pr− 후보(상승)", "pr_asc"), ("2Pr", "two_pr")]
    elif vc and not pr and not imprint:
        metrics = [("Vc− 후보(하강)", "vc_desc"), ("Vc+ 후보(상승)", "vc_asc")]
    else:
        metrics = [("Pr+ 후보", "pr_desc"), ("Pr− 후보", "pr_asc"), ("2Pr", "two_pr"),
                   ("Vc− 후보", "vc_desc"), ("Vc+ 후보", "vc_asc"), ("임프린트", "imprint")]
    def order(s):
        meta = s["metadata"]
        return (str(meta.get("device_id") or ""), str(meta.get("treatment") or ""),
                meta.get("frequency_hz") if meta.get("frequency_hz") is not None else math.inf,
                meta.get("voltage_v") if meta.get("voltage_v") is not None else math.inf, s["label"])
    selected = sorted(summaries, key=order)[:max_rows]
    lines = [f"선택한 전체 {len(summaries)}개 P–V 곡선의 P(0) / Pr 후보 · 2Pr · 임프린트 계산입니다.", "",
             "| 곡선·측정 조건 | " + " | ".join(label for label, _ in metrics) + " | P 단위 / X 단위 |",
             "|---|" + "---:|" * len(metrics) + "---|"]
    for s in selected:
        label = s["label"].replace("|", "\\|").replace("\n", " ")
        meta = s["metadata"]
        conditions = []
        for key, unit in (("frequency_hz", "Hz"), ("voltage_v", "V")):
            if meta.get(key) is not None:
                conditions.append(f"{meta[key]:g} {unit}")
        if conditions:
            label += " · " + ", ".join(conditions)
        lines.append("| " + label + " | " + " | ".join(display_feature(s, metric) for _, metric in metrics)
                     + f" | {s['y_unit'] or '미확인'} / {s['x_unit'] or '미확인'} |")
    if any(s["loop_features"]["two_pr_symmetry"]["estimated"].get("count") for s in selected):
        lines += ["", "단일 분지의 **대칭 가정 참고값 2×|P(0)|** (측정된 2Pr와 구분):"]
        for s in selected:
            if s["loop_features"]["two_pr_symmetry"]["estimated"].get("count"):
                lines.append(f"- {s['label']}: {display_feature(s, 'two_pr_symmetry')} {s['y_unit']}")
    if any(s["loop_features"]["imprint_proxy"]["estimated"].get("count") for s in selected):
        lines += ["", "**임프린트 근접점 참고값** (P=0이 아닌 근접 측정점의 전압으로 계산):"]
        for s in selected:
            if s["loop_features"]["imprint_proxy"]["estimated"].get("count"):
                residual = s["loop_features"]["imprint_proxy"]["estimated"]["max_abs_residual"]
                lines.append(f"- {s['label']}: {display_feature(s, 'imprint_proxy')} {s['x_unit']} · 영점 잔차 최대 {residual:.6g} {s['y_unit']}")
    lines += ["", "2Pr = |P(0)하강 − P(0)상승|, 임프린트 = (Vc상승 + Vc하강)/2입니다. 인접 반대 스윕쌍별로 계산하며 반복 쌍은 범위로 표시합니다.",
              "≈는 끝점의 실제 0 측정값 또는 영점에 가까운 측정점을 사용한 근사입니다. 영점 근접 대용값은 해당 스윕의 축 범위 2% 이내에만 적용합니다. 원본 행·잔차·방법은 특성 CSV에 기록합니다.",
              "—는 그 지표에 필요한 반대 스윕/영점 근거가 부족한 항목입니다. 계산되는 다른 지표는 위에 표시합니다. 포화·누설 기여가 확인되기 전에는 Pr·Vc 후보와 루프 이동으로 해석합니다."]
    return "\n".join(lines)
