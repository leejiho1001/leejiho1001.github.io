"""Read-only analysis of actual plotted points; all fixtures are synthetic."""
import copy
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from streamlit.testing.v1 import AppTest

from analysis_core import analysis_evidence, analysis_intent, numeric_markdown
from chat_agent import chat_turn
from lab_core import ai_interpret, default_plan, load_tables, materialize


LOOP = b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\n0,2\n-2,-5\n"


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def curves(self, content=LOOP):
        tables = load_tables([("device_3V.csv", content)], self.root / "raw")
        plan = default_plan(tables)
        return materialize(plan, tables)

    def test_exact_zero_branches_have_real_p_values_not_pmax(self):
        curves = self.curves()
        summaries, rows = analysis_evidence(curves)
        one = summaries[0]
        self.assertEqual(one["y_at_x_zero"]["ascending"]["last"], -1)
        self.assertEqual(one["y_at_x_zero"]["descending"]["last"], 2)
        self.assertEqual(one["y_max"], 5)
        self.assertEqual(one["y_unit"], "uC/cm2")
        zeros = rows[rows.quantity == "y_at_x_zero"]
        self.assertEqual(zeros.source_row_start.tolist(), [3, 5])
        self.assertEqual(zeros.direction.tolist(), ["ascending", "descending"])
        self.assertAlmostEqual(one["x_at_y_zero"]["ascending"]["last"], 1/3)
        self.assertAlmostEqual(one["x_at_y_zero"]["descending"]["last"], -4/7)

    def test_linear_crossing_keeps_original_source_row_bracket(self):
        content = b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n-1,-3\n1,1\n2,5\n1,4\n-1,-2\n-2,-5"
        summaries, rows = analysis_evidence(self.curves(content))
        p0 = rows[rows.quantity == "y_at_x_zero"]
        self.assertEqual(p0.value.tolist(), [-1, 1])
        self.assertEqual(p0.method.tolist(), ["linear", "linear"])
        self.assertEqual(p0.source_row_start.tolist(), [3, 6])
        self.assertEqual(p0.source_row_end.tolist(), [4, 7])

    def test_startup_endpoint_and_touch_are_kept_separately_not_called_pr(self):
        content = b"Voltage (V),Polarization (uC/cm2)\n0,99\n2,5\n0,2\n-2,-5\n0,-1\n2,5\n0,3"
        summaries, rows = analysis_evidence(self.curves(content))
        one = summaries[0]
        self.assertEqual(one["y_at_x_zero"]["descending"]["last"], 2)
        self.assertEqual(one["y_at_x_zero"]["ascending"]["last"], -1)
        self.assertEqual(one["unclassified_y_at_x_zero"], {"count": 2, "min": 3, "max": 99, "last": 3})
        self.assertEqual(len(rows[rows.quantity == "y_at_x_zero"]), 4)
        _, touched = analysis_evidence(self.curves(b"Voltage (V),Polarization (uC/cm2)\n1,3\n0,2\n1,4"))
        self.assertEqual(touched[touched.quantity == "y_at_x_zero"].direction.tolist(), ["touch"])

    def test_no_interpolation_across_missing_rows_and_no_extrapolation(self):
        content = b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n-1,-3\n0,NA\n1,1\n2,5"
        summaries, rows = analysis_evidence(self.curves(content))
        self.assertTrue(rows.empty)
        self.assertEqual(summaries[0]["y_at_x_zero"]["ascending"]["count"], 0)
        summaries, _ = analysis_evidence(self.curves(b"Voltage (V),Polarization (uC/cm2)\n1,2\n2,4\n3,5"))
        self.assertEqual(summaries[0]["y_at_x_zero"]["descending"]["count"], 0)

    def test_repeated_branches_report_range_without_cycle_averaging(self):
        content = b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\n0,2\n-2,-5\n0,-2\n2,6\n0,3\n-2,-6"
        summaries, _ = analysis_evidence(self.curves(content))
        one = summaries[0]
        self.assertEqual(one["y_at_x_zero"]["descending"], {"count": 2, "min": 2, "max": 3, "last": 3})
        self.assertNotIn("mean", one["y_at_x_zero"]["ascending"])
        self.assertIn("2 ~ 3 (2개)", numeric_markdown(summaries))

    def test_iv_is_not_presented_as_remanent_polarization(self):
        curves = self.curves(LOOP.replace(b"Polarization (uC/cm2)", b"Current (A)"))
        summaries, _ = analysis_evidence(curves)
        self.assertFalse(summaries[0]["remanence_candidates_available"])
        self.assertNotIn("Pr 후보", numeric_markdown(summaries))

    def test_pr_question_routes_to_analysis_without_a_router_model_call(self):
        client = Mock()
        context = {"current_curves": [{"curve_id": "already-plotted"}]}
        for request in ("pr값 어떤것 같아?", "Pr 얼마야?", "Ec도 봐줘", "이 그래프 분석해줘"):
            answer = chat_turn([], request, context, "offline", "test", client)
            self.assertEqual(answer["action"], "analyze")
            self.assertEqual(answer["task"], request)
        client.responses.create.assert_not_called()
        self.assertFalse(analysis_intent("Pr의 정의가 뭐야?", True))
        self.assertFalse(analysis_intent("Pr값은 무엇을 의미해?", True))
        self.assertFalse(analysis_intent("Pr 비교 그래프 그려줘", True))
        self.assertFalse(analysis_intent("Pr 얼마야?", False))

    def test_interpreter_receives_computed_values_units_and_branch_directions(self):
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text="현재 루프의 두 분지 값이 비대칭입니다."))))
        curves = self.curves()
        before = curves[0].data.copy()
        answer = ai_interpret(curves, "pr값 어떤것 같아?", "offline", "test", client=client)
        sent = client.responses.create.call_args.kwargs
        payload = json.loads(sent["input"].split("계산된 데이터 요약:\n", 1)[1])
        self.assertTrue(payload["data_available"])
        self.assertEqual(payload["curves"][0]["y_at_x_zero"]["descending"]["last"], 2)
        self.assertEqual(payload["curves"][0]["y_unit"], "uC/cm2")
        self.assertIn("P(0) / Pr 후보", answer)
        self.assertIn("비대칭", answer)
        self.assertTrue(before.equals(curves[0].data))

    def test_many_cycles_send_compact_statistics_instead_of_all_crossing_arrays(self):
        curve = self.curves()[0]
        curve.metrics["y_at_x_zero"] *= 300
        curves = []
        for i in range(100):
            item = copy.copy(curve)
            item.curve_id = f"synthetic-curve-{i}"
            curves.append(item)
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text="분할 수치 요약을 확인했습니다."))))
        ai_interpret(curves, "현재 그래프 Pr 분석", "offline", "test", client=client)
        total = 0
        for call in client.responses.create.call_args_list:
            text = call.kwargs["input"].split("계산된 데이터 요약:\n", 1)[1]
            self.assertLess(len(text), 90_000)
            total += len(json.loads(text)["curves"])
        self.assertEqual(total, 100)


class AnalysisWebRegressionTests(unittest.TestCase):
    def test_pr_question_uses_current_run_without_replotting_and_saves_evidence(self):
        upload = io.BytesIO(LOOP)
        upload.name = "device_3V.csv"
        client = Mock()
        client.responses.create.return_value = SimpleNamespace(status="completed", output_text="하강 분지 P(0)는 2, 상승 분지는 -1 uC/cm2입니다.")
        stale_answer = {"action": "answer", "reply": "0V 부근 데이터를 다시 보내주세요.", "task": ""}
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("streamlit.file_uploader", return_value=[upload]), patch("chat_agent.chat_turn", return_value=stale_answer), patch("openai.OpenAI", return_value=client), patch("origin_adapter.plot_origin") as origin, patch("lab_core.ai_plan") as planner:
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(folder).run()
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            self.assertFalse(app.error)
            run_id = app.session_state["result"]["run_id"]
            data = app.session_state["result"]["curves"][0].data.copy()
            app.session_state["app_version"] = "4.0.1"
            app.run(timeout=30)  # compatible live update retains the plotted points
            self.assertEqual(app.session_state["result"]["run_id"], run_id)
            app.chat_input[0].set_value("pr값 어떤것 같아?").run(timeout=30)
            self.assertFalse(app.exception)
            answer = app.session_state["chat_messages"][-1]["content"]
            self.assertIn("P(0) / Pr 후보", answer)
            self.assertNotIn("다시 보내주세요", answer)
            result = app.session_state["result"]
            self.assertEqual(result["run_id"], run_id)
            self.assertTrue(data.equals(result["curves"][0].data))
            self.assertEqual(len(list(Path(folder).glob("runs/*"))), 1)
            evidence = Path(result["run_dir"])
            self.assertTrue((evidence / "analysis_values.csv").is_file())
            self.assertTrue((evidence / "analysis_summary.json").is_file())
            self.assertEqual((evidence / "analysis.md").read_text(), app.session_state["interpretation"])
            sent = json.loads(client.responses.create.call_args.kwargs["input"].split("계산된 데이터 요약:\n", 1)[1])
            self.assertEqual(sent["curves"][0]["y_at_x_zero"]["ascending"]["last"], -1)
            client.responses.create.side_effect = RuntimeError("synthetic connection failure")
            app.chat_input[0].set_value("Pr 다시 분석해줘").run(timeout=30)
            answer = app.session_state["chat_messages"][-1]["content"]
            self.assertIn("P(0) / Pr 후보", answer)
            self.assertIn("AI 해석에 실패", answer)
            self.assertEqual(app.session_state["result"]["run_id"], run_id)
            origin.assert_not_called()
            planner.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
