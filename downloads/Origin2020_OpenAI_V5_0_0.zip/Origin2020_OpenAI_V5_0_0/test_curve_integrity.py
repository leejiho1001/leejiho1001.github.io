import copy
import tempfile
import unittest
from pathlib import Path

from curve_integrity import source_point_audit
from lab_core import default_plan, load_tables, materialize


class CurveIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def load(self, text, name="source.csv"):
        tables = load_tables([(name, text.encode())], self.root / "raw")
        plan = default_plan(tables)
        plan["measurement"] = "PV"
        return tables, plan

    def test_same_y_against_opposite_x_channels_is_blocked(self):
        tables, plan = self.load("V1 (V),V2 (V),Polarization (uC/cm2)\n-1,1,-2\n0,0,1\n2,-2,4\n")
        additional = copy.deepcopy(plan["curves"][0])
        additional.update(x_column="B", label="second X")
        plan["curves"].append(additional)
        before = copy.deepcopy(plan)
        with self.assertRaisesRegex(ValueError, "X열 중복 연결|전압열 대응 불명확"):
            materialize(plan, tables)
        self.assertEqual(plan, before)

    def test_opposite_y_channels_from_same_rows_are_blocked_not_deleted(self):
        tables, plan = self.load("Voltage (V),P1 (uC/cm2),P2 (uC/cm2)\n-1,-2,2\n0,1,-1\n2,4,-4\n")
        self.assertEqual(len(plan["curves"]), 2)
        with self.assertRaisesRegex(ValueError, "반전 채널"):
            materialize(plan, tables)
        self.assertEqual(len(plan["curves"]), 2)

    def test_explicit_manual_comparison_is_preserved(self):
        tables, plan = self.load("Voltage (V),P1 (uC/cm2),P2 (uC/cm2)\n-1,-2,2\n0,1,-1\n2,4,-4\n")
        plan["measurement"] = "manual"
        curves = materialize(plan, tables)
        self.assertEqual(len(curves), 2)
        self.assertEqual(curves[1].data.y.tolist(), [2, -1, -4])

    def test_asymmetric_source_values_and_acquisition_order_are_preserved(self):
        text = "Voltage (V),Polarization (uC/cm2)\n-.21,-1.73\n.08,.91\n.74,3.61\n1.16,6.43\n.62,4.28\n-.03,.37\n-.34,-1.19\n"
        tables, plan = self.load(text)
        curves = materialize(plan, tables)
        self.assertEqual(curves[0].data.x.tolist(), [-.21, .08, .74, 1.16, .62, -.03, -.34])
        self.assertEqual(curves[0].data.y.tolist(), [-1.73, .91, 3.61, 6.43, 4.28, .37, -1.19])
        audit = source_point_audit(curves)
        self.assertEqual(audit.source_row.tolist(), list(range(2, 9)))
        self.assertEqual(audit.x_column.unique().tolist(), ["A"])
        curves[0].data.loc[0, "y"] *= -1
        with self.assertRaisesRegex(ValueError, "원본과 플롯 데이터"):
            source_point_audit(curves)

    def test_non_mirrored_multiple_y_channels_are_still_supported(self):
        tables, plan = self.load("Voltage (V),P1 (uC/cm2),P2 (uC/cm2)\n-1,-2,2\n0,1,4\n2,4,7\n")
        self.assertEqual(len(materialize(plan, tables)), 2)

    def test_explicitly_different_device_conditions_are_not_silently_removed(self):
        tables, plan = self.load("Voltage (V),P1 (uC/cm2),P2 (uC/cm2)\n-1,-2,2\n0,1,-1\n2,4,-4\n")
        for spec, treatment in zip(plan["curves"], ("pristine", "bottom_uv")):
            spec["metadata"]["treatment"] = treatment
        self.assertEqual(len(materialize(plan, tables)), 2)

    def test_separate_cycle_row_ranges_are_preserved(self):
        tables, plan = self.load("Voltage (V),P1 (uC/cm2)\n-1,-2\n0,1\n2,4\n-1,2\n0,-1\n2,-4\n")
        first = plan["curves"][0]
        second = copy.deepcopy(first)
        first.update(start_row=2, end_row=4)
        second.update(start_row=5, end_row=7, label="cycle 2")
        plan["curves"] = [first, second]
        self.assertEqual(len(materialize(plan, tables)), 2)

    def test_mirror_test_respects_small_current_scale(self):
        tables, plan = self.load("Voltage (V),I1 (A),I2 (A)\n-1,-2e-12,2e-12\n0,1e-12,-1e-12\n2,4e-12,-4e-12\n")
        plan["measurement"] = "IV"
        with self.assertRaisesRegex(ValueError, "반전 채널"):
            materialize(plan, tables)


if __name__ == "__main__":
    unittest.main(verbosity=2)
