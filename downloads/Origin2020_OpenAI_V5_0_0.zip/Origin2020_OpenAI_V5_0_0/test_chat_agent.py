import json
import unittest
from types import SimpleNamespace
from unittest.mock import Mock

from chat_agent import chat_turn


class ChatAgentTests(unittest.TestCase):
    def test_question_keeps_conversation_and_returns_read_only_action(self):
        response = {"action": "answer", "reply": "네, 전압이 X축입니다.", "task": ""}
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text=json.dumps(response)))))
        history = [{"role": "user", "content": "PV를 그리고 싶어"}, {"role": "assistant", "content": "조건을 알려주세요."}]
        answer = chat_turn(history, "전압이 가로축이지?", {"selected_sources": []}, "fake", "fake", client)
        self.assertEqual(answer["action"], "answer")
        sent = json.loads(client.responses.create.call_args.kwargs["input"])
        self.assertEqual(len(sent["history"]), 2)
        self.assertEqual(sent["current_request"], "전압이 가로축이지?")

    def test_incomplete_and_invalid_actions_are_rejected(self):
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="incomplete", output_text="{}"))))
        with self.assertRaises(ValueError):
            chat_turn([], "plot", {}, "fake", "fake", client)
        client.responses.create.return_value = SimpleNamespace(status="completed", output_text=json.dumps({"action": "delete", "reply": "x", "task": "x"}))
        with self.assertRaises(ValueError):
            chat_turn([], "plot", {}, "fake", "fake", client)


if __name__ == "__main__":
    unittest.main(verbosity=2)
