@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 exit /b 1
py -3.12 apply_plot_update.py
if errorlevel 1 (
    echo Update failed. Copy the error above. Do not delete your existing installation.
    pause
    exit /b 1
)
pause
