@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 exit /b 1
if not exist ".venv\Scripts\python.exe" (
    echo Run 01_install.bat first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m streamlit run agent_origin2020_openai.py --server.address 127.0.0.1
if errorlevel 1 (
    echo The app stopped with an error. Copy the error above.
    pause
    exit /b 1
)
