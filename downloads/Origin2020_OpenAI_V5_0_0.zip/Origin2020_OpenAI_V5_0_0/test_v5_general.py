"""V5 command/data preservation regressions. All measurement fixtures are synthetic."""
import copy
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pandas as pd
from streamlit.testing.v1 import AppTest

from analysis_core import analysis_evidence, analysis_intent, numeric_markdown
from chat_agent import chat_turn
from curve_integrity import source_point_audit
from data_selector import selection_report
from db_compare import compare_measurements, compare_database
from generic_analysis import generic_evidence
from lab_core import ai_plan, default_plan, load_tables, materialize, prepare_plan, group_key, save_run
from plot_rules import axis_info, request_options
from v4_selection import constrain_plan, export_preflight


def xrd_data(scale=1):
    rows = ["Instrument: anonymous XRD", "sample: synthetic", "2Theta [deg]\tCalc. data [counts]\tMeasured [counts]\tBackground [counts]"]
    for x, y in [(20, 0), (21, 2), (22, 4), (22, 4), (23, 2), (24, 0)]:
        rows.append(f"{x}\t{y*scale}\t{y*scale+1}\t0.5")
    rows.append("End of measurement")
    return "\n".join(rows).encode()


class GeneralSelectorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def select(self, content=None, request="XRD 그려줘", name="sample.txt"):
        tables = load_tables([(name, content or xrd_data())], self.root / "raw")
        plan = prepare_plan(constrain_plan(default_plan(tables), tables, request, measurement="general"), tables)
        return tables, plan, materialize(plan, tables)

    def test_shared_x_keeps_all_y_repeated_points_and_skips_only_metadata(self):
        tables, plan, curves = self.select()
        self.assertEqual([(c.spec['x_column'], c.spec['y_column']) for c in curves], [('A','B'),('A','C'),('A','D')])
        self.assertEqual({c.spec['metadata']['measurement_type'] for c in curves}, {'XRD'})
        self.assertEqual(len({group_key(c, plan) for c in curves}), 1)
        for curve in curves:
            self.assertEqual(curve.data.source_row.tolist(), list(range(4,10)))
            self.assertEqual(curve.data.x.tolist(), [20,21,22,22,23,24])
        self.assertEqual(curves[0].data.y.tolist(), [0,2,4,4,2,0])
        report = selection_report(curves)
        self.assertEqual(report['선택 점'].tolist(), [6,6,6])
        self.assertEqual(report['앞에서 스킵한 행'].tolist(), [3,3,3])
        self.assertEqual(report['뒤에서 스킵한 행'].tolist(), [1,1,1])
        self.assertEqual(len(source_point_audit(curves)), 18)
        export_preflight(curves, plan)

    def test_independent_pairs_keep_distinct_x_grids_and_signed_y(self):
        data = b'2Theta [deg],Calc [counts],2Theta [deg],Measured [counts],2Theta [deg],Background [counts]\n20,1,30,-1,40,0\n21,2,31,-2,41,1\n22,1,32,-1,42,0'
        _, _, curves = self.select(data)
        self.assertEqual([(c.spec['x_column'],c.spec['y_column']) for c in curves], [('A','B'),('C','D'),('E','F')])
        self.assertEqual([c.data.x.tolist() for c in curves], [[20,21,22],[30,31,32],[40,41,42]])
        self.assertEqual(curves[1].data.y.tolist(), [-1,-2,-1])

    def test_unknown_xy_and_separate_mode_do_not_drop_repeated_channels(self):
        _, plan, curves = self.select(b'X1,Y1,X2,Y2\n3,1,8,2\n2,4,9,5\n2,4,9,5\n1,2,10,3', '따로 그려줘')
        self.assertEqual(len(curves),2)
        self.assertEqual([c.data.x.tolist() for c in curves], [[3,2,2,1],[8,9,9,10]])
        self.assertEqual(len({group_key(c,plan) for c in curves}),2)

    def test_time_current_and_spectra_do_not_require_voltage(self):
        _,_,curves = self.select(b'Time [s],Current [A],I2 [A]\n0,1,-1\n1,2,-2\n2,3,-3', '시간 응답 그려줘')
        self.assertEqual(len(curves),2)
        self.assertEqual({c.spec['metadata']['measurement_type'] for c in curves},{'TimeSeries'})
        _,_,curves = self.select(b'Wavelength [nm],Absorbance [a.u.]\n500,.2\n600,.4\n700,.1', '스펙트럼 그려줘', 'spectrum.csv')
        self.assertEqual(curves[0].spec['metadata']['measurement_type'],'Spectrum')

    def test_literal_generic_mapping_can_choose_any_numeric_x(self):
        tables = load_tables([('generic.csv',b'Index,Time [s],Signal\n0,10,4\n1,20,5\n2,30,6')],self.root/'mapping')
        mapping=[{'source_id':tables[0].source_id,'start_row':2,'end_row':4,'x_column':'B','y_column':'C'}]
        plan=default_plan(tables)
        plan['curves']=[s for s in plan['curves'] if s['y_column']=='C']
        curves=materialize(constrain_plan(plan,tables,'일반 데이터',measurement='general',mappings=mapping),tables)
        self.assertEqual(curves[0].data.x.tolist(),[10,20,30])

    def test_multiple_excel_sheets_keep_all_selected_curves(self):
        buffer=io.BytesIO()
        with pd.ExcelWriter(buffer,engine='openpyxl') as writer:
            for sheet in ('raw','treated'):
                pd.DataFrame([['2Theta [deg]','Intensity [counts]'],[20,1],[21,2],[22,1]]).to_excel(writer,sheet_name=sheet,header=False,index=False)
        tables=load_tables([('all.xlsx',buffer.getvalue())],self.root/'sheets')
        plan=constrain_plan(default_plan(tables),tables,'XRD',measurement='general')
        self.assertEqual({c.source.sheet for c in materialize(plan,tables)},{'raw','treated'})

    def test_xrd_request_overrides_previous_pv_and_wrong_model_metadata(self):
        tables,plan,_=self.select()
        plan['measurement']='PV'
        for spec in plan['curves']:
            spec['metadata']['measurement_type']='PV'
        corrected=constrain_plan(plan,tables,'XRD 그려줘',measurement='PV')
        self.assertEqual(len(materialize(corrected,tables)),3)
        self.assertEqual(corrected['measurement'],'XRD')
        self.assertEqual(request_options('XRD 그려줘')['measurement'],'XRD')

    def test_api_selects_requested_signal_without_forcing_other_columns(self):
        tables,proposal,_=self.select()
        proposal['curves']=[s for s in proposal['curves'] if s['y_column']=='C']
        client=SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status='completed',output_text=json.dumps(proposal)))))
        plan=ai_plan(tables,'XRD 측정 강도만 그려줘. 계산값과 배경은 빼줘','offline','test',client=client)
        self.assertEqual([(c.spec['x_column'],c.spec['y_column']) for c in materialize(plan,tables)],[('A','C')])
        kwargs=client.responses.create.call_args.kwargs
        self.assertIn('Calc. data',kwargs['input'])
        schema=kwargs['text']['format']['schema']
        self.assertIn('general',schema['properties']['measurement']['enum'])
        self.assertIn('XRD',schema['properties']['measurement']['enum'])

    def test_first_channel_only_when_explicitly_requested(self):
        tables,plan,curves=self.select()
        self.assertEqual(len(curves),3)
        selected=materialize(constrain_plan(plan,tables,'XRD 첫 번째 채널만'),tables)
        self.assertEqual(len(selected),1)
        self.assertEqual(selected[0].spec['y_column'],'B')

    def test_multistate_repeated_electrical_channels_remain_by_default(self):
        from test_large_inspection import condition_files
        tables=load_tables(condition_files(3),self.root/'states')
        plan=constrain_plan(default_plan(tables),tables,'PV만 한 그래프에')
        curves=materialize(plan,tables)
        self.assertEqual(len(curves),9)
        self.assertEqual(sum(len(c.data) for c in curves),3600)
        self.assertEqual({c.spec['y_column'] for c in curves},{'E','G','I'})
        self.assertEqual(len({group_key(c,plan) for c in curves}),1)

    def test_all_cycles_command_restores_real_channels_omitted_by_model(self):
        from test_dual_voltage_export import original_export_data
        tables=load_tables([('device_1kHz_2V.dat',original_export_data())],self.root/'allcycles')
        proposed=default_plan(tables)
        proposed['curves']=[s for s in proposed['curves'] if s['y_column']=='E']
        client=SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status='completed',output_text=json.dumps(proposed)))))
        plan=ai_plan(tables,'PV만 모든 사이클 한 그래프에 그려줘','offline','test',client=client)
        curves=materialize(plan,tables)
        self.assertEqual({c.spec['y_column'] for c in curves},{'E','G','I'})
        self.assertEqual(sum(len(c.data) for c in curves),24)
        self.assertEqual({c.spec['metadata']['measurement_type'] for c in curves},{'PV'})

    def test_generic_analysis_uses_every_point_and_never_pr(self):
        _,_,curves=self.select()
        summaries,_=analysis_evidence(curves)
        stats=summaries[0]['generic_statistics']
        self.assertEqual(stats['n_points'],6)
        self.assertEqual((stats['peak_x_min'],stats['peak_x_max']),(22,22))
        self.assertEqual(stats['peak_width'],2)
        self.assertEqual(stats['raw_area'],8)
        self.assertFalse(summaries[0]['remanence_candidates_available'])
        report=numeric_markdown(summaries)
        self.assertIn('FWHM 후보',report)
        self.assertNotIn('Pr',report)
        self.assertTrue(analysis_intent('피크 위치랑 FWHM 구해줘', True))

    def test_generic_area_does_not_bridge_row_gap(self):
        _,_,curves=self.select(b'Time [s],Signal,Aux\n0,1,0\n1,1,0\n2,NA,0\n3,1,0\n4,1,0','일반 데이터')
        curve=curves[0]
        stats,_=generic_evidence(curve)
        self.assertEqual((stats['segments'],stats['raw_area']),(2,2))
        self.assertEqual(curve.data.source_row.tolist(),[2,3,5,6])

    def test_unitless_2theta_stays_unitless_and_i_au_is_intensity(self):
        _,_,curves=self.select(b'2theta,I [a.u.]\n20,1\n21,2\n22,1')
        self.assertEqual(curves[0].spec['x_unit'],'')
        self.assertEqual(axis_info(curves[0].spec['y_name'],curves[0].spec['y_unit'])[0],'intensity')

    def test_simple_xrd_command_avoids_redundant_routing_call(self):
        client=Mock()
        result=chat_turn([], 'XRD 그려줘', {'selected_sources':['source']},'offline','test',client)
        self.assertEqual(result['action'],'plot')
        client.responses.create.assert_not_called()

    def test_generic_db_compares_saved_points_after_raw_files_removed(self):
        tables,plan,refs=self.select(xrd_data(),name='baseline.txt')
        tables2,plan2,targets=self.select(xrd_data(2),name='treated.txt')
        db=self.root/'experiments.sqlite3'
        save_run(db,'base','XRD',plan,refs)
        save_run(db,'new','XRD',plan2,targets)
        for table in tables+tables2:
            Path(table.path).unlink(missing_ok=True)
        settings={'metrics':['y_max','peak_x'],'fixed_fields':[],'group_by':[]}
        result=compare_database(db,[],settings=settings,target_source='db',target_ids=[targets[0].curve_id],reference_ids=[refs[0].curve_id])
        self.assertEqual(len(result['rows']),2)
        maximum=result['rows'][result['rows'].metric=='y_max'].iloc[0]
        self.assertEqual((maximum.target_min,maximum.reference_min,maximum.magnitude_change_percent_min),(8,4,100))
        self.assertEqual(result['features'].point_count.tolist(),[6,6,6,6])

    def test_generic_db_rejects_same_unit_with_incompatible_x_quantity(self):
        _,_,refs=self.select()
        _,_,targets=self.select(xrd_data(2),name='second.txt')
        targets[0].spec['x_name']='Time'
        result=compare_measurements(targets[:1],refs[:1],{'metrics':['y_max'],'fixed_fields':[],'group_by':[]})
        self.assertTrue(result['rows'].empty)
        self.assertTrue(result['excluded'].reason.str.contains('물리량/단위').any())


class GeneralOriginAndWebTests(unittest.TestCase):
    def test_mock_origin_receives_all_xrd_points_with_one_or_separate_graphs(self):
        import test_origin_adapter as protocol
        harness=protocol.OriginProtocolTests()
        harness.setUp()
        try:
            tables=load_tables([('xrd.txt',xrd_data())],harness.root/'xrd')
            harness.plan=constrain_plan(default_plan(tables),tables,'XRD 한 그래프에')
            harness.curves=materialize(harness.plan,tables)
            result=harness.run_plot()
            self.assertEqual((result['curve_count'],result['graph_count']),(3,1))
            self.assertEqual(harness.origin.PutWorksheet.call_args_list[0].args[1],[20,21,22,22,23,24])
            self.assertEqual(harness.origin.PutWorksheet.call_args_list[1].args[1],[0,2,4,4,2,0])
            harness.origin.PutWorksheet.reset_mock()
            (harness.root/'result.opju').unlink()
            harness.plan['plot_mode']='separate'
            self.assertEqual(harness.run_plot()['graph_count'],3)
            self.assertEqual(harness.origin.PutWorksheet.call_count,6)
        finally:
            harness.tearDown()

    def test_web_xrd_request_overrides_sidebar_pv_and_exports_selection(self):
        upload=io.BytesIO(xrd_data()); upload.name='synthetic_xrd.txt'
        def proposal(tables,*args,**kwargs):
            return default_plan(tables)
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ,{'OPENAI_API_KEY':'offline-test-only'}), patch('streamlit.file_uploader',return_value=[upload]), patch('lab_core.ai_plan',side_effect=proposal), patch('origin_adapter.plot_origin',return_value={}) as origin:
            app=AppTest.from_file(str(Path(__file__).with_name('agent_origin2020_openai.py'))).run(timeout=30)
            app.sidebar.text_input[0].set_value(folder).run()
            next(s for s in app.selectbox if s.label=='요청에 종류가 없을 때').set_value('PV').run()
            app.chat_input[0].set_value('XRD 그려줘').run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            result=app.session_state['result']
            self.assertEqual(len(result['curves']),3)
            self.assertEqual(len(app.get('plotly_chart')),1)
            origin.assert_called_once()
            self.assertEqual(len(origin.call_args.args[0]),3)
            selection=pd.read_csv(Path(result['run_dir'])/'data_selection.csv')
            self.assertEqual(selection['선택 점'].tolist(),[6,6,6])
            self.assertEqual(next(s for s in app.multiselect if s.label=='비교할 특성').value,['y_max','peak_x'])
            self.assertEqual(next(s for s in app.multiselect if s.label=='같게 맞출 측정 조건').value,[])


if __name__=='__main__':
    unittest.main(verbosity=2)
