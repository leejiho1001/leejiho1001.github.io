"""Synthetic DB controls exercise scientific matching and real saved points."""
import copy
import io
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pandas as pd
from streamlit.testing.v1 import AppTest

from comparison_agent import comparison_plan, explain_comparison
from db_compare import (compare_measurements, compare_database, catalog, filter_catalog,
    feature, DEFAULT_SETTINGS, save_comparison, comparison_excel, comparison_intent,
    comparison_history, load_comparison, update_comparison_report)
from lab_core import META_FIELDS, default_plan, load_tables, materialize, save_run


def measurement(root, name, scale=1., treatment="pristine", frequency=1000., voltage=3.,
                x_unit="V", y_unit="uC/cm2", x_scale=1., temperature=None, points=None):
    points = points or [(-2, -5), (0, -1), (2, 5), (0, 2), (-2, -5)]
    y_name = "Polarization" if "C/" in y_unit else "Current"
    text = "Measurement " + name + f"\nVoltage ({x_unit}),{y_name} ({y_unit})\n"
    text += "\n".join(f"{x*x_scale},{y*scale}" for x, y in points)
    tables = load_tables([(name + ".csv", text.encode())], root / "raw")
    plan = default_plan(tables)
    spec = plan["curves"][0]
    spec["metadata"].update(treatment=treatment, voltage_v=voltage, frequency_hz=frequency,
        temperature_c=temperature, device_stack="shared-stack", device_id=name)
    spec["label"] = name
    curves = materialize(plan, tables)
    return curves[0], plan


def seed_database(root):
    db = root / "experiments.sqlite3"
    baseline, bp = measurement(root, "pristine-control")
    target, tp = measurement(root, "bottom-uv-target", scale=1.2, treatment="bottom_uv")
    save_run(db, "control-run", "control", bp, [baseline])
    save_run(db, "target-run", "target", tp, [target])
    return db, target, baseline


def planning_response():
    target = {key: None for key in META_FIELDS}
    reference = dict(target)
    target["treatment"] = "bottom_uv"
    reference["treatment"] = "pristine"
    return {"target_source": "db", "target_filters": target, "reference_filters": reference,
        **copy.deepcopy(DEFAULT_SETTINGS), "notes": ["같은 전압·주파수의 기준군과 비교"]}


class DBComparisonTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.db, self.target, self.baseline = seed_database(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_signed_negative_pr_and_magnitude_change_are_distinct(self):
        result = compare_measurements([self.target], [self.baseline])
        rows = result["rows"].set_index("metric")
        self.assertAlmostEqual(rows.loc["p0_desc", "delta_min"], .4)
        self.assertAlmostEqual(rows.loc["p0_asc", "delta_min"], -.2)
        self.assertAlmostEqual(rows.loc["p0_desc", "magnitude_change_percent_min"], 20)
        self.assertAlmostEqual(rows.loc["p0_asc", "magnitude_change_percent_min"], 20)
        self.assertEqual(set(rows.unit), {"uC/cm2"})
        both = compare_measurements([self.target], [self.baseline], {"metrics": ["p0_desc", "p0_asc", "vc_desc", "vc_asc"]})["rows"].set_index("metric")
        self.assertAlmostEqual(both.loc["vc_asc", "delta_min"], 0)
        self.assertAlmostEqual(both.loc["vc_desc", "delta_min"], 0)

    def test_different_voltage_frequency_and_missing_fixed_fields_do_not_match(self):
        wrong_f, _ = measurement(self.root, "other-frequency", frequency=10000)
        wrong_v, _ = measurement(self.root, "other-voltage", voltage=4)
        result = compare_measurements([self.target], [wrong_f, wrong_v])
        self.assertTrue(result["rows"].empty)
        self.target.spec["metadata"]["frequency_hz"] = None
        result = compare_measurements([self.target], [self.baseline])
        self.assertTrue(result["rows"].empty)
        self.assertTrue(result["excluded"].reason.str.contains("고정 조건 미확인").any())

    def test_units_convert_polarization_and_voltage_without_changing_points(self):
        baseline, _ = measurement(self.root, "SI-control", scale=10, y_unit="mC/m2", x_unit="mV", x_scale=1000)
        before = baseline.data.copy()
        result = compare_measurements([self.target], [baseline], {"metrics": ["p0_desc", "vc_asc"]})
        rows = result["rows"].set_index("metric")
        self.assertAlmostEqual(rows.loc["p0_desc", "reference_min"], 2)
        self.assertAlmostEqual(rows.loc["p0_desc", "magnitude_change_percent_min"], 20)
        self.assertAlmostEqual(rows.loc["vc_asc", "reference_min"], 1/3)
        self.assertEqual(rows.loc["vc_asc", "unit"], "V")
        self.assertTrue(before.equals(baseline.data))

    def test_current_at_explicit_voltage_uses_both_branches_and_native_mv_units(self):
        ref, _ = measurement(self.root, "iv-control", y_unit="uA", x_unit="mV", x_scale=1000)
        target, _ = measurement(self.root, "iv-target", scale=1.2, y_unit="uA", treatment="bottom_uv")
        settings = {"metrics": ["i_v_asc", "i_v_desc"], "probe_voltage_v": 1.}
        result = compare_measurements([target], [ref], settings)
        rows = result["rows"].set_index("metric")
        self.assertAlmostEqual(rows.loc["i_v_asc", "reference_min"], 2e-6)
        self.assertAlmostEqual(rows.loc["i_v_desc", "reference_min"], 3.5e-6)
        self.assertAlmostEqual(rows.loc["i_v_desc", "magnitude_change_percent_min"], 20)
        self.assertEqual(set(rows.unit), {"A"})
        self.assertTrue(compare_measurements([target], [ref], {**settings, "probe_voltage_v": 10})["rows"].empty)

    def test_current_and_current_density_are_not_compared_as_one_quantity(self):
        ref, _ = measurement(self.root, "density", y_unit="A/cm2")
        target, _ = measurement(self.root, "current", y_unit="A")
        result = compare_measurements([target], [ref], {"metrics": ["i_v_desc"]})
        self.assertTrue(result["rows"].empty)
        self.assertTrue(result["excluded"].reason.str.contains("물리량/단위").any())

    def test_self_and_style_copies_do_not_create_false_baselines_or_extra_samples(self):
        copy_of_target = copy.deepcopy(self.target)
        copy_of_target.curve_id = "new-legend-same-measurement"
        copy_of_control = copy.deepcopy(self.baseline)
        copy_of_control.curve_id = "new-style-same-measurement"
        result = compare_measurements([self.target], [self.target, copy_of_target, self.baseline, copy_of_control])
        self.assertEqual(len(result["rows"]), 2)
        self.assertEqual(set(result["rows"].reference_count), {1})
        self.assertEqual(len(result["excluded"]), 3)

    def test_zero_baseline_has_defined_difference_and_no_infinite_percent(self):
        ref, _ = measurement(self.root, "zero-control", points=[(-2, -5), (0, -1), (2, 5), (0, 0), (-2, -5)])
        result = compare_measurements([self.target], [ref], {"metrics": ["p0_desc"]})
        row = result["rows"].iloc[0]
        self.assertAlmostEqual(row.delta_min, 2.4)
        self.assertIsNone(row.magnitude_change_percent_min)
        self.assertEqual(row.status, "baseline_includes_zero_percent_undefined")

    def test_control_in_current_multicondition_plot_remains_a_control_for_other_targets(self):
        result = compare_measurements([self.baseline, self.target], [self.baseline])
        self.assertEqual(set(result["rows"].target_id), {self.target.curve_id})
        self.assertEqual(len(result["rows"]), 2)

    def test_tiny_current_values_survive_json_report_without_rounding_to_zero(self):
        from db_compare import result_payload
        ref, _ = measurement(self.root, "tiny-reference", scale=1e-20, y_unit="A")
        target, _ = measurement(self.root, "tiny-target", scale=1.2e-20, y_unit="A")
        result = compare_measurements([target], [ref], {"metrics": ["i_v_desc"]})
        row = result_payload(result)["rows"][0]
        self.assertAlmostEqual(row["reference_min"] / 1e-20, 3.5)
        self.assertNotEqual(row["target_min"], 0)

    def test_reference_range_and_explicit_median_have_different_documented_results(self):
        ref2, _ = measurement(self.root, "second-control", scale=2)
        target, _ = measurement(self.root, "large-target", scale=3)
        ranged = compare_measurements([target], [self.baseline, ref2], {"metrics": ["p0_desc"]})["rows"].iloc[0]
        self.assertEqual((ranged.reference_min, ranged.reference_max), (2, 4))
        self.assertEqual((ranged.delta_min, ranged.delta_max), (2, 4))
        self.assertAlmostEqual(ranged.magnitude_change_percent_min, 50)
        self.assertAlmostEqual(ranged.magnitude_change_percent_max, 200)
        median = compare_measurements([target], [self.baseline, ref2], {"metrics": ["p0_desc"], "reference_mode": "median"})["rows"].iloc[0]
        self.assertEqual(median.reference_min, 3)
        self.assertAlmostEqual(median.magnitude_change_percent_min, 100)

    def test_multiple_crossings_are_not_averaged_and_median_requires_single_value(self):
        points = [(-2,-5),(0,-1),(2,5),(0,2),(-2,-5),(0,-2),(2,6),(0,4),(-2,-6)]
        ref, _ = measurement(self.root, "many-cycles", points=points)
        ranged = compare_measurements([self.target], [ref], {"metrics": ["p0_desc"]})["rows"].iloc[0]
        self.assertEqual((ranged.reference_min, ranged.reference_max), (2, 4))
        last = feature(ref, "p0_desc", {**DEFAULT_SETTINGS, "value_mode": "last"})
        self.assertEqual((last["min"], last["max"]), (4, 4))
        result = compare_measurements([self.target], [ref], {"metrics": ["p0_desc"], "reference_mode": "median"})
        self.assertTrue(result["rows"].empty)

    def test_different_temperatures_remain_separate_reference_groups(self):
        hot, _ = measurement(self.root, "hot-control", scale=2, temperature=100)
        room, _ = measurement(self.root, "room-control", temperature=25)
        result = compare_measurements([self.target], [hot, room], {"metrics": ["p0_desc"]})
        self.assertEqual(len(result["rows"]), 2)
        self.assertEqual(set(result["rows"].reference_min), {2, 4})
        self.assertTrue(all("temperature_c" in text for text in result["rows"].reference_group))

    def test_db_only_works_without_raw_files_and_preserves_measurement_tables(self):
        for path in (self.root / "raw").glob("*"):
            path.unlink()
        with sqlite3.connect(self.db) as con:
            original = (con.execute("SELECT COUNT(*) FROM curves").fetchone()[0], con.execute("SELECT COUNT(*) FROM points").fetchone()[0])
        result = compare_database(self.db, [], {"treatment": "bottom_uv"}, {"treatment": "pristine"}, target_source="db")
        self.assertEqual(len(result["rows"]), 2)
        self.assertAlmostEqual(result["rows"].iloc[0].magnitude_change_percent_min, 20)
        with sqlite3.connect(self.db) as con:
            self.assertEqual(original, (con.execute("SELECT COUNT(*) FROM curves").fetchone()[0], con.execute("SELECT COUNT(*) FROM points").fetchone()[0]))
            self.assertIsNone(con.execute("SELECT name FROM sqlite_master WHERE name='comparison_runs'").fetchone())
        folder = save_comparison(self.db, self.root, "Pr 비교", result)
        self.assertTrue((folder / "comparison.xlsx").is_file())
        self.assertEqual(len(pd.ExcelFile(io.BytesIO(comparison_excel(result))).sheet_names), 4)
        with sqlite3.connect(self.db) as con:
            self.assertEqual(con.execute("SELECT COUNT(*) FROM comparison_runs").fetchone()[0], 1)
            self.assertEqual(con.execute("SELECT COUNT(*) FROM curves").fetchone()[0], 2)
        self.assertEqual(json.loads((folder / "comparison.json").read_text())["settings"]["value_mode"], "range")
        update_comparison_report(self.db, result["comparison_id"], "실제 수치에 근거한 저장된 비교 해석")
        loaded = load_comparison(self.db, result["comparison_id"])
        self.assertTrue(loaded["historical_snapshot"])
        self.assertEqual(loaded["report"], "실제 수치에 근거한 저장된 비교 해석")
        self.assertEqual(len(comparison_history(self.db)), 1)
        self.assertEqual(len(loaded["rows"]), 2)

    def test_catalog_filters_are_literal_and_cannot_execute_sql(self):
        self.assertTrue(filter_catalog(catalog(self.db), {"device_id": "' OR 1=1; DROP TABLE curves; --"}).empty)
        self.assertEqual(len(catalog(self.db)), 2)
        with self.assertRaises(ValueError):
            filter_catalog(catalog(self.db), {"sql": "anything"})

    def test_planner_restores_same_voltage_frequency_guards_and_read_only_route(self):
        plan = planning_response()
        plan["fixed_fields"] = []
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text=json.dumps(plan)))))
        actual = comparison_plan(self.db, [], "DB의 Bottom UV와 Pristine Pr 비교", "offline", "test", client=client)
        self.assertEqual(set(actual["settings"]["fixed_fields"]), {"voltage_v", "frequency_hz"})
        self.assertEqual(actual["reference_filters"], {"treatment": "pristine"})
        actual_both = comparison_plan(self.db, [], "DB의 Pr와 Vc 모두 비교", "offline", "test", client=client)
        self.assertEqual(set(actual_both["settings"]["metrics"]), {"p0_desc", "p0_asc", "vc_desc", "vc_asc"})
        from chat_agent import chat_turn
        client.responses.create.reset_mock()
        self.assertEqual(chat_turn([], "현재 Pr을 DB의 Pristine과 비교해줘", {}, "offline", "test", client)["action"], "compare")
        client.responses.create.assert_not_called()

    def test_comparison_interpreter_uses_only_computed_numbers(self):
        result = compare_measurements([self.target], [self.baseline])
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text="두 분지의 크기가 기준 대비 20% 증가했습니다."))))
        text = explain_comparison(result, "Pr 비교", "offline", "test", client=client)
        sent = json.loads(client.responses.create.call_args.kwargs["input"])
        self.assertAlmostEqual(sent["computed_comparisons"][0]["magnitude_change_percent_min"], 20)
        self.assertIn("20%", text)


class DBComparisonWebTests(unittest.TestCase):
    def test_db_only_comparison_without_uploads_or_api_key(self):
        with tempfile.TemporaryDirectory() as folder, patch("openai.OpenAI") as api:
            root = Path(folder)
            db, _, _ = seed_database(root)
            for path in (root / "raw").glob("*"):
                path.unlink()
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(folder).run()
            next(b for b in app.button if b.label == "조건을 맞춰 DB 비교 분석").click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            result = app.session_state["comparison_result"]
            self.assertEqual(len(result["rows"]), 2)
            self.assertAlmostEqual(result["rows"].iloc[0].magnitude_change_percent_min, 20)
            api.assert_not_called()
            with sqlite3.connect(db) as con:
                self.assertEqual(con.execute("SELECT COUNT(*) FROM comparison_runs").fetchone()[0], 1)
                self.assertEqual(con.execute("SELECT COUNT(*) FROM curves").fetchone()[0], 2)

    def test_natural_db_comparison_without_upload_reaches_filters_and_numeric_interpretation(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            db, _, _ = seed_database(root)
            def respond(**kwargs):
                if "text" in kwargs:
                    return SimpleNamespace(status="completed", output_text=json.dumps(planning_response()))
                sent = json.loads(kwargs["input"])
                assert abs(sent["computed_comparisons"][0]["magnitude_change_percent_min"] - 20) < 1e-9
                return SimpleNamespace(status="completed", output_text="동일 조건에서 Pr 후보 크기가 20% 증가했습니다.")
            client = Mock()
            client.responses.create.side_effect = respond
            with patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("openai.OpenAI", return_value=client), patch("origin_adapter.plot_origin") as origin:
                app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
                app.sidebar.text_input[0].set_value(folder).run()
                app.chat_input[0].set_value("DB의 Bottom UV와 Pristine의 Pr을 같은 전압 주파수에서 비교해줘").run(timeout=30)
                self.assertFalse(app.exception)
                self.assertIn("20% 증가", app.session_state["chat_messages"][-1]["content"])
                self.assertEqual(len(app.session_state["comparison_result"]["rows"]), 2)
                self.assertEqual(client.responses.create.call_count, 2)
                origin.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
