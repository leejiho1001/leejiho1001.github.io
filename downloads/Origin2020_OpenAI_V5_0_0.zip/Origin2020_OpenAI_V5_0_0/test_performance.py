"""No paid calls: streaming transport, reuse, routing and COM round-trip regressions."""
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as Obj
from unittest.mock import Mock, patch

import httpx
from openai import OpenAI
from streamlit.testing.v1 import AppTest

from api_runtime import observe_api, response_call
from chat_agent import chat_turn
from lab_core import default_plan, load_tables, materialize
import test_origin_adapter


def completed():
    return {"id": "resp_offline_speed", "object": "response", "created_at": 0,
            "status": "completed", "model": "reported-model",
            "output": [{"id": "msg_offline", "type": "message", "status": "completed", "role": "assistant",
                        "content": [{"type": "output_text", "text": "분지 값은 -1과 2입니다.", "annotations": []}]}],
            "parallel_tool_calls": False, "tools": [], "tool_choice": "auto",
            "usage": {"input_tokens": 321, "output_tokens": 12, "total_tokens": 333}}


class APIPerformanceTests(unittest.TestCase):
    def test_real_sdk_sse_emits_text_before_completion_and_records_actual_model_usage(self):
        records, deltas, sent = [], [], []
        def respond(request):
            sent.append(json.loads(request.content))
            events = [{"type": "response.output_text.delta", "delta": "분지 값은 ", "sequence_number": 0,
                       "item_id": "msg_offline", "output_index": 0, "content_index": 0},
                      {"type": "response.output_text.delta", "delta": "-1과 2입니다.", "sequence_number": 1,
                       "item_id": "msg_offline", "output_index": 0, "content_index": 0},
                      {"type": "response.completed", "sequence_number": 2, "response": completed()}]
            return httpx.Response(200, headers={"content-type": "text/event-stream", "x-request-id": "req_offline"},
                                  text="".join("data: " + json.dumps(e) + "\n\n" for e in events))
        token = observe_api(records.append)
        try:
            with OpenAI(api_key="offline-only", base_url="https://api.example.test/v1", http_client=httpx.Client(transport=httpx.MockTransport(respond))) as client:
                response = response_call(client, "interpret", model="requested-model", input="private-input",
                                         on_delta=deltas.append)
        finally:
            token.var.reset(token)
        self.assertEqual("".join(deltas), response.output_text)
        self.assertTrue(sent[0]["stream"])
        self.assertEqual(records[0]["response_model"], "reported-model")
        self.assertEqual(records[0]["requested_model"], "requested-model")
        self.assertEqual(records[0]["usage"]["total_tokens"], 333)
        self.assertIsNotNone(records[0]["first_text_seconds"])
        self.assertEqual(records[0]["api_host"], "api.example.test")
        self.assertEqual(records[0]["request_id"], "req_offline")
        self.assertNotIn("private-input", json.dumps(records))
        self.assertNotIn("offline-only", json.dumps(records))

    def test_broken_stream_is_not_silently_retried_or_saved_as_complete(self):
        received, records = [], []
        client = Obj(responses=Obj(create=Mock(return_value=iter([Obj(type="response.output_text.delta", delta="partial")]))))
        token = observe_api(records.append)
        try:
            with self.assertRaisesRegex(RuntimeError, "완료 응답 없이"):
                response_call(client, "interpret", model="test", input="private", on_delta=received.append)
        finally:
            token.var.reset(token)
        self.assertEqual(received, ["partial"])
        self.assertEqual(client.responses.create.call_count, 1)
        self.assertEqual(records[0]["status"], "error")

    def test_clear_plot_skips_router_but_keeps_prior_selection_request(self):
        client = Mock()
        decision = chat_turn([{"role": "user", "content": "Bottom UV 1kHz만"}], "PV만 그려줘",
            {"selected_sources": [{"source_id": "a"}], "last_data_request": "Bottom UV만"}, "unused", "test", client)
        self.assertEqual(decision["action"], "plot")
        self.assertIn("Bottom UV만", decision["task"])
        self.assertTrue(decision["task"].endswith("이번 사용자 원문: PV만 그려줘"))
        client.responses.create.assert_not_called()

    def test_question_and_negative_plot_commands_still_use_conversation_router(self):
        client = Obj(responses=Obj(create=Mock(return_value=Obj(status="completed", output_text=json.dumps(
            {"action": "answer", "reply": "확인했습니다.", "task": ""})))))
        for request in ("PV 그려줄 수 있어?", "그리지 말아줘", "PV 플롯하지 마"):
            answer = chat_turn([], request, {"selected_sources": [{"source_id": "a"}]}, "unused", "test", client)
            self.assertEqual(answer["action"], "answer")
        self.assertEqual(client.responses.create.call_count, 3)


class ReuseAndOriginTests(unittest.TestCase):
    def test_analysis_cache_survives_followup_and_rerender_and_exposes_api_metadata(self):
        from analysis_core import analysis_evidence
        upload = io.BytesIO(b"Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\n0,2\n-2,-5")
        upload.name = "anonymous_3V.csv"
        response = completed()
        client = Obj(responses=Obj(create=Mock(return_value=Obj(status="completed", model=response["model"],
                     id=response["id"], output_text="분지 값은 -1과 2입니다.", usage=Obj(**response["usage"])))))
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {"OPENAI_API_KEY": "offline-only"}), patch("streamlit.file_uploader", return_value=[upload]), patch("openai.OpenAI", return_value=client), patch("analysis_core.analysis_evidence", wraps=analysis_evidence) as calculation:
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(folder).run(timeout=30)
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(calculation.call_count, 1)
            result = app.session_state["result"]
            before = result["curves"][0].data.copy()
            evidence = Path(result["run_dir"]) / "analysis_values.csv"
            modified = evidence.stat().st_mtime_ns
            app.chat_input[0].set_value("Pr 얼마야?").run(timeout=30)
            app.run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(calculation.call_count, 1)
            self.assertEqual(evidence.stat().st_mtime_ns, modified)
            self.assertTrue(before.equals(app.session_state["result"]["curves"][0].data))
            diagnostic = app.session_state["api_timings"][-1]
            self.assertEqual(diagnostic["response_model"], "reported-model")
            self.assertEqual(diagnostic["usage"]["total_tokens"], 333)
            self.assertEqual(diagnostic["key_source"], "환경변수")
            self.assertNotIn("offline-only", (Path(folder) / "api_calls.jsonl").read_text())
            self.assertTrue(client.responses.create.call_args.kwargs["stream"])
            upload.seek(0)
            upload.truncate()
            upload.write(b"Voltage (V),Polarization (uC/cm2)\n-2,-10\n0,-2\n2,10\n0,4\n-2,-10")
            app.run(timeout=30)
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(calculation.call_count, 2)
            fresh = app.session_state["result"]
            self.assertNotEqual(fresh["run_id"], result["run_id"])
            self.assertEqual(fresh["analysis_cache"]["summaries"][0]["y_at_x_zero"]["descending"]["last"], 4)

    def test_fifteen_curves_keep_all_xy_and_styles_with_fewer_com_calls(self):
        case = test_origin_adapter.OriginProtocolTests()
        case.setUp()
        try:
            tables = load_tables([(f"anonymous_{i}V.csv", f"Voltage (V),Current (A)\n-1,-{i}\n0,1\n1,{i}\n".encode())
                                  for i in range(1, 16)], case.root / "many")
            case.plan, case.curves = default_plan(tables), []
            case.curves = materialize(case.plan, tables)
            progress, hidden = [], []
            def execute(command):
                hidden.append(case.origin.Visible == 0)
                return True
            case.origin.Execute.side_effect = execute
            result = case.run_plot(on_progress=progress.append)
            self.assertEqual((result["curve_count"], result["graph_count"]), (15, 1))
            self.assertEqual(case.origin.PutWorksheet.call_count, 30)
            for i, curve in enumerate(case.curves):
                self.assertEqual(case.origin.PutWorksheet.call_args_list[2*i].args[1], curve.data.x.tolist())
                self.assertEqual(case.origin.PutWorksheet.call_args_list[2*i+1].args[1], curve.data.y.tolist())
            commands = "\n".join(call.args[0] for call in case.origin.Execute.call_args_list)
            self.assertEqual(commands.count("plotxy iy:="), 15)
            self.assertEqual(commands.count("set jihoPlot -w"), 15)
            self.assertEqual(commands.count("set jihoPlot -c color("), 15)
            self.assertEqual(result["execute_calls"], case.origin.Execute.call_count)
            self.assertLessEqual(result["execute_calls"], 10)
            self.assertTrue(all(hidden))
            self.assertEqual(case.origin.Visible, 3)
            self.assertIn("OPJU 파일 저장", result["timings"])
            self.assertEqual(progress[-1], "완료")
        finally:
            case.tearDown()


if __name__ == "__main__":
    unittest.main(verbosity=2)
