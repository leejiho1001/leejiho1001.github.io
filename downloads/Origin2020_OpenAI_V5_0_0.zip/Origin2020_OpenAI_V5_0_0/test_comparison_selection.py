"""Explicit file/curve cohorts and auditable reference selection without API calls."""
import copy
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from unittest.mock import Mock
from types import SimpleNamespace as Obj

from streamlit.testing.v1 import AppTest

from comparison_selection import current_catalog, file_groups, selection_summary
from db_compare import catalog, compare_database, save_comparison, load_comparison
from lab_core import save_run
from test_db_comparison import measurement, seed_database, planning_response


class CohortSelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.db, self.target, self.reference = seed_database(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_exact_reference_id_excludes_other_controls_and_survives_saved_report(self):
        extra, plan = measurement(self.root, "unused-control", scale=10.)
        save_run(self.db, "unused", "unused", plan, [extra])
        result = compare_database(self.db, [], target_source="db", target_ids=[self.target.curve_id],
                                  reference_ids=[self.reference.curve_id])
        self.assertEqual(result["target_count"], 1)
        self.assertEqual(result["reference_count"], 1)
        self.assertTrue((result["rows"].reference_count == 1).all())
        self.assertAlmostEqual(result["rows"].iloc[0].magnitude_change_percent_min, 20)
        self.assertEqual(result["selected_reference_ids"], [self.reference.curve_id])
        for ids in result["rows"].reference_ids:
            self.assertEqual(json.loads(ids), [self.reference.curve_id])
        save_comparison(self.db, self.root, "explicit selection", result)
        loaded = load_comparison(self.db, result["comparison_id"])
        self.assertEqual(loaded["selected_reference_ids"], [self.reference.curve_id])
        self.assertEqual(loaded["selected_target_ids"], [self.target.curve_id])

    def test_current_data_is_subsetted_by_selected_curve_ids(self):
        extra, _ = measurement(self.root, "extra-current", scale=3., treatment="bottom_uv")
        result = compare_database(self.db, [self.target, extra], target_ids=[self.target.curve_id],
                                  reference_ids=[self.reference.curve_id])
        self.assertEqual(result["target_count"], 1)
        self.assertEqual(set(result["rows"].target_id), {self.target.curve_id})

    def test_empty_selection_never_expands_to_all_and_stale_ids_are_rejected(self):
        for params in ({"target_ids": []}, {"reference_ids": []}, {"reference_ids": ["missing"]},
                       {"target_filters": {"treatment": "bottom_uv"}, "target_ids": [self.reference.curve_id]},
                       {"reference_filters": {"treatment": "bottom_uv"}, "reference_ids": [self.reference.curve_id]}):
            with self.subTest(params=params), self.assertRaises(ValueError):
                compare_database(self.db, [], target_source="db", **params)

    def test_unknown_treatment_does_not_prevent_file_based_selection(self):
        baseline, bp = measurement(self.root, "unknown-control", treatment=None)
        target, tp = measurement(self.root, "unknown-target", treatment=None, scale=1.5)
        save_run(self.db, "unknown-baseline", "", bp, [baseline])
        save_run(self.db, "unknown-target", "", tp, [target])
        result = compare_database(self.db, [], target_source="db", target_ids=[target.curve_id], reference_ids=[baseline.curve_id])
        self.assertAlmostEqual(result["rows"].iloc[0].magnitude_change_percent_min, 50)

    def test_duplicate_filenames_are_distinguished_by_content_not_collapsed(self):
        frame = catalog(self.db)
        frame["filename"] = "same-name.csv"
        groups = file_groups(frame)
        self.assertEqual(len(groups), 2)
        self.assertEqual(len({g["label"] for g in groups.values()}), 2)
        self.assertEqual({cid for g in groups.values() for cid in g["ids"]}, set(frame.curve_id))

    def test_self_measurement_is_recognized_even_after_legend_or_style_changes(self):
        alias = copy.copy(self.reference)
        alias.curve_id = "different-style-id"
        alias.spec = copy.deepcopy(alias.spec)
        alias.spec["label"] = "new legend"
        summary = selection_summary(current_catalog([alias]), current_catalog([self.reference]), ["voltage_v", "frequency_hz"])
        self.assertEqual(summary["overlap_count"], 1)
        self.assertEqual(summary["candidate_pairs"], 0)


class CohortSelectionWebTests(unittest.TestCase):
    def open(self, folder):
        app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
        app.sidebar.text_input[0].set_value(str(folder)).run(timeout=30)
        self.assertFalse(app.exception)
        return app

    def named(self, items, label):
        return next(item for item in items if item.label == label)

    def test_both_file_cohorts_are_selectable_without_treatment_metadata(self):
        with tempfile.TemporaryDirectory() as folder, patch("openai.OpenAI") as api:
            root = Path(folder)
            db = root / "experiments.sqlite3"
            baseline, bp = measurement(root, "selected-reference", treatment=None)
            target, tp = measurement(root, "selected-target", treatment=None, scale=1.2)
            extra, ep = measurement(root, "unselected", treatment=None, scale=10.)
            for name, curve, plan in (("ref", baseline, bp), ("target", target, tp), ("unused", extra, ep)):
                save_run(db, name, name, plan, [curve])
            groups = file_groups(catalog(db))
            target_file = next(k for k, g in groups.items() if target.curve_id in g["ids"])
            reference_file = next(k for k, g in groups.items() if baseline.curve_id in g["ids"])
            app = self.open(root)
            button = self.named(app.button, "조건을 맞춰 DB 비교 분석")
            self.assertTrue(button.disabled)
            self.named(app.radio, "대상군 파일 선택 방식").set_value("selected").run(timeout=30)
            self.named(app.multiselect, "대상군 파일·시트 선택").set_value([target_file]).run(timeout=30)
            self.named(app.multiselect, "기준군 파일·시트 선택").set_value([reference_file]).run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(self.named(app.button, "조건을 맞춰 DB 비교 분석").disabled)
            self.named(app.button, "조건을 맞춰 DB 비교 분석").click().run(timeout=30)
            result = app.session_state["comparison_result"]
            self.assertEqual(result["selected_target_ids"], [target.curve_id])
            self.assertEqual(result["selected_reference_ids"], [baseline.curve_id])
            self.assertAlmostEqual(result["rows"].iloc[0].magnitude_change_percent_min, 20)
            self.assertFalse(app.error)
            api.assert_not_called()
            def respond(**kwargs):
                if "text" in kwargs:
                    return Obj(status="completed", output_text=json.dumps(planning_response()))
                rows = json.loads(kwargs["input"])["computed_comparisons"]
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["metric"], "two_pr")
                self.assertAlmostEqual(rows[0]["magnitude_change_percent_min"], 20)
                return Obj(status="completed", output_text="선택한 두 군의 2Pr는 기준 대비 20% 증가했습니다.")
            client = Obj(responses=Obj(create=Mock(side_effect=respond)))
            api.return_value = client
            with patch.dict(os.environ, {"OPENAI_API_KEY": "offline-only"}):
                app.chat_input[0].set_value("선택한 대상과 기준으로 DB의 2Pr를 비교해줘").run(timeout=30)
            self.assertFalse(app.exception)
            selected = app.session_state["comparison_result"]
            self.assertEqual(selected["selected_target_ids"], [target.curve_id])
            self.assertEqual(selected["selected_reference_ids"], [baseline.curve_id])
            self.assertIn("20% 증가", app.session_state["chat_messages"][-1]["content"])

    def test_same_measurement_on_both_sides_disables_compare_with_visible_reason(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            baseline, plan = measurement(root, "only-saved-file", treatment=None)
            save_run(root / "experiments.sqlite3", "single", "single", plan, [baseline])
            group = next(iter(file_groups(catalog(root / "experiments.sqlite3"))))
            app = self.open(root)
            self.named(app.multiselect, "기준군 파일·시트 선택").set_value([group]).run(timeout=30)
            self.assertTrue(self.named(app.button, "조건을 맞춰 DB 비교 분석").disabled)
            self.assertTrue(any("동일 원본 측정" in warning.value for warning in app.warning))
            self.assertTrue(any("서로 다른 측정" in warning.value for warning in app.warning))
            with patch.dict(os.environ, {"OPENAI_API_KEY": "offline-only"}):
                app.chat_input[0].set_value("선택한 대상과 기준으로 DB 비교해줘").run(timeout=30)
            self.assertIn("파일을 선택", app.session_state["chat_messages"][-1]["content"])

    def test_current_target_curves_can_be_selected_individually(self):
        upload = io.BytesIO(b"Voltage (V),Polarization (uC/cm2)\n-2,-6\n0,-1.2\n2,6\n0,2.4\n-2,-6")
        upload.name = "current_1kHz_3V.csv"
        with tempfile.TemporaryDirectory() as folder, patch("streamlit.file_uploader", return_value=[upload]), patch("openai.OpenAI") as api:
            root = Path(folder)
            seed_database(root)
            app = self.open(root)
            self.named(app.button, "1. 파일 읽기 · 데이터 구간 탐색").click().run(timeout=30)
            self.named(app.button, "4. 이 계획으로 데이터 정리 · 저장").click().run(timeout=30)
            self.named(app.radio, "비교 대상 데이터").set_value("current").run(timeout=30)
            self.named(app.checkbox, "대상군 곡선도 직접 선택").set_value(True).run(timeout=30)
            target_id = app.session_state["result"]["curves"][0].curve_id
            self.named(app.multiselect, "대상군 곡선 선택").set_value([target_id]).run(timeout=30)
            self.assertFalse(self.named(app.button, "조건을 맞춰 DB 비교 분석").disabled)
            self.named(app.button, "조건을 맞춰 DB 비교 분석").click().run(timeout=30)
            self.assertEqual(app.session_state["comparison_result"]["selected_target_ids"], [target_id])
            api.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
