import copy
import tempfile
import unittest
from pathlib import Path

from lab_core import default_plan, load_tables, materialize, prepare_plan
from plot_rules import select_requested_channels
from curve_integrity import source_point_audit


class NumberedChannelTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.v = [-2, -1, 0, 1, 2, 1, 0, -1, -2]
        self.p = [-5, -4, -2, 1, 5, 4, 2, -1, -5]
        headers = "Time [s],V1 [V],I1 [A],P1 [uC/cm2],V2 [V],I2 [A],P2 [uC/cm2],V3 [V],I3 [A],P3 [uC/cm2]"
        rows = [headers]
        for i, (v, p) in enumerate(zip(self.v, self.p)):
            rows.append(f"{i/1000},{v},{v/1000},{p},{-v},{-v/1000},{-p},{v},{v/1000},{p+.05}")
        self.tables = load_tables([("device_2V_3cycles.dat", "\n".join(rows).replace(",", "\t").encode())], self.root / "raw")
        self.plan = default_plan(self.tables)

    def tearDown(self):
        self.tmp.cleanup()

    def test_default_pairs_every_current_and_polarization_with_its_numbered_voltage(self):
        pairs = {(s["x_column"], s["y_column"]) for s in self.plan["curves"]}
        self.assertEqual(pairs, {("B", "C"), ("B", "D"), ("E", "F"), ("E", "G"), ("H", "I"), ("H", "J")})

    def test_common_v1_ai_plan_is_corrected_to_raw_v2_v3_without_sign_changes(self):
        self.plan["measurement"] = "PV"
        for spec in self.plan["curves"]:
            spec["x_column"] = "B"  # reproduce the old shared-first-X selection
        prepared = prepare_plan(self.plan, self.tables)
        curves = materialize(prepared, self.tables)
        self.assertEqual([(c.spec["x_column"], c.spec["y_column"]) for c in curves], [("B", "D"), ("E", "G"), ("H", "J")])
        self.assertEqual(curves[1].data.x.tolist(), [-v for v in self.v])
        self.assertEqual(curves[1].data.y.tolist(), [-p for p in self.p])
        self.assertEqual(len(source_point_audit(curves)), 27)
        self.assertTrue(any("E" in note and "P2" in note for note in prepared["notes"]))

    def test_manual_source_pair_is_not_overridden(self):
        self.plan["measurement"] = "manual"
        for spec in self.plan["curves"]:
            spec["x_column"] = "B"
        curves = materialize(self.plan, self.tables)
        p2 = next(c for c in curves if c.spec["y_column"] == "G")
        self.assertEqual(p2.data.x.tolist(), self.v)

    def test_p1_only_keeps_one_polarization_curve_per_source(self):
        plan = prepare_plan(self.plan, self.tables)
        chosen = select_requested_channels(plan, self.tables, "모든 전압의 P1만 그려줘")
        curves = materialize(chosen, self.tables)
        self.assertEqual(len(curves), 1)
        self.assertEqual((curves[0].spec["x_column"], curves[0].spec["y_column"]), ("B", "D"))

    def test_two_copies_of_same_y_with_competing_x_are_added_only_once_after_pairing(self):
        self.plan["measurement"] = "PV"
        original = next(s for s in self.plan["curves"] if s["y_column"] == "D")
        extra = copy.deepcopy(original)
        extra["x_column"] = "E"
        self.plan["curves"] = [original, extra]
        prepared = prepare_plan(self.plan, self.tables)
        self.assertEqual(len(materialize(prepared, self.tables)), 1)

    def test_missing_matching_numbered_voltage_does_not_silently_reuse_v1(self):
        tables = load_tables([("missing.csv", b"V1 (V),V2 (V),P3 (uC/cm2)\n-1,1,-2\n0,0,1\n1,-1,2\n")], self.root / "missing")
        with self.assertRaisesRegex(ValueError, "V3"):
            materialize(default_plan(tables), tables)


if __name__ == "__main__":
    unittest.main(verbosity=2)
