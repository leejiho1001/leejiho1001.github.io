"""Measurement-neutral statistics from all original selected points; no fitting."""
import math

import numpy as np


GENERIC_METRICS = {"y_min": "Y 최솟값", "y_max": "Y 최댓값", "y_mean": "Y 평균(분석 통계)",
                   "peak_x": "최대 신호의 X 위치", "raw_area": "원본 취득 방향 적분", "peak_width": "측정점 FWHM 후보"}


def _width(x, y, index):
    if len(x) < 3 or not (np.all(np.diff(x) >= 0) or np.all(np.diff(x) <= 0)):
        return None
    baseline = float(np.min(y))
    target = baseline + (float(y[index]) - baseline) / 2
    if y[index] <= baseline:
        return None
    crossings = []
    for step in (-1, 1):
        i = index
        while 0 <= i + step < len(y):
            j = i + step
            if y[j] <= target < y[i]:
                fraction = (target - y[i]) / (y[j] - y[i])
                crossings.append(float(x[i] + fraction * (x[j] - x[i])))
                break
            i = j
    return abs(crossings[1] - crossings[0]) if len(crossings) == 2 else None


def generic_evidence(curve):
    data = curve.data
    x, y = data.x.to_numpy(dtype=float), data.y.to_numpy(dtype=float)
    contiguous = np.diff(data.source_row.to_numpy()) == 1
    dx = np.diff(x)[contiguous]
    order = "increasing" if len(dx) and np.all(dx >= 0) and np.any(dx > 0) else "decreasing" if len(dx) and np.all(dx <= 0) and np.any(dx < 0) else "constant" if not len(dx) or np.all(dx == 0) else "nonmonotonic"
    maximum = np.flatnonzero(y == np.max(y))
    area = float(np.sum(((y[1:] + y[:-1]) * .5 * np.diff(x))[contiguous]))
    peaks, width = [], None
    for _, segment in data.groupby(data.source_row.diff().ne(1).cumsum(), sort=False):
        sx, sy = segment.x.to_numpy(dtype=float), segment.y.to_numpy(dtype=float)
        starts = np.r_[0, np.flatnonzero(np.diff(sy) != 0) + 1]
        ends = np.r_[starts[1:] - 1, len(sy) - 1]
        heights = sy[starts]
        local = np.flatnonzero((heights[1:-1] > heights[:-2]) & (heights[1:-1] > heights[2:])) + 1
        for run in local:
            center = int((starts[run] + ends[run]) // 2)
            peaks.append({"x": float(sx[center]), "y": float(sy[center]),
                          "source_row": int(segment.source_row.iloc[center]), "fwhm": None,
                          "_width_input": (sx, sy, center)})
    peaks.sort(key=lambda p: p["y"], reverse=True)
    # Bound secondary peak-width work, never the data used for plotting/stats.
    for rank, peak in enumerate(peaks):
        args = peak.pop("_width_input")
        if rank < 10:
            peak["fwhm"] = _width(*args)
            if peak["y"] == np.max(y) and width is None:
                width = peak["fwhm"]
    summary = {"n_points": len(data), "x_order": order, "segments": int(np.count_nonzero(~contiguous) + 1),
               "x_min": float(np.min(x)), "x_max": float(np.max(x)),
               "y_min": float(np.min(y)), "y_max": float(np.max(y)), "y_mean": float(np.mean(y)),
               "y_std": float(np.std(y)), "peak_x_min": float(np.min(x[maximum])),
               "peak_x_max": float(np.max(x[maximum])), "peak_x_last": float(x[maximum[-1]]),
               "peak_sample_count": len(maximum), "raw_area": area if math.isfinite(area) else None,
               "peak_width": width, "local_peak_count": len(peaks), "top_measured_peaks": peaks[:10],
               "method": "all selected points; original acquisition order; no smoothing/averaging/downsampling; area excludes row gaps; top 10 measured peaks carry FWHM candidates using each contiguous segment minimum as constant baseline"}
    return summary, peaks


def generic_markdown(summaries):
    lines = [f"선택한 전체 {len(summaries)}개 곡선의 범용 수치 분석입니다.", "",
             "| 곡선 | 측정 유형 | 전체 점 수 | X 범위 | Y 범위 | 최대 신호의 X 위치 | FWHM 후보 | X / Y 단위 |",
             "|---|---|---:|---:|---:|---:|---:|---|"]
    for summary in summaries:
        stats = summary["generic_statistics"]
        label = summary["label"].replace("|", "\\|").replace("\n", " ")
        peak = f"{stats['peak_x_min']:.6g}" if stats["peak_x_min"] == stats["peak_x_max"] else f"{stats['peak_x_min']:.6g} ~ {stats['peak_x_max']:.6g}"
        width = "—" if stats["peak_width"] is None else f"{stats['peak_width']:.6g}"
        lines.append(f"| {label} | {summary['metadata'].get('measurement_type') or 'XY'} | {stats['n_points']} | {stats['x_min']:.6g} ~ {stats['x_max']:.6g} | {stats['y_min']:.6g} ~ {stats['y_max']:.6g} | {peak} | {width} | {summary['x_unit'] or '미지정'} / {summary['y_unit'] or '미지정'} |")
    lines += ["", "전체 선택 점을 그대로 분석했습니다. 최대 신호 위치는 측정점 기준이며, FWHM은 구간 최솟값을 일정 배경으로 둔 보간 후보입니다. 중첩 피크 분리나 모델 피팅 결과와 구분합니다."]
    return "\n".join(lines)
