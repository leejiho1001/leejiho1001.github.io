"""Deterministic plotting choices shared by the web preview and Origin export."""
from __future__ import annotations

import copy
import re
from pathlib import Path
from string import Formatter

from openpyxl.utils import column_index_from_string
from openpyxl.utils import get_column_letter
import pandas as pd


PLOT_DEFAULTS = {"plot_mode": "combined", "measurement": "auto", "legend_format": ""}
PLOT_MODES = ("combined", "separate", "grouped")
MEASUREMENTS = ("auto", "PV", "IV", "manual")
AXIS_NAMES = {"voltage": "Voltage", "polarization": "Polarization", "current": "Current",
              "current_density": "Current density", "time": "Time", "field": "Electric field", "charge": "Charge"}
LEGEND_FIELDS = {"filename", "stem", "sheet", "x_name", "y_name", "x_unit", "y_unit",
                 "device_id", "measurement_type", "voltage_v", "frequency_hz", "temperature_c",
                 "cycle", "split_condition", "device_stack", "treatment"}


def source_header(table, start, col):
    for row in range(start - 2, max(-1, start - 7), -1):
        value = table.frame.iat[row, col]
        if pd.notna(value) and str(value).strip() and pd.isna(pd.to_numeric(value, errors="coerce")):
            unit = str(value).strip().strip("[]()")
            if re.fullmatch(r"[pnumkM]?(?:V|A|C/(?:cm|m)(?:2|²|\^2)|A/(?:cm|m)(?:2|²|\^2)|s)", unit):
                for previous in range(row - 1, max(-1, row - 4), -1):
                    name = str(table.frame.iat[previous, col]).strip()
                    if re.match(r"^(?:Voltage|Current|Polarization|Time|V[\d+−-]*|I\d*|P\d*|J\d*)\b", name, re.I):
                        return f"{name} [{unit}]"[:120]
            return str(value).strip()[:120]
    return get_column_letter(col + 1)


def axis_channel(header):
    """A literal numbered source channel, e.g. V2 [V] or P2 [uC/cm2]."""
    match = re.match(r"\s*(?:Voltage|Current|Polarization|V|I|P|J)[ _-]*(\d+)(?!\d)", str(header), re.I)
    return str(int(match.group(1))) if match else None


def axis_polarity(header):
    match = re.match(r"\s*(?:Voltage|Current|Polarization|V|I|P|J)(?:[ _]*\d+)?[ _]*([+−-])(?=\s|[\[(]|$)", str(header), re.I)
    return match.group(1).replace("−", "-") if match else None


def matching_voltage_column(table, start, y_column):
    y_header = source_header(table, start, y_column)
    channel = axis_channel(y_header)
    if axis_info(y_header)[0] not in ("polarization", "current", "current_density"):
        return None
    voltages = [(i, source_header(table, start, i)) for i in range(table.frame.shape[1])
                if axis_info(source_header(table, start, i))[0] == "voltage"]
    matched = [i for i, header in voltages if channel is not None and axis_channel(header) == channel
               and axis_polarity(header) == axis_polarity(y_header)]
    if len(matched) == 1:
        return matched[0]
    if not matched and axis_polarity(y_header):
        matched = [i for i, header in voltages if axis_polarity(header) == axis_polarity(y_header)
                   and (axis_channel(header) is None or axis_channel(header) == channel)]
        if len(matched) == 1:
            return matched[0]
    if len(matched) > 1 or (len(voltages) > 1 and channel is not None and any(axis_channel(header) for _, header in voltages)):
        raise ValueError(f"{table.filename} / {table.sheet}: {y_header}에 대응하는 V{channel} 전압열을 하나로 정할 수 없습니다. 원본 열 지정을 확인하세요.")
    if len(voltages) == 1:
        return voltages[0][0]
    if len(voltages) > 1:
        choices = ", ".join(f"{get_column_letter(i + 1)}={header}" for i, header in voltages)
        raise ValueError(f"전압열 대응 불명확: {table.filename} / {table.sheet}, {y_header}. 후보: {choices}. "
                         "반대 극성 전압을 임의로 연결하지 않았습니다. 원본 파일의 열 대응 정보가 필요합니다.")
    return None


def select_requested_channels(plan, tables, request):
    requested = {(family.upper(), str(int(number))) for family, number in
                 re.findall(r"(?<![A-Za-z0-9])([PIJ])[ _-]*(\d+)(?![A-Za-z0-9])", request, re.I)}
    if not requested:
        return plan
    result = copy.deepcopy(plan)
    sources = {t.source_id: t for t in tables}
    kept = []
    for spec in result["curves"]:
        header = source_header(sources[spec["source_id"]], spec["start_row"], column_index_from_string(spec["y_column"]) - 1)
        kind = axis_info(header)[0]
        family = {"polarization": "P", "current": "I", "current_density": "J"}.get(kind)
        if (family, axis_channel(header)) in requested:
            kept.append(spec)
    result["curves"] = kept
    result["notes"].append("요청한 번호의 측정열만 선택했습니다: " + ", ".join(family + index for family, index in sorted(requested)))
    return result


def unit_text(text: str) -> str:
    return (str(text).replace("µ", "u").replace("μ", "u").replace("²", "2")
            .replace("^2", "2").replace("−", "-").replace(" ", "").strip())


def axis_info(name: str, unit: str = "") -> tuple[str, str]:
    """Recognize explicit labels/units, never infer physics from numeric ranges."""
    text = str(name).strip()
    normalized = unit_text(unit)
    if not normalized:
        match = re.search(r"\(([^)]+)\)|\[([^\]]+)\]", text)
        if match:
            normalized = unit_text(match.group(1) or match.group(2))
    name_only = re.sub(r"[\[(].*", "", text).strip()
    if re.search(r"polar|분극", name_only, re.I) or re.fullmatch(r"P\d*", name_only, re.I):
        kind = "polarization"
    elif re.search(r"current.?density|전류.?밀도", name_only, re.I) or re.fullmatch(r"J\d*", name_only):
        kind = "current_density"
    elif re.search(r"current|전류", name_only, re.I) or re.fullmatch(r"I\d*", name_only, re.I):
        kind = "current_density" if "/" in normalized else "current"
    elif re.search(r"electric.?field|전계", name_only, re.I):
        kind = "field"
    elif re.search(r"volt|전압", name_only, re.I) or re.fullmatch(r"V\d*", name_only, re.I):
        kind = "voltage"
    elif re.search(r"time|시간", name_only, re.I):
        kind = "time"
    elif re.search(r"charge|전하", name_only, re.I) or re.fullmatch(r"Q\d*", name_only):
        kind = "charge"
    elif re.fullmatch(r"[pnumkM]?C/(?:cm|m)2", normalized):
        kind = "polarization"
    elif re.fullmatch(r"[pnumkM]?A/(?:cm|m)2", normalized):
        kind = "current_density"
    elif re.fullmatch(r"[pnumkM]?A", normalized):
        kind = "current"
    elif re.fullmatch(r"[pnumkM]?V", normalized) or re.fullmatch(r"V[+−-]", name_only, re.I):
        kind = "voltage"
    else:
        kind = "unknown"
    return kind, normalized


def request_options(request: str) -> dict:
    """Resolve clear commands locally; ambiguous wording remains with the AI/UI."""
    patterns = {
        "combined": r"한\s*그래프|하나(?:의\s*그래프)?로|겹쳐|겹치|합쳐|overlay|combined?",
        "separate": r"각각|따로|개별|separate(?:ly)?",
        "grouped": r"조건별|전압별|온도별|주파수별|grouped",
    }
    matches = {key for key, pattern in patterns.items() if re.search(pattern, request, re.I)}
    options = {"plot_mode": next(iter(matches))} if len(matches) == 1 else {}
    positive, negative = set(), set()
    token = r"(?<![A-Za-z])(?P<latin>[PI])\s*[-–]?\s*V(?![A-Za-z])|(?P<korean>분극|전류)"
    for match in re.finditer(token, request, re.I):
        kind = ("PV" if (match.group("latin") or "").upper() == "P" or match.group("korean") == "분극" else "IV")
        tail = request[match.end():match.end() + 24]
        excluded = bool(re.match(r"\s*(?:은|는|을|를|도|그래프)?\s*(?:빼|제외|말고|말아|그리지\s*(?:마|말)|필요\s*없|하지\s*(?:마|말)|싫)", tail))
        (negative if excluded else positive).add(kind)
    positive -= negative
    if len(positive) == 1:
        options["measurement"] = next(iter(positive))
    elif len(positive) == 2:
        options["measurement"] = "auto"  # both kinds were explicitly requested
    elif len(negative) == 1:
        options["measurement"] = "IV" if "PV" in negative else "PV"
    return options


def validate_plot_options(plan: dict):
    if plan.get("plot_mode", "combined") not in PLOT_MODES:
        raise ValueError("plot_mode는 combined, separate, grouped 중 하나여야 합니다.")
    if plan.get("measurement", "auto") not in MEASUREMENTS:
        raise ValueError("measurement는 auto, PV, IV, manual 중 하나여야 합니다.")
    pattern = plan.get("legend_format", "")
    if not isinstance(pattern, str) or len(pattern) > 500:
        raise ValueError("범례 형식은 500자 이하 문자열이어야 합니다.")
    try:
        for _, field, spec, conversion in Formatter().parse(pattern):
            if field is None:
                continue
            if field not in LEGEND_FIELDS or conversion or not re.fullmatch(r"(?:\.\d{1,2})?[fgGeEd]?", spec):
                raise ValueError("지원하지 않는 범례 필드/형식입니다: " + str(field))
    except ValueError as exc:
        raise ValueError(f"범례 형식을 확인하세요: {exc}") from exc


def legend_label(spec: dict, source, pattern: str) -> str:
    if not pattern:
        return spec["label"]
    context = {**spec["metadata"], **{k: spec[k] for k in ("label", "x_name", "y_name", "x_unit", "y_unit")},
               "filename": source.filename, "stem": Path(source.filename).stem, "sheet": source.sheet}
    parts = []
    for literal, field, formatting, _ in Formatter().parse(pattern):
        parts.append(literal)
        if field is not None:
            value = context[field]
            try:
                parts.append("미확인" if value is None else format(value, formatting))
            except (ValueError, TypeError) as exc:
                raise ValueError(f"범례 {{{field}:{formatting}}}에 맞지 않는 값입니다.") from exc
    label = "".join(parts)
    if len(label) > 500:
        raise ValueError("생성된 범례가 500자를 넘습니다.")
    return label


def prepare_plot_plan(plan: dict, tables: list, header_reader) -> dict:
    """Correct inverted V-Y pairs from raw headers, preserving acquisition order."""
    result = copy.deepcopy(plan)
    for key, value in PLOT_DEFAULTS.items():
        result.setdefault(key, value)
    validate_plot_options(result)
    sources = {table.source_id: table for table in tables}
    selected = []
    reversed_count = 0
    channel_corrections = []
    seen_selections = set()
    for spec in result["curves"]:
        source = sources[spec["source_id"]]
        kinds = {}
        for axis in ("x", "y"):
            col = column_index_from_string(spec[f"{axis}_column"]) - 1
            raw_name = header_reader(source, spec["start_row"], col)
            raw_kind, raw_unit = axis_info(raw_name)
            named_kind, named_unit = axis_info(spec[f"{axis}_name"], spec[f"{axis}_unit"])
            kinds[axis] = raw_kind if raw_kind != "unknown" else named_kind
            if result["measurement"] != "manual":
                spec[f"{axis}_unit"] = raw_unit or named_unit
                if kinds[axis] != "unknown":
                    spec[f"{axis}_name"] = AXIS_NAMES[kinds[axis]]
        if result["measurement"] != "manual":
            if kinds["y"] == "voltage" and kinds["x"] in ("polarization", "current", "current_density"):
                for suffix in ("column", "name", "unit"):
                    spec[f"x_{suffix}"], spec[f"y_{suffix}"] = spec[f"y_{suffix}"], spec[f"x_{suffix}"]
                kinds["x"], kinds["y"] = kinds["y"], kinds["x"]
                reversed_count += 1
            measurement = "PV" if kinds["x"] == "voltage" and kinds["y"] == "polarization" else (
                "IV" if kinds["x"] == "voltage" and kinds["y"] in ("current", "current_density") else "other")
            target = result["measurement"]
            if target in ("PV", "IV") and measurement != target:
                continue
            if kinds["x"] == "voltage" and kinds["y"] in ("polarization", "current", "current_density"):
                y_index = column_index_from_string(spec["y_column"]) - 1
                explicit = next((m for m in result.get("column_mappings", []) if m["source_id"] == spec["source_id"]
                    and m["start_row"] <= spec["start_row"] and m["end_row"] >= spec["end_row"]
                    and m["y_column"] == spec["y_column"]), None)
                if explicit and not explicit["x_column"]:
                    continue
                matching = (column_index_from_string(explicit["x_column"]) - 1 if explicit
                            else matching_voltage_column(source, spec["start_row"], y_index))
                if explicit and axis_info(source_header(source, spec["start_row"], matching))[0] != "voltage":
                    raise ValueError("저장된 열 대응의 X가 전압열이 아닙니다.")
                if matching is not None and get_column_letter(matching + 1) != spec["x_column"]:
                    old = spec["x_column"]
                    spec["x_column"] = get_column_letter(matching + 1)
                    spec["x_name"] = "Voltage"
                    spec["x_unit"] = axis_info(source_header(source, spec["start_row"], matching))[1]
                    channel_corrections.append(f"{source.filename}: {source_header(source, spec['start_row'], y_index)}의 X를 {old}→{spec['x_column']}로 연결")
            if measurement != "other":
                spec["metadata"]["measurement_type"] = measurement
        spec["label"] = legend_label(spec, source, result["legend_format"])
        selection = (spec["source_id"], spec["start_row"], spec["end_row"], spec["x_column"], spec["y_column"])
        if selection in seen_selections:
            result["notes"].append("채널 연결 교정 후 동일해진 X–Y 선택 항목 하나를 중복 추가하지 않았습니다.")
            continue
        seen_selections.add(selection)
        selected.append(spec)
    result["curves"] = selected
    if reversed_count:
        result["notes"].append(f"원본 헤더 기준으로 {reversed_count}개 곡선의 X/Y를 바로잡았습니다: X=전압, Y=분극/전류.")
    if channel_corrections:
        result["notes"].extend(channel_corrections)
    if not selected:
        raise ValueError("선택한 P–V/I–V에 맞는 전압·측정값 열을 찾지 못했습니다. 열/헤더를 확인하거나 '열 지정 그대로' 모드를 사용하세요.")
    return result


def grouping_axes(spec: dict) -> list[str]:
    result = []
    for axis in ("x", "y"):
        kind, unit = axis_info(spec[f"{axis}_name"], spec[f"{axis}_unit"])
        result.extend([kind if kind != "unknown" else spec[f"{axis}_name"].strip().casefold(), unit])
    return result
