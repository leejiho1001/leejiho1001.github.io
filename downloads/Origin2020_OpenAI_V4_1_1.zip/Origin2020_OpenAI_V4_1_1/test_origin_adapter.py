"""Mock COM protocol tests; these do NOT validate a real Origin installation."""
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from lab_core import default_plan, load_tables, materialize
from origin_adapter import plot_origin


class OriginProtocolTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        tables = load_tables([("demo_3V.csv", b"V,I\n-1,-2\n0,1\n1,2\n")], self.root / "raw")
        self.plan = default_plan(tables)
        self.curves = materialize(self.plan, tables)
        self.origin = Mock()
        self.origin.CreatePage.side_effect = lambda page_type, name, template: name
        self.origin.Execute.return_value = True
        self.columns = {}
        self.origin.FindWorksheet.return_value.Columns.side_effect = lambda index: self.columns.setdefault(index, Mock())
        self.origin.Save.side_effect = self.save
        self.com = types.ModuleType("pythoncom")
        self.com.CoInitialize = Mock()
        self.com.CoUninitialize = Mock()
        self.client = types.ModuleType("win32com.client")
        self.client.Dispatch = Mock(return_value=self.origin)
        self.client.DispatchEx = Mock(return_value=self.origin)
        self.package = types.ModuleType("win32com")
        self.package.client = self.client

    def tearDown(self):
        self.temp.cleanup()

    def save(self, path):
        Path(path).write_bytes(b"MOCK-OPJU-NOT-A-REAL-PROJECT")
        return True

    def run_plot(self, **kwargs):
        with patch.dict(sys.modules, {"pythoncom": self.com, "win32com": self.package, "win32com.client": self.client}), patch("origin_adapter.sys.platform", "win32"):
            return plot_origin(self.curves, self.plan, self.root / "result.opju", **kwargs)

    def test_original_si_connection_transfers_xy_and_saves(self):
        result = self.run_plot(prog_id="Origin.ApplicationSI")
        self.client.Dispatch.assert_called_once_with("Origin.ApplicationSI")
        self.client.DispatchEx.assert_not_called()
        self.assertEqual(result["curve_count"], 1)
        self.assertEqual(self.origin.PutWorksheet.call_args_list[0].args[1], [-1., 0., 1.])
        self.assertEqual(self.origin.PutWorksheet.call_args_list[1].args[1], [-2., 1., 2.])
        self.origin.NewProject.assert_not_called()
        self.origin.Quit.assert_not_called()
        self.com.CoUninitialize.assert_called_once()

    def test_separate_instance_is_an_explicit_option(self):
        self.run_plot(prog_id="Origin.Application")
        self.client.Dispatch.assert_not_called()
        self.client.DispatchEx.assert_called_once_with("Origin.Application")

    def test_overlay_uses_one_graph_and_custom_long_names_for_all_curves(self):
        tables = load_tables([
            ("one.csv", b"Voltage (V),Current (A)\n-1,-2\n0,1\n1,2\n"),
            ("two.csv", b"I (A),Voltage (V)\n-3,-1\n2,0\n3,1\n"),
        ], self.root / "raw")
        self.plan = default_plan(tables)
        self.plan["legend_format"] = "{stem}"
        self.curves = materialize(self.plan, tables)
        result = self.run_plot()
        commands = [call.args[0] for call in self.origin.Execute.call_args_list]
        plots = [command for command in commands if command.startswith("plotxy")]
        self.assertEqual(result["graph_count"], 1)
        self.assertEqual(len(plots), 2)
        self.assertEqual(plots[0].split("ogl:=")[1], plots[1].split("ogl:=")[1])
        self.assertEqual(self.columns[1].LongName, "one")
        self.assertEqual(self.columns[3].LongName, "two")
        legend = next(command for command in commands if command.startswith("legend.text$"))
        self.assertIn(r"\l(1) %(1,@LL)", legend)
        self.assertIn(r"\l(2) %(2,@LL)", legend)
        self.assertTrue(any(command.startswith('xb.text$ = "Voltage (V)"') for command in commands))

    def test_separate_mode_creates_two_graphs(self):
        tables = load_tables([
            ("one.csv", b"V,I\n-1,-2\n0,1\n1,2\n"),
            ("two.csv", b"V,I\n-1,-3\n0,2\n1,3\n"),
        ], self.root / "raw")
        self.plan = default_plan(tables)
        self.plan["plot_mode"] = "separate"
        self.curves = materialize(self.plan, tables)
        self.assertEqual(self.run_plot()["graph_count"], 2)

    def test_native_palette_uses_state_column_and_origin_2020_properties(self):
        from lab_features import COLOR_DEFAULTS
        tables = load_tables([
            ("one_1V.csv", b"Voltage (V),Current (A)\n-1,-2\n0,1\n1,2\n"),
            ("two_3V.csv", b"Voltage (V),Current (A)\n-3,-3\n0,2\n3,3\n"),
        ], self.root / "raw")
        self.plan = default_plan(tables)
        self.plan["color_settings"] = dict(COLOR_DEFAULTS, mode="origin", origin_palette="Maple.pal")
        self.curves = materialize(self.plan, tables)
        result = self.run_plot()
        calls = self.origin.PutWorksheet.call_args_list
        self.assertEqual([c.args[3] for c in calls], [0, 1, 2, 3, 4, 5])
        self.assertEqual(calls[2].args[1], [0., 0., 0.])
        self.assertEqual(calls[5].args[1], [1., 1., 1.])
        commands = [c.args[0] for c in self.origin.Execute.call_args_list]
        self.assertEqual(result["graph_count"], 1)
        self.assertIn('jihoPlot.cmap.palette$ = "Maple.pal";', commands)
        self.assertTrue(any("(4,5)" in c for c in commands if c.startswith("plotxy")))

    def test_pv_and_iv_pick_their_registered_templates(self):
        pv, iv = self.root / "pv.otpu", self.root / "iv.otpu"
        pv.write_bytes(b"test-template")
        iv.write_bytes(b"test-template")
        tables = load_tables([("mixed.csv", b"Voltage (V),Current (A),Polarization (uC/cm2)\n-1,-2,-4\n0,1,2\n1,2,4\n")], self.root / "raw")
        self.plan = default_plan(tables)
        self.plan["template_routes"] = {"PV": str(pv), "IV": str(iv)}
        self.curves = materialize(self.plan, tables)
        result = self.run_plot()
        templates = {c.args[2] for c in self.origin.CreatePage.call_args_list if c.args[0] == 3}
        self.assertEqual(templates, {str(pv), str(iv)})
        self.assertEqual(result["graph_count"], 2)

    def test_explicit_xrd_measurement_uses_its_own_template_route(self):
        template = self.root / "XRD_2.otpu"
        template.write_bytes(b"synthetic-template")
        tables = load_tables([("xrd.csv", b"2Theta (deg),Intensity (cps)\n20,100\n21,200\n22,120")], self.root / "xrd")
        self.plan = default_plan(tables)
        self.plan["measurement"] = "manual"
        self.plan["curves"][0]["metadata"]["measurement_type"] = "XRD"
        self.plan["template_routes"] = {"XRD": str(template)}
        self.curves = materialize(self.plan, tables)
        result = self.run_plot()
        used = [c.args[2] for c in self.origin.CreatePage.call_args_list if c.args[0] == 3]
        self.assertEqual(used, [str(template)])
        self.assertEqual(result["graph_count"], 1)

    def test_numbered_cycle_voltages_reach_origin_without_reusing_v1(self):
        tables = load_tables([("cycles.csv", b"V1 [V],P1 [uC/cm2],V2 [V],P2 [uC/cm2]\n-1,-2,1,2\n0,1,0,-1\n1,2,-1,-2\n")], self.root / "raw")
        self.plan = default_plan(tables)
        self.plan["measurement"] = "PV"
        self.curves = materialize(self.plan, tables)
        result = self.run_plot()
        calls = self.origin.PutWorksheet.call_args_list
        self.assertEqual(calls[0].args[1], [-1., 0., 1.])
        self.assertEqual(calls[2].args[1], [1., 0., -1.])
        self.assertEqual(calls[3].args[1], [2., -1., -2.])
        self.assertEqual(self.columns[2].LongName, "V2 [V]")
        self.assertIn("source C: V2 [V]", self.columns[2].Comments)
        self.assertEqual(result["graph_count"], 1)

    def test_original_vplus_vminus_export_transfers_pv_only_once(self):
        from test_dual_voltage_export import original_export_data
        from v4_selection import constrain_plan
        tables = load_tables([("original_1.2V.dat", original_export_data())], self.root / "original")
        self.plan = constrain_plan(default_plan(tables), tables, "PV만 한 그래프에")
        self.curves = materialize(self.plan, tables)
        result = self.run_plot()
        self.assertEqual((result["curve_count"], result["graph_count"]), (1, 1))
        calls = self.origin.PutWorksheet.call_args_list
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0].args[1], [-1.9, -.8, .1, 1.2, 2.1, .9, -.1, -1.9])
        self.assertEqual(calls[1].args[1], [-4.8, -3.6, -1.3, 3.4, 5.3, 4.2, 1.4, -4.8])
        self.assertEqual(self.columns[0].LongName, "V+ [V]")

    def test_failure_reports_stage_and_cleans_com_without_saving(self):
        self.origin.Execute.side_effect = lambda command: not command.startswith("plotxy")
        with self.assertRaisesRegex(RuntimeError, "LabTalk 플롯 생성"):
            self.run_plot()
        self.origin.Save.assert_not_called()
        self.com.CoUninitialize.assert_called_once()

    def test_save_failure_is_reported_even_if_file_exists(self):
        def failed_save(path):
            Path(path).write_bytes(b"incomplete")
            return False
        self.origin.Save.side_effect = failed_save
        with self.assertRaisesRegex(RuntimeError, "OPJU 파일 저장"):
            self.run_plot()
        self.com.CoUninitialize.assert_called_once()


if __name__ == "__main__":
    unittest.main(verbosity=2)
