"""Literature evidence/citation regressions. All papers and values are synthetic."""
import copy
import io
import json
import os
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
import zipfile

import httpx
from openpyxl import load_workbook
from streamlit.testing.v1 import AppTest

from literature_core import (clean_doi,crossref_paper,search_papers,lookup_doi,manual_paper,save_papers,papers,
    attach_source,sources,save_observations,observations,review_values,build_benchmark,bibtex,ris,excel_bytes,
    word_bytes,pdf_pages,save_report,reports,literal_numbers)
from literature_agent import extract_values,evidence_batches,explain_benchmark,local_benchmark_rows,research_plan
from chat_agent import chat_turn
from lab_core import load_tables,default_plan,materialize,save_run

ITEM={'DOI':'10.9999/SYNTHETIC-ONLY-A','title':['Synthetic HZO device benchmark'],
      'author':[{'given':'A.','family':'Researcher'}],'published':{'date-parts':[[2025,1,2]]},'container-title':['Synthetic Journal']}
TEXT='Synthetic test only. The TiN/HZO/TiN device has 2Pr = 30 uC/cm2 at 1 kHz and 3 V (Table 1). Endurance = 10^6 cycles.'


def row(value=30,page=1,quote=TEXT):
    return {'metric':'2Pr','value':value,'unit':'uC/cm2','device':'TiN/HZO/TiN','conditions':{'frequency':'1 kHz','voltage':'3 V'},
            'page':page,'locator':'Table 1','quote':quote,'method':'reported_text'}


def model_client(document):
    return SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status='completed',output_text=json.dumps(document)))))


class LiteratureTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.db=self.root/'experiments.sqlite3'
        self.paper=crossref_paper(ITEM)
        save_papers(self.db,[self.paper])
        self.source=attach_source(self.db,self.paper['paper_id'],[{'page':1,'text':TEXT}],'synthetic table')

    def tearDown(self):self.temp.cleanup()

    def test_crossref_query_and_doi_are_bounded_and_metadata_deduplicated(self):
        captured=[]
        def respond(request):
            captured.append(request)
            body={'items':[ITEM,ITEM]} if request.url.path=='/works' else ITEM
            return httpx.Response(200,json={'message':body})
        with httpx.Client(transport=httpx.MockTransport(respond)) as client:
            found=search_papers('HZO multistate',7,2020,2026,client=client)
            self.assertEqual(len(found),1)
            self.assertEqual(captured[0].url.params['rows'],'7')
            self.assertIn('from-pub-date:2020',captured[0].url.params['filter'])
            self.assertEqual(lookup_doi('https://doi.org/10.9999/SYNTHETIC-ONLY-A',client=client)['paper_id'],self.paper['paper_id'])
        self.assertEqual(found[0]['metadata_source'],'Crossref')
        self.assertNotIn('value',found[0])

    def test_doi_rejects_arbitrary_url_and_http_error_is_actionable(self):
        for bad in ('http://127.0.0.1/private','javascript:foo','bad','10.99/x','10.9999/x\ny'):
            with self.subTest(bad=bad),self.assertRaises(ValueError):clean_doi(bad)
        with httpx.Client(transport=httpx.MockTransport(lambda req:httpx.Response(429))) as client:
            with self.assertRaisesRegex(ValueError,'Crossref 검색'):search_papers('topic',client=client)

    def test_manual_metadata_does_not_overwrite_crossref_and_library_deduplicates(self):
        save_papers(self.db,[self.paper,self.paper])
        weaker=manual_paper('Wrong title','Someone',2024,'Journal',self.paper['doi'])
        save_papers(self.db,[weaker])
        self.assertEqual(len(papers(self.db)),1)
        self.assertEqual(papers(self.db)[0]['title'],ITEM['title'][0])

    def test_all_values_preserve_quote_page_conditions_and_explicit_review(self):
        save_observations(self.db,self.source['source_id'],[row(),row()])
        values=observations(self.db)
        self.assertEqual(len(values),1)
        self.assertFalse(values[0]['reviewed'])
        self.assertEqual(values[0]['conditions']['frequency'],'1 kHz')
        self.assertEqual(values[0]['quote'],TEXT)
        review_values(self.db,[values[0]['value_id']])
        self.assertEqual(len(observations(self.db,True)),1)

    def test_fabricated_number_quote_page_and_unit_are_rejected_atomically(self):
        for change in ({'value':99},{'quote':'This number is not in the actual document 30 uC/cm2'},{'page':4},{'unit':'mC/cm2'},{'value':3}):
            candidate={**row(),**change}
            with self.subTest(change=change),self.assertRaises(ValueError):save_observations(self.db,self.source['source_id'],[row(),candidate])
            self.assertEqual(observations(self.db),[])

    def test_reported_scientific_notation_is_supported_without_physics_conversion(self):
        candidate={**row(),'metric':'Endurance','value':1e6,'unit':'cycles'}
        save_observations(self.db,self.source['source_id'],[candidate])
        self.assertEqual(observations(self.db)[0]['value'],1e6)
        self.assertIn(1e5,literal_numbers('Endurance 10⁵ cycles'))
        self.assertIn(2.5e6,literal_numbers('Endurance 2.5 × 10^6 cycles'))
        self.assertIn(30,literal_numbers('2Pr=30uC/cm²'))

    def test_table_header_units_require_explicit_review_before_benchmark(self):
        text='Synthetic table only\nTiN/HZO/TiN\n2Pr (uC/cm2)\n30'
        source=attach_source(self.db,self.paper['paper_id'],[{'page':1,'text':text}],'Table 2')
        candidate={**row(30,1,text),'conditions':{},'locator':'Table 2'}
        save_observations(self.db,source['source_id'],[candidate])
        report=build_benchmark(self.db,[self.paper['paper_id']],['2Pr'])
        self.assertIsNone(report['rows'][0]['value'])
        review_values(self.db,[observations(self.db)[0]['value_id']])
        self.assertEqual(build_benchmark(self.db,[self.paper['paper_id']],['2Pr'])['rows'][0]['value'],30)

    def test_unreported_device_or_condition_is_not_accepted(self):
        for change in ({'device':'Never-reported stack'},{'conditions':{'frequency':'999 kHz'}}):
            with self.subTest(change=change),self.assertRaises(ValueError):
                save_observations(self.db,self.source['source_id'],[{**row(),**change}])
        self.assertFalse(observations(self.db))

    def test_benchmark_never_fills_missing_pr_or_unreviewed_values(self):
        save_observations(self.db,self.source['source_id'],[row()])
        report=build_benchmark(self.db,[self.paper['paper_id']],['2Pr','Pr'])
        self.assertTrue(all(r['value'] is None for r in report['rows']))
        self.assertIn('N/R',report['markdown'])
        report=build_benchmark(self.db,[self.paper['paper_id']],['2Pr','Pr'],include_unreviewed=True)
        self.assertEqual(report['rows'][0]['value'],30)
        self.assertEqual(report['rows'][0]['status'],'원문 일치 · 미검토')
        self.assertIsNone(report['rows'][1]['value'])
        self.assertEqual(len(report['bibliography']),1)
        self.assertIn('[1]',report['markdown'])
        self.assertIn('https://doi.org/'+self.paper['doi'],report['markdown'])

    def test_distinct_conditions_are_not_averaged_or_collapsed(self):
        page2=TEXT.replace('30','40').replace('1 kHz','10 kHz')
        source=attach_source(self.db,self.paper['paper_id'],[{'page':1,'text':TEXT},{'page':2,'text':page2}],'two conditions')
        second={**row(40,2,page2),'conditions':{'frequency':'10 kHz','voltage':'3 V'}}
        save_observations(self.db,source['source_id'],[row(),second])
        report=build_benchmark(self.db,[self.paper['paper_id']],['2Pr'],include_unreviewed=True)
        self.assertEqual([r['value'] for r in report['rows']],[30,40])
        self.assertEqual({r['reference'] for r in report['rows']},{'[1]'})

    def test_report_snapshot_and_exports_have_the_same_citations(self):
        save_observations(self.db,self.source['source_id'],[row()]);review_values(self.db,[observations(self.db)[0]['value_id']])
        report=build_benchmark(self.db,[self.paper['paper_id']],['2Pr']);save_report(self.db,report)
        self.assertEqual(reports(self.db)[0]['rows'][0]['quote'],TEXT)
        workbook=load_workbook(io.BytesIO(excel_bytes(report)))
        self.assertEqual(workbook.sheetnames,['Benchmark','References'])
        self.assertIn('[1]',str(list(workbook['References'].values)))
        with zipfile.ZipFile(io.BytesIO(word_bytes(report))) as archive:
            xml=archive.read('word/document.xml').decode()
            self.assertIn('[1]',xml);self.assertIn(self.paper['doi'],xml)
        self.assertIn('doi = {'+self.paper['doi']+'}',bibtex(report['bibliography']))
        self.assertIn('DO  - '+self.paper['doi'],ris(report['bibliography']))

    def test_literal_content_does_not_create_excel_formulas_or_bibtex_entries(self):
        malicious=manual_paper('=HYPERLINK("x") {injected} & %','Author',2026)
        save_papers(self.db,[malicious])
        report=build_benchmark(self.db,[malicious['paper_id']],['metric'])
        workbook=load_workbook(io.BytesIO(excel_bytes(report)))
        title=list(workbook['Benchmark'].values)[1][2]
        self.assertTrue(title.startswith("'="))
        text=bibtex([malicious]);self.assertIn(r'\{injected\}',text);self.assertIn(r'\&',text)

    def test_api_extraction_validates_evidence_and_rejects_fabrication(self):
        good=row();good.pop('method');good['conditions']=[{'field':'frequency','value':'1 kHz'}]
        bad={**good,'value':99}
        client=model_client({'values':[good,bad]})
        found,rejected=extract_values(self.source,['2Pr'],[1],'offline','test',client=client)
        self.assertEqual(len(found),1);self.assertEqual(len(rejected),1)
        kwargs=client.responses.create.call_args.kwargs
        self.assertIn('VERBATIM',kwargs['instructions'])
        self.assertEqual(json.loads(kwargs['input'])['pages'][0]['page'],1)
        self.assertEqual(found[0]['conditions'],{'frequency':'1 kHz'})
        self.assertFalse(observations(self.db))  # extraction has no hidden DB mutation

    def test_selected_pages_and_batches_do_not_drop_text_or_accept_other_page(self):
        source={**self.source,'pages':[{'page':1,'text':'a'*10000},{'page':2,'text':TEXT}]}
        batches=evidence_batches(source,[1,2],size=4000)
        self.assertEqual(sum(p['page']==1 for batch in batches for p in batch),4)
        self.assertTrue(any(p['page']==2 for batch in batches for p in batch))
        with self.assertRaises(ValueError):evidence_batches(source,[3])
        with self.assertRaises(ValueError):evidence_batches(source,[])

    def test_incomplete_model_response_is_not_a_completed_extraction(self):
        client=SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status='incomplete',output_text='{}'))))
        with self.assertRaisesRegex(ValueError,'미완료'):extract_values(self.source,['2Pr'],[1],'offline','test',client=client)

    def test_ai_citations_use_only_supplied_sources_and_do_not_invent_numbers(self):
        save_observations(self.db,self.source['source_id'],[row()]);report=build_benchmark(self.db,[self.paper['paper_id']],['2Pr'],include_unreviewed=True)
        client=model_client({'statements':[{'text':'보고된 값은 30 uC/cm2이며 측정 조건을 확인해야 합니다.','paper_ids':[self.paper['paper_id']]}]})
        text=explain_benchmark(report,'설명','offline','test',client=client)
        self.assertIn('[1]',text)
        for statement in ({'text':'99 uC/cm2입니다.','paper_ids':[self.paper['paper_id']]}, {'text':'새 논문입니다.','paper_ids':['invented']}, {'text':'30 uC/cm2 [99]','paper_ids':[self.paper['paper_id']]}):
            with self.subTest(statement=statement),self.assertRaises(ValueError):explain_benchmark(report,'설명','offline','test',client=model_client({'statements':[statement]}))

    def test_local_repeat_points_and_db_tables_are_unchanged_by_literature(self):
        tables=load_tables([('synthetic.csv',b'Voltage (V),Polarization (uC/cm2)\n-2,-5\n0,-1\n2,5\n0,2\n-2,-5\n0,-1\n2,5\n0,2\n-2,-5')],self.root/'raw')
        plan=default_plan(tables);curves=materialize(plan,tables);save_run(self.db,'run','plot',plan,curves)
        with sqlite3.connect(self.db) as con:before=con.execute('SELECT * FROM points ORDER BY point_index').fetchall()
        rows,missing=local_benchmark_rows(curves,['2Pr'])
        self.assertTrue(rows);self.assertEqual(rows[0]['value'],3)
        report=build_benchmark(self.db,[self.paper['paper_id']],['2Pr'],local_rows=rows)
        self.assertEqual(report['rows'][-1]['reference'],'This work')
        with sqlite3.connect(self.db) as con:after=con.execute('SELECT * FROM points ORDER BY point_index').fetchall()
        self.assertEqual(before,after);self.assertEqual(len(curves[0].data),9)

    def test_missing_library_reads_do_not_create_measurement_database(self):
        absent=self.root/'absent.sqlite3'
        self.assertEqual(papers(absent),[]);self.assertEqual(sources(absent),[]);self.assertEqual(observations(absent),[]);self.assertEqual(reports(absent),[])
        self.assertFalse(absent.exists())

    def test_scanned_pdf_and_text_pdf_are_distinguished(self):
        from pypdf import PdfWriter
        writer=PdfWriter();writer.add_blank_page(width=600,height=800);content=io.BytesIO();writer.write(content)
        with self.assertRaisesRegex(ValueError,'스캔'):pdf_pages(content.getvalue())
        from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject
        writer=PdfWriter();page=writer.add_blank_page(width=600,height=800)
        font=DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/Helvetica')})
        page[NameObject('/Resources')]=DictionaryObject({NameObject('/Font'):DictionaryObject({NameObject('/F1'):writer._add_object(font)})})
        stream=DecodedStreamObject();stream.set_data(b'BT /F1 12 Tf 40 740 Td (Synthetic 2Pr = 30 uC/cm2) Tj ET')
        page[NameObject('/Contents')]=writer._add_object(stream)
        content=io.BytesIO();writer.write(content)
        pages=pdf_pages(content.getvalue())
        self.assertEqual(pages[0]['page'],1);self.assertIn('30',pages[0]['text'])

    def test_literature_chat_routes_without_plotting_or_an_extra_router_call(self):
        client=Mock()
        decision=chat_turn([], 'HZO 논문 레퍼 찾아서 벤치마킹 테이블 만들어줘',{},'offline','test',client)
        self.assertEqual(decision['action'],'literature');client.responses.create.assert_not_called()
        plan=research_plan('HZO 2Pr 비교','offline','test',client=model_client({'query':'HZO ferroelectric remanent polarization','metrics':['2Pr']}))
        self.assertEqual(plan['metrics'],['2Pr'])


class LiteratureWebTests(unittest.TestCase):
    def test_search_attach_extract_review_build_and_export_without_origin_calls(self):
        def choose(elements,label):return next(e for e in elements if e.label==label)
        with tempfile.TemporaryDirectory() as folder, patch('literature_ui.search_papers',return_value=[crossref_paper(ITEM)]) as search, patch('origin_adapter.plot_origin') as origin, patch('lab_core.ai_plan') as plot:
            app=AppTest.from_file(str(Path(__file__).with_name('agent_origin2020_openai.py'))).run(timeout=30)
            app.sidebar.text_input[0].set_value(folder).run()
            choose(app.text_input,'논문 검색어').set_value('synthetic HZO')
            choose(app.button,'논문 찾기').click().run(timeout=30)
            choose(app.multiselect,'라이브러리에 추가할 검색 논문').set_value([crossref_paper(ITEM)['paper_id']])
            choose(app.button,'선택 논문 저장').click().run()
            choose(app.text_area,'표·본문 텍스트 붙여넣기 (PDF 대신 사용 가능)').set_value(TEXT)
            choose(app.button,'이 논문에 원문 등록').click().run()
            db=Path(folder)/'experiments.sqlite3';source=sources(db)[0]
            with patch('literature_ui.extract_values',return_value=([row()],[])) as extraction,patch.dict(os.environ,{'OPENAI_API_KEY':'offline-only'}):
                choose(app.button,'요청 지표를 원문에서 자동 추출').click().run(timeout=30)
            self.assertFalse(app.exception)
            values=observations(db)
            self.assertEqual(len(values),1)
            choose(app.multiselect,'원문과 정의·조건을 확인한 수치').set_value([values[0]['value_id']])
            choose(app.button,'선택 수치 검토 완료로 표시').click().run()
            choose(app.button,'벤치마킹 표 생성 · 번호 인용 자동 연결').click().run(timeout=30)
            self.assertFalse(app.exception);self.assertFalse(app.error)
            report=reports(db)[0]
            self.assertEqual(report['rows'][0]['value'],30)
            self.assertIn('[1]',report['markdown'])
            labels=[b.label for b in app.get('download_button')]
            self.assertIn('BibTeX 참고문헌',labels);self.assertIn('RIS · Zotero/EndNote 가져오기',labels)
            choose(app.button,'Word 보고서 준비').click().run(timeout=30)
            self.assertFalse(app.exception);self.assertIn('인용 포함 Word 보고서',[b.label for b in app.get('download_button')])
            origin.assert_not_called();plot.assert_not_called();search.assert_called_once()

    def test_chat_search_creates_cited_nr_table_without_inventing_literature_values(self):
        paper=crossref_paper(ITEM)
        with tempfile.TemporaryDirectory() as folder,patch.dict(os.environ,{'OPENAI_API_KEY':'offline-only'}),patch('literature_agent.research_plan',return_value={'query':'synthetic HZO','metrics':['2Pr']}) as plan,patch('literature_core.search_papers',return_value=[paper]),patch('origin_adapter.plot_origin') as origin:
            # The app imports symbols on each execution; patch their providers.
            app=AppTest.from_file(str(Path(__file__).with_name('agent_origin2020_openai.py'))).run(timeout=30)
            app.sidebar.text_input[0].set_value(folder).run()
            app.chat_input[0].set_value('HZO 논문 찾아서 2Pr 벤치마킹 표 만들어줘').run(timeout=30)
            self.assertFalse(app.exception)
            content=app.session_state['chat_messages'][-1]['content']
            self.assertIn('N/R',content);self.assertIn('[1]',content);self.assertIn(paper['doi'],content)
            self.assertFalse(observations(Path(folder)/'experiments.sqlite3'))
            origin.assert_not_called();plan.assert_called_once()


if __name__=='__main__':unittest.main(verbosity=2)
