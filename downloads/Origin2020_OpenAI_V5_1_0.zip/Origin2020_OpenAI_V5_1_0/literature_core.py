"""Evidence-linked literature library and deterministic benchmark/citation exports."""
from __future__ import annotations

from contextlib import closing
from datetime import datetime, timezone
import hashlib
import html
import io
import json
import math
from pathlib import Path
import re
import sqlite3
import unicodedata
from urllib.parse import quote

import httpx
import pandas as pd

SCHEMA = """
CREATE TABLE IF NOT EXISTS lit_papers (
 paper_id TEXT PRIMARY KEY, doi TEXT UNIQUE, metadata_json TEXT NOT NULL, added_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS lit_sources (
 source_id TEXT PRIMARY KEY, paper_id TEXT NOT NULL REFERENCES lit_papers(paper_id),
 content_json TEXT NOT NULL, added_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS lit_values (
 value_id TEXT PRIMARY KEY, paper_id TEXT NOT NULL REFERENCES lit_papers(paper_id),
 source_id TEXT NOT NULL REFERENCES lit_sources(source_id), value_json TEXT NOT NULL,
 reviewed INTEGER NOT NULL DEFAULT 0, added_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS lit_reports (
 report_id TEXT PRIMARY KEY, report_json TEXT NOT NULL, added_at TEXT NOT NULL);
"""


def utc():
    return datetime.now(timezone.utc).isoformat()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def clean_doi(value):
    text = str(value).strip()
    text = re.sub(r'^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)', '', text, flags=re.I)
    if not re.fullmatch(r'10\.\d{4,9}/[^\s<>"{}]+', text, re.I) or len(text) > 250:
        raise ValueError('유효한 DOI를 입력하세요. 예: 10.xxxx/논문식별자')
    return text.lower()


def _plain(value):
    return html.unescape(re.sub(r'<[^>]*>', '', str(value))).strip()


def crossref_paper(item):
    doi = clean_doi(item['DOI'])
    dates = item.get('published', item.get('published-print', item.get('published-online', {}))).get('date-parts', [])
    year = dates[0][0] if dates and dates[0] else None
    authors = [' '.join(filter(None, (a.get('given'), a.get('family')))) or a.get('name', '') for a in item.get('author', [])]
    def first(field):
        v = item.get(field, [])
        return _plain(v[0]) if isinstance(v, list) and v else _plain(v) if isinstance(v, str) else ''
    title = first('title')
    if not title:
        raise ValueError('제목이 없는 Crossref 항목입니다.')
    return {'paper_id': fingerprint(doi)[:24], 'doi': doi, 'title': title, 'authors': authors,
            'year': year, 'journal': first('container-title'), 'volume': str(item.get('volume', '')),
            'issue': str(item.get('issue', '')), 'pages': str(item.get('page', '')),
            'url': 'https://doi.org/' + doi, 'metadata_source': 'Crossref', 'retrieved_at': utc()}


def search_papers(query, limit=10, year_from=None, year_to=None, *, client=None):
    if not isinstance(query, str) or not query.strip() or len(query) > 1000 or type(limit) is not int or not 1 <= limit <= 50:
        raise ValueError('검색어와 논문 수(1~50)를 확인하세요.')
    params = {'query.bibliographic': query.strip(), 'rows': limit,
              'select': 'DOI,title,author,published,container-title,volume,issue,page'}
    filters = []
    for key, year in (('from-pub-date', year_from), ('until-pub-date', year_to)):
        if year is not None:
            if type(year) is not int or not 1800 <= year <= 2200:
                raise ValueError('검색 연도를 확인하세요.')
            filters.append(f'{key}:{year}')
    if year_from and year_to and year_from > year_to:
        raise ValueError('시작 연도가 끝 연도보다 큽니다.')
    if filters:
        params['filter'] = ','.join(filters)
    return _crossref('/works', params, client)


def lookup_doi(doi, *, client=None):
    return _crossref('/works/' + quote(clean_doi(doi), safe=''), None, client)[0]


def _crossref(path, params, client):
    owned = client is None
    client = client or httpx.Client(timeout=25, follow_redirects=False, headers={'User-Agent': 'OriginLab-Literature/5.1 (Crossref metadata search)'})
    try:
        response = client.get('https://api.crossref.org' + path, params=params)
        response.raise_for_status()
        body = response.json()['message']
        items = body['items'] if 'items' in body else [body]
        found = {}
        for item in items:
            try:
                paper = crossref_paper(item)
            except (KeyError, TypeError, ValueError):
                continue
            found.setdefault(paper['paper_id'], paper)
        if path != '/works' and not found:
            raise ValueError('DOI의 논문 메타데이터를 확인하지 못했습니다.')
        return list(found.values())
    except (httpx.HTTPError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise ValueError('Crossref 검색에 실패했습니다. 인터넷 연결·접근 제한을 확인하거나 DOI/논문 정보를 직접 등록하세요.') from exc
    finally:
        if owned:
            client.close()


def manual_paper(title, authors='', year=None, journal='', doi=''):
    if not title.strip():
        raise ValueError('논문 제목을 입력하세요.')
    doi = clean_doi(doi) if doi.strip() else None
    return {'paper_id': fingerprint(doi or [title.strip(), authors.strip(), year])[:24], 'doi': doi,
            'title': title.strip(), 'authors': [a.strip() for a in authors.split(';') if a.strip()],
            'year': year, 'journal': journal.strip(), 'volume': '', 'issue': '', 'pages': '',
            'url': 'https://doi.org/' + doi if doi else '', 'metadata_source': '사용자 입력 · 서지 미검증'}


def _connect(db):
    from lab_core import connect_db
    con = connect_db(Path(db))
    con.execute('PRAGMA foreign_keys=ON')
    con.executescript(SCHEMA)
    return con


def _read(db, table):
    path = Path(db)
    if not path.is_file():
        return []
    with closing(sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True)) as con:
        if not con.execute('SELECT 1 FROM sqlite_master WHERE type=? AND name=?', ('table', table)).fetchone():
            return []
        return con.execute('SELECT * FROM ' + table + ' ORDER BY rowid').fetchall()


def papers(db):
    return [json.loads(row[2]) for row in _read(db, 'lit_papers')]


def save_papers(db, entries):
    validated = []
    for entry in entries:
        item = dict(entry)
        if not item.get('title') or not item.get('paper_id'):
            raise ValueError('논문 제목과 식별자가 필요합니다.')
        if item.get('doi'):
            item['doi'] = clean_doi(item['doi'])
        validated.append(item)
    with closing(_connect(db)) as con, con:
        for item in validated:
            old = con.execute('SELECT metadata_json FROM lit_papers WHERE paper_id=?', (item['paper_id'],)).fetchone()
            if old and json.loads(old[0]).get('metadata_source') == 'Crossref' and item.get('metadata_source') != 'Crossref':
                continue
            con.execute('INSERT INTO lit_papers VALUES(?,?,?,?) ON CONFLICT(paper_id) DO UPDATE SET metadata_json=excluded.metadata_json',
                        (item['paper_id'], item.get('doi'), json.dumps(item, ensure_ascii=False), utc()))
    return len(validated)


def pdf_pages(content):
    if not content or len(content) > 32 * 1024 * 1024:
        raise ValueError('PDF는 32 MB 이하로 올려주세요.')
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ValueError('PDF 읽기에 pypdf가 필요합니다. 업데이트 후 01_install.bat를 실행하세요.') from exc
    try:
        reader = PdfReader(io.BytesIO(content))
        if reader.is_encrypted and not reader.decrypt(''):
            raise ValueError('암호가 걸린 PDF입니다.')
        pages = [{'page': i + 1, 'text': page.extract_text() or ''} for i, page in enumerate(reader.pages)]
    except Exception as exc:
        raise ValueError('PDF 문자를 읽지 못했습니다. 표·본문 텍스트를 붙여넣어 등록할 수 있습니다.') from exc
    if not any(p['text'].strip() for p in pages):
        raise ValueError('텍스트가 없는 스캔 PDF입니다. 필요한 표·본문을 텍스트로 입력하세요. 그림 수치를 임의로 읽지 않습니다.')
    return pages


def attach_source(db, paper_id, pages, label, kind='text'):
    if paper_id not in {p['paper_id'] for p in papers(db)}:
        raise ValueError('먼저 연결할 논문을 등록하세요.')
    if kind not in ('text', 'pdf') or not pages or len(pages) > 1000:
        raise ValueError('원문 형식을 확인하세요.')
    for page in pages:
        if set(page) != {'page', 'text'} or type(page['page']) is not int or page['page'] < 1 or not isinstance(page['text'], str):
            raise ValueError('페이지와 원문 텍스트를 확인하세요.')
    if len({p['page'] for p in pages}) != len(pages) or sum(len(p['text']) for p in pages) > 3_000_000:
        raise ValueError('원문 페이지 중복 또는 문서 크기를 확인하세요.')
    source_id = fingerprint([paper_id, pages])[:32]
    source = {'source_id': source_id, 'paper_id': paper_id, 'kind': kind, 'label': str(label)[:200],
              'pages': pages, 'association': '사용자가 선택한 논문에 연결한 원문 · 문서 동일성 자동 검증 아님'}
    with closing(_connect(db)) as con, con:
        con.execute('INSERT OR IGNORE INTO lit_sources VALUES(?,?,?,?)', (source_id, paper_id, json.dumps(source, ensure_ascii=False), utc()))
    return source


def sources(db, paper_id=None):
    rows = [json.loads(row[2]) for row in _read(db, 'lit_sources')]
    return [r for r in rows if paper_id is None or r['paper_id'] == paper_id]


def normalize(text):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', str(text))).replace('μ', 'u').replace('µ', 'u').replace('−', '-').replace('^', '')


def _number_text(text):
    """Normalize number notation while keeping units and metric definitions intact."""
    superscripts=str.maketrans('⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺','0123456789-+')
    text=re.sub(r'([⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺]+)',lambda m:'^'+m[1].translate(superscripts),str(text))
    text=unicodedata.normalize('NFKC',text).replace('−','-')
    power=r'(?:(\d+(?:\.\d+)?)\s*[×x*]\s*)?10\s*\^\s*\{?([+-]?\d+)\}?'
    def expand(match):
        try:return ' '+str(float(match[1] or 1)*10.**int(match[2]))+' '
        except OverflowError:return ' invalid-number '
    text=re.sub(power,expand,text)
    text=re.sub(r'(?<=\d),(?=\d{3}(?:\D|$))','',text)
    return text


def literal_numbers(text):
    text = _number_text(text)
    tokens=re.findall(r'(?<![\w.])[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?![\d.])',text)
    return {float(token) for token in tokens if math.isfinite(float(token))}


def validate_observation(source, item):
    fields = {'metric', 'value', 'unit', 'device', 'conditions', 'page', 'locator', 'quote', 'method'}
    if not isinstance(item, dict) or set(item) != fields:
        raise ValueError('추출 수치의 필드를 확인하세요.')
    if type(item['value']) not in (int, float) or not math.isfinite(item['value']):
        raise ValueError('문헌 값은 유한한 숫자여야 합니다.')
    if type(item['page']) is not int or item['page'] < 1:
        raise ValueError('근거 페이지는 1 이상의 정수여야 합니다.')
    if any(not isinstance(item[k], str) or len(item[k]) > 2000 for k in ('metric', 'unit', 'device', 'locator', 'quote', 'method')) or not item['metric'].strip():
        raise ValueError('추출 지표·단위·근거 형식을 확인하세요.')
    if item['method'] not in ('reported_text', 'manual_transcription'):
        raise ValueError('텍스트에 보고된 값을 사용하세요. 그림 추정/계산 변환은 지원하지 않습니다.')
    if not isinstance(item['conditions'], dict) or len(item['conditions']) > 30 or any(not isinstance(k, str) or not isinstance(v, str) or len(k) > 100 or len(v) > 500 for k,v in item['conditions'].items()):
        raise ValueError('측정 조건은 이름과 원문 값으로 입력하세요.')
    page = next((p for p in source['pages'] if p['page'] == item['page']), None)
    if page is None or len(item['quote'].strip()) < 8 or normalize(item['quote']) not in normalize(page['text']):
        raise ValueError('근거 인용문이 지정 페이지의 원문과 일치하지 않습니다.')
    if item['device'] and normalize(item['device']) not in normalize(page['text']):
        raise ValueError('소자 구조가 근거 페이지에 그대로 보고되어 있지 않습니다.')
    if any(value and normalize(value) not in normalize(page['text']) for value in item['conditions'].values()):
        raise ValueError('측정 조건이 근거 페이지에 보고되어 있지 않습니다.')
    if float(item['value']) not in literal_numbers(item['quote']):
        raise ValueError('숫자가 근거 인용문에 그대로 보고되어 있지 않습니다. 계산·단위 변환으로 만들지 마세요.')
    if item['unit']:
        unit = normalize(item['unit'])
        number = r'(?<![\d.,])([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)'
        uncertainty = r'(?:±[\d.]+)?'
        pairs = re.findall(number + uncertainty + r'[({]?' + re.escape(unit), normalize(_number_text(item['quote'])))
        if not any(float(value) == float(item['value']) for value in pairs):
            table = '\n' in item['quote'] and bool(re.search(r'table|표', item['locator'], re.I))
            if normalize(item['unit']) not in normalize(item['quote']) or not (table or item['method'] == 'manual_transcription'):
                raise ValueError('숫자와 단위가 원문에서 한 값으로 대응하지 않습니다. 다른 열의 숫자를 연결하지 마세요.')
            # Separated table headers / explicit manual transcriptions remain
            # unreviewed; column semantics require a human check before export.
    return dict(item)


def save_observations(db, source_id, items):
    source = next((s for s in sources(db) if s['source_id'] == source_id), None)
    if source is None:
        raise ValueError('연결된 원문을 찾지 못했습니다.')
    validated = [validate_observation(source, item) for item in items]
    with closing(_connect(db)) as con, con:
        for item in validated:
            value_id = fingerprint([source_id, item])[:32]
            con.execute('INSERT OR IGNORE INTO lit_values VALUES(?,?,?,?,?,?)',
                        (value_id, source['paper_id'], source_id, json.dumps(item, ensure_ascii=False), 0, utc()))
    return len(validated)


def observations(db, reviewed_only=False):
    return [dict(json.loads(row[3]), value_id=row[0], paper_id=row[1], source_id=row[2], reviewed=bool(row[4]))
            for row in _read(db, 'lit_values') if not reviewed_only or row[4]]


def review_values(db, ids):
    ids = list(dict.fromkeys(ids))
    known = {v['value_id'] for v in observations(db)}
    if not ids or set(ids) - known:
        raise ValueError('검토할 문헌 수치를 선택하세요.')
    with closing(_connect(db)) as con, con:
        con.executemany('UPDATE lit_values SET reviewed=1 WHERE value_id=?', [(value,) for value in ids])


def reference_text(paper):
    author = ', '.join(paper.get('authors') or []) or '저자 미등록'
    text = f"{author}. {paper['title']}. {paper.get('journal') or ''} ({paper.get('year') or '연도 미등록'})."
    return text + (' https://doi.org/' + paper['doi'] if paper.get('doi') else '')


def _cell(value):
    return str(value).replace('|', '\\|').replace('\n', ' ')


def build_benchmark(db, paper_ids, metrics, *, include_unreviewed=False, local_rows=None):
    requested = list(dict.fromkeys(m.strip() for m in metrics if m.strip()))
    selected = list(dict.fromkeys(paper_ids))
    library = {p['paper_id']: p for p in papers(db)}
    if not selected or set(selected) - set(library) or not requested:
        raise ValueError('비교할 논문과 지표를 선택하세요.')
    bibliography = [library[pid] for pid in selected]
    numbers = {p['paper_id']: i+1 for i,p in enumerate(bibliography)}
    values = [v for v in observations(db, not include_unreviewed) if v['paper_id'] in selected and v['metric'] in requested]
    rows = []
    for pid in selected:
        paper = library[pid]
        for metric in requested:
            found = [v for v in values if v['paper_id'] == pid and v['metric'] == metric]
            if not found:
                found = [{'value': None, 'unit': '', 'device': '', 'conditions': {}, 'page': None, 'locator': '', 'quote': '', 'reviewed': False}]
            for item in found:
                rows.append({'reference': f'[{numbers[pid]}]', 'paper_id': pid, 'title': paper['title'], 'year': paper.get('year'),
                    'metric': metric, 'value': item['value'], 'unit': item['unit'], 'device': item['device'],
                    'conditions': json.dumps(item['conditions'],ensure_ascii=False), 'page': item['page'],
                    'locator': item['locator'], 'quote': item['quote'], 'doi': paper.get('doi') or '',
                    'status': '원문 값 없음 / 검토된 값 없음' if item['value'] is None else '사용자 검토 완료' if item['reviewed'] else '원문 일치 · 미검토',
                    'metadata_source': paper['metadata_source'], 'source_id': item.get('source_id','')})
    for item in local_rows or []:
        if item['metric'] in requested:
            rows.append({'reference': 'This work', 'paper_id': '', 'title': item['label'], 'year': None,
                'metric': item['metric'], 'value': item['value'], 'unit': item['unit'], 'device': item.get('device',''),
                'conditions': json.dumps(item.get('conditions',{}),ensure_ascii=False), 'page': None, 'locator': item.get('locator',''),
                'quote': '', 'doi': '', 'status': item.get('status','로컬 계산'), 'metadata_source': '실험 DB/현재 선택 점', 'source_id': item.get('curve_id','')})
    report = {'report_id': fingerprint([utc(), selected, rows])[:32], 'created_at': utc(), 'paper_ids': selected,
              'metrics': requested, 'rows': rows, 'bibliography': bibliography, 'include_unreviewed': include_unreviewed}
    report['markdown'] = benchmark_markdown(report)
    return report


def benchmark_markdown(report):
    lines = ['문헌 벤치마킹 표', '', '| 출처 | 논문/측정 | 지표 | 값 | 단위 | 소자 | 측정 조건 | 근거 위치 | 상태 |', '|---|---|---|---:|---|---|---|---|---|']
    for row in report['rows']:
        location = f"p.{row['page']} {row['locator']}" if row['page'] else row['locator']
        values = [row['reference'],row['title'],row['metric'],'N/R' if row['value'] is None else row['value'],row['unit'],row['device'],row['conditions'],location,row['status']]
        lines.append('| ' + ' | '.join(_cell(v) for v in values) + ' |')
    lines += ['', '조건·정의·단위가 다른 값은 그대로 병기합니다. 이 표만으로 우열·직접 비교 가능성을 판정하거나 수치를 변환하지 않습니다.', '', '참고문헌', '']
    for i,paper in enumerate(report['bibliography'],1):
        lines.append(f'[{i}] {reference_text(paper)}')
    return '\n'.join(lines)


def save_report(db, report):
    with closing(_connect(db)) as con, con:
        con.execute('INSERT OR IGNORE INTO lit_reports VALUES(?,?,?)', (report['report_id'],json.dumps(report,ensure_ascii=False,allow_nan=False),utc()))


def reports(db):
    return [json.loads(row[1]) for row in _read(db,'lit_reports')]


def _bib_escape(text):
    return ''.join({'\\':r'\textbackslash{}','{':r'\{','}':r'\}','%':r'\%','&':r'\&','_':r'\_','#':r'\#'}.get(c,c) for c in str(text)).replace('\n',' ')


def bibtex(entries):
    blocks=[]
    for paper in entries:
        fields={'title':paper['title'],'author':' and '.join(paper.get('authors') or []),'journal':paper.get('journal'),
                'year':paper.get('year'),'volume':paper.get('volume'),'number':paper.get('issue'),'pages':paper.get('pages'),'doi':paper.get('doi')}
        body=',\n'.join(f'  {k} = {{{_bib_escape(v)}}}' for k,v in fields.items() if v not in (None,''))
        blocks.append('@article{ref'+paper['paper_id']+',\n'+body+'\n}')
    return '\n\n'.join(blocks)+'\n'


def ris(entries):
    blocks=[]
    for p in entries:
        lines=['TY  - JOUR','TI  - '+_cell(p['title'])]+['AU  - '+_cell(a) for a in p.get('authors') or []]
        lines += [key+'  - '+_cell(value) for key,value in [('PY',p.get('year')),('JO',p.get('journal')),('DO',p.get('doi')),('UR',p.get('url'))] if value not in (None,'')]
        blocks.append('\n'.join(lines+['ER  - ']))
    return '\n\n'.join(blocks)+'\n'


def excel_bytes(report):
    output=io.BytesIO()
    def safe(frame):
        return frame.map(lambda v:"'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v)
    with pd.ExcelWriter(output,engine='openpyxl') as writer:
        safe(pd.DataFrame(report['rows'])).to_excel(writer,sheet_name='Benchmark',index=False)
        safe(pd.DataFrame([{'reference':f'[{i}]','citation':reference_text(p),'doi':p.get('doi')} for i,p in enumerate(report['bibliography'],1)])).to_excel(writer,sheet_name='References',index=False)
    return output.getvalue()


def word_bytes(report):
    try:
        from docx import Document
    except ImportError as exc:
        raise ValueError('Word 내보내기에 python-docx가 필요합니다. 01_install.bat를 실행하세요.') from exc
    document=Document();document.add_heading('문헌 벤치마킹',level=1)
    if report.get('narrative'):
        document.add_paragraph(report['narrative'])
    table=document.add_table(rows=1,cols=6);table.style='Table Grid'
    for cell,title in zip(table.rows[0].cells,['출처','논문/측정','지표','값·단위','조건','근거·상태']):cell.text=title
    for row in report['rows']:
        values=[row['reference'],row['title'],row['metric'],('N/R' if row['value'] is None else str(row['value']))+' '+row['unit'],row['conditions'],f"p.{row['page'] or '—'} {row['locator']} · {row['status']}"]
        for cell,value in zip(table.add_row().cells,values):cell.text=value
    document.add_paragraph('조건·정의·단위가 다른 값은 병기한 값입니다. 직접 비교 가능성을 별도로 확인하세요.')
    document.add_heading('참고문헌',level=1)
    for i,p in enumerate(report['bibliography'],1):document.add_paragraph(f'[{i}] {reference_text(p)}')
    output=io.BytesIO();document.save(output);return output.getvalue()
