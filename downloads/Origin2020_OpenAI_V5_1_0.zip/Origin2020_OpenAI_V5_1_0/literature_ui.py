"""Literature search, source-linked extraction, benchmark and reference controls."""
import json
from pathlib import Path

import pandas as pd
import streamlit as st

from literature_core import (search_papers, lookup_doi, manual_paper, papers, save_papers, pdf_pages,
    attach_source, sources, save_observations, observations, review_values, build_benchmark,
    bibtex, ris, excel_bytes, word_bytes, save_report, reports, fingerprint, benchmark_markdown)
from literature_agent import extract_values, local_benchmark_rows, explain_benchmark


def render_literature(db, workspace, get_key, model, current=None):
    st.subheader('논문 검색 · 벤치마킹 · 자동 인용')
    st.caption('논문 검색은 Crossref 서지 정보와 DOI를 사용합니다. 성능 수치는 연결한 PDF/원문에서 추출하며, 각 값에 원문·페이지·조건과 검토 상태를 남깁니다.')
    prefix='lit_'+fingerprint(str(Path(db).resolve()))[:10]+'_'
    def key(name):return prefix+name
    kind={c.spec['metadata'].get('measurement_type') for c in current['curves']} if current else set()
    default_metrics='2Pr, Vc+, Vc-, Imprint' if kind=={'PV'} else 'Y max, Peak X, FWHM' if kind else '2Pr, Ec, Endurance'
    previous=st.session_state.get(key('last_metric_default'))
    if key('metrics') in st.session_state and st.session_state[key('metrics')]==previous:
        st.session_state[key('metrics')]=default_metrics
    st.session_state[key('last_metric_default')]=default_metrics
    metric_text=st.text_input('벤치마킹 지표 (쉼표로 구분 · 자유 입력)',value=default_metrics,key=key('metrics'),
        help='원문의 Pr와 2Pr, Ec와 Vc를 구분하세요. 지표 이름이 같아야 한 항목으로 묶습니다. PV/IV 외 지표도 입력할 수 있습니다.')
    metrics=list(dict.fromkeys(m.strip() for m in metric_text.split(',') if m.strip()))
    with st.expander('① 논문 검색 · DOI 등록',expanded=True):
        with st.form(key('search_form')):
            query=st.text_input('논문 검색어',placeholder='예: HZO ferroelectric multilevel endurance',key=key('query'))
            count=st.number_input('검색할 논문 수',min_value=1,max_value=50,value=10,key=key('count'))
            years=st.text_input('검색 연도 범위 (선택)',placeholder='예: 2018-2026',key=key('years'))
            search=st.form_submit_button('논문 찾기')
        if search:
            try:
                bounds=[int(y.strip()) for y in years.split('-')] if years.strip() else [None,None]
                if len(bounds)!=2:raise ValueError('연도 범위는 2018-2026 형식으로 입력하세요.')
                with st.spinner('Crossref 논문 메타데이터 조회 중…'):
                    st.session_state[key('search_results')]=search_papers(query,int(count),*bounds)
                st.success('검색 결과를 불러왔습니다. 원문 수치까지 확인한 결과는 아닙니다.')
            except Exception as exc:st.error(str(exc))
        found=st.session_state.get(key('search_results'),[])
        if found:
            st.dataframe(pd.DataFrame([{k:p.get(k) for k in ('title','year','journal','doi')} for p in found]),hide_index=True,width='stretch')
            by_id={p['paper_id']:p for p in found}
            chosen=st.multiselect('라이브러리에 추가할 검색 논문',list(by_id),format_func=lambda pid:by_id[pid]['title'],key=key('found_chosen'))
            if st.button('선택 논문 저장',key=key('save_search')):
                try:
                    if not chosen:raise ValueError('저장할 검색 논문을 선택하세요.')
                    save_papers(db,[by_id[pid] for pid in chosen]);st.success('논문과 DOI를 저장했습니다.')
                except Exception as exc:st.error(str(exc))
        doi=st.text_input('DOI로 논문 추가',placeholder='10.xxxx/… 또는 https://doi.org/…',key=key('doi'))
        if st.button('DOI 확인 · 저장',key=key('lookup')):
            try:
                with st.spinner('DOI 메타데이터 확인 중…'):paper=lookup_doi(doi)
                save_papers(db,[paper]);st.success('저장: '+paper['title'])
            except Exception as exc:st.error(str(exc))
        with st.expander('논문 정보 직접 입력 (검색 연결이 어려울 때)'):
            with st.form(key('manual_paper_form')):
                title=st.text_input('논문 제목',key=key('manual_title'))
                authors=st.text_input('저자 (세미콜론으로 구분)',key=key('manual_authors'))
                year=st.number_input('발행 연도',min_value=1800,max_value=2200,value=2026,key=key('manual_year'))
                journal=st.text_input('저널',key=key('manual_journal'))
                manual_doi=st.text_input('DOI (선택 · 직접 입력한 서지는 미검증으로 표시)',key=key('manual_doi'))
                register=st.form_submit_button('논문 정보 등록')
            if register:
                try:
                    save_papers(db,[manual_paper(title,authors,int(year),journal,manual_doi)]);st.success('직접 입력한 서지 정보를 저장했습니다.')
                except Exception as exc:st.error(str(exc))
    library=papers(db)
    if not library:
        st.info('논문을 검색해 저장하거나 DOI/서지 정보를 등록하면 원문 수치 추출과 벤치마킹 표를 사용할 수 있습니다.')
        return
    by_id={p['paper_id']:p for p in library}
    with st.expander('② PDF · 원문 연결과 수치 추출'):
        pid=st.selectbox('원문을 연결할 논문',list(by_id),format_func=lambda i:by_id[i]['title'],key=key('source_paper'))
        st.caption('선택한 논문의 원문인지 확인해 연결하세요. 문서 동일성을 자동 검증한 것으로 표시하지 않습니다. 선택한 원문 텍스트는 AI 추출 시 OpenAI에 전송됩니다.')
        uploaded=st.file_uploader('논문 PDF (선택)',type=['pdf'],key=key('pdf'))
        pasted=st.text_area('표·본문 텍스트 붙여넣기 (PDF 대신 사용 가능)',height=120,key=key('paste'))
        page=st.number_input('붙여넣은 원문의 페이지',min_value=1,value=1,key=key('page'))
        locator=st.text_input('원문 구분명',placeholder='예: 본문 Table 1 또는 Supporting information',key=key('source_label'))
        if st.button('이 논문에 원문 등록',key=key('attach')):
            try:
                if uploaded:
                    pages=pdf_pages(uploaded.getvalue());label=locator or uploaded.name;kind='pdf'
                elif pasted.strip():pages=[{'page':int(page),'text':pasted}];label=locator or '붙여넣은 원문';kind='text'
                else:raise ValueError('PDF를 선택하거나 필요한 표·본문 텍스트를 붙여넣으세요.')
                attach_source(db,pid,pages,label,kind);st.success('원문 텍스트와 페이지를 보관했습니다.')
            except Exception as exc:st.error(str(exc))
        available=sources(db,pid)
        if available:
            by_source={s['source_id']:s for s in available}
            sid=st.selectbox('추출할 원문',list(by_source),format_func=lambda i:by_source[i]['label']+' · '+i[:8],key=key('source_'+pid))
            source=by_source[sid]
            page_ids=[p['page'] for p in source['pages']]
            selected_pages=st.multiselect('AI에 전달할 페이지',page_ids,default=page_ids,key=key('pages_'+sid))
            if st.button('요청 지표를 원문에서 자동 추출',key=key('extract')):
                try:
                    progress=st.empty()
                    found,rejected=extract_values(source,metrics,selected_pages,get_key(),model,
                        on_progress=lambda n,total:progress.caption(f'원문 묶음 {n}/{total} 분석 중…'))
                    progress.empty();save_observations(db,sid,found)
                    st.session_state[key('rejected')]=rejected
                    st.success(f'원문 근거가 일치하는 후보 {len(found)}개를 저장했습니다. 인용문과 정의·측정 조건을 확인하세요.')
                except Exception as exc:st.error(str(exc))
            rejected=st.session_state.get(key('rejected'),[])
            if rejected:
                st.warning('원문과 일치하지 않거나 형식이 잘못된 후보는 저장하지 않았습니다.')
                st.dataframe(pd.DataFrame(rejected),hide_index=True,width='stretch')
            with st.expander('수치를 직접 전사해 추가'):
                with st.form(key('manual_value_form')):
                    metric=st.text_input('전사할 지표 이름',value=metrics[0] if metrics else '',key=key('value_metric'))
                    number=st.number_input('보고된 숫자',value=0.0,format='%.8g',key=key('value_number'))
                    unit=st.text_input('보고된 단위',key=key('value_unit'))
                    device=st.text_input('소자 구조·재료',key=key('value_device'))
                    conditions=st.text_input('측정 조건 (JSON)',value='{}',placeholder='{"frequency":"1 kHz"}',key=key('value_conditions'))
                    location=st.text_input('표·그림·문단 위치',key=key('value_locator'))
                    value_page=st.selectbox('수치 근거 페이지',page_ids,key=key('value_page_'+sid))
                    quote=st.text_area('숫자·단위를 포함한 연속 원문 인용문',key=key('value_quote'))
                    add=st.form_submit_button('원문과 대조해 수치 저장')
                if add:
                    try:
                        save_observations(db,sid,[{'metric':metric,'value':float(number),'unit':unit,'device':device,'conditions':json.loads(conditions),
                            'page':value_page,'locator':location,'quote':quote,'method':'manual_transcription'}]);st.success('원문 일치 후보를 저장했습니다.')
                    except Exception as exc:st.error(str(exc))
    values=observations(db)
    with st.expander('③ 추출 수치 · 원문 근거 검토',expanded=bool(values)):
        if values:
            frame=pd.DataFrame([{**v,'title':by_id[v['paper_id']]['title'],'conditions':json.dumps(v['conditions'],ensure_ascii=False)} for v in values])
            columns=['title','metric','value','unit','device','conditions','page','locator','quote','reviewed']
            st.dataframe(frame[columns],hide_index=True,width='stretch')
            candidates={v['value_id']:v for v in values if not v['reviewed']}
            ids=st.multiselect('원문과 정의·조건을 확인한 수치',list(candidates),format_func=lambda i:f"{by_id[candidates[i]['paper_id']]['title'][:45]} · {candidates[i]['metric']}={candidates[i]['value']} {candidates[i]['unit']}",key=key('review_ids'))
            if st.button('선택 수치 검토 완료로 표시',key=key('review')):
                try:review_values(db,ids);st.success('검토 상태를 저장했습니다.')
                except Exception as exc:st.error(str(exc))
        else:st.info('원문 수치를 등록하면 값과 인용문을 함께 확인할 수 있습니다. 서지 정보만으로 성능값을 만들지 않습니다.')
    with st.expander('④ 벤치마킹 표 · 자동 인용 내보내기',expanded=True):
        selected=st.multiselect('벤치마킹에 사용할 논문',list(by_id),default=list(by_id),format_func=lambda i:by_id[i]['title'],key=key('benchmark_papers'))
        include=st.checkbox('미검토 후보도 상태를 표시해 표에 포함',value=False,key=key('unreviewed'))
        local_options=['문헌만','현재 플롯 데이터도 포함','DB 측정 데이터도 포함']
        mode=st.radio('내 측정값 병기',local_options,key=key('local_mode'),horizontal=True)
        local_curves=[]
        if mode==local_options[1] and current:local_curves=current['curves']
        elif mode==local_options[1]:st.info('먼저 측정 데이터를 정리·플롯하세요.')
        elif mode==local_options[2]:
            from db_compare import catalog,load_db_curves
            if Path(db).is_file():
                frame=catalog(db)
                chosen=st.multiselect('함께 표시할 DB 곡선',frame.curve_id.tolist(),format_func=lambda i:frame.loc[frame.curve_id==i,'filename'].iloc[0]+' · '+frame.loc[frame.curve_id==i,'label'].iloc[0],key=key('db_curves'))
                if chosen:local_curves=load_db_curves(db,chosen)
        if st.button('벤치마킹 표 생성 · 번호 인용 자동 연결',key=key('build'),type='primary'):
            try:
                local,missing=local_benchmark_rows(local_curves,metrics)
                report=build_benchmark(db,selected,metrics,include_unreviewed=include,local_rows=local)
                save_report(db,report);st.session_state[key('report')]=report
                if missing:st.warning(f'근거가 부족한 로컬 지표 {len(missing)}개는 표에서 제외했습니다.')
            except Exception as exc:st.error(str(exc))
        history=reports(db)
        if history:
            options={r['report_id']:r for r in history}
            choice=st.selectbox('저장한 벤치마킹 표',list(options),format_func=lambda i:options[i]['created_at'][:19]+' · '+', '.join(options[i]['metrics']),key=key('history'))
            if st.button('저장한 표 불러오기',key=key('load')):st.session_state[key('report')]=options[choice]
        report=st.session_state.get(key('report'))
        if report:
            request=st.text_input('문헌 해설 요청 (선택)',value='측정 조건과 지표 정의의 차이를 고려해 문헌 경향을 설명해줘.',key=key('explain_request'))
            if st.button('근거를 인용해 AI 해설 추가',key=key('explain')):
                try:
                    with st.spinner('등록된 근거 수치로 해설 작성 중…'):narrative=explain_benchmark(report,request,get_key(),model)
                    report=dict(report,report_id=fingerprint([report['report_id'],narrative])[:32],narrative=narrative)
                    report['markdown']=narrative+'\n\n'+benchmark_markdown(report)
                    save_report(db,report);st.session_state[key('report')]=report
                except Exception as exc:st.error(str(exc))
            st.markdown(report['markdown'])
            with st.expander('표의 원문 근거·DOI 상세'):st.dataframe(pd.DataFrame(report['rows']),hide_index=True,width='stretch')
            bundle_key=key('exports_'+report['report_id'])
            if bundle_key not in st.session_state:
                st.session_state[bundle_key]={'excel':excel_bytes(report),'bib':bibtex(report['bibliography']),'ris':ris(report['bibliography'])}
            bundle=st.session_state[bundle_key]
            st.download_button('벤치마킹 Excel · 참고문헌 시트',bundle['excel'],'literature_benchmark.xlsx',key=key('download_xlsx'))
            st.download_button('인용 포함 Markdown 보고서',report['markdown'],'literature_benchmark.md',key=key('download_md'))
            st.download_button('BibTeX 참고문헌',bundle['bib'],'references.bib',key=key('download_bib'))
            st.download_button('RIS · Zotero/EndNote 가져오기',bundle['ris'],'references.ris',key=key('download_ris'))
            if st.button('Word 보고서 준비',key=key('word')):
                try:st.session_state[key('word_bytes_'+report['report_id'])]=word_bytes(report)
                except Exception as exc:st.error(str(exc))
            word=st.session_state.get(key('word_bytes_'+report['report_id']))
            if word:st.download_button('인용 포함 Word 보고서',word,'literature_benchmark.docx',key=key('download_word'))
            st.caption('번호는 이 보고서의 논문 순서로 자동 연결됩니다. Word의 번호·서지는 일반 텍스트이며 Zotero 실시간 인용 필드가 아닙니다.')
