"""Regression for the supplied original B,D / B,E plotting convention.

Fixtures are synthetic, with the V+/V-/I1/P1 layout shown in the report.
They are not reconstructed numeric data from the user's OPJU project.
"""
import copy
import io
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from streamlit.testing.v1 import AppTest

from curve_integrity import source_point_audit
from lab_core import ai_plan, default_plan, group_key, load_tables, materialize, prepare_plan
from plot_rules import original_plotter_voltage
from v4_selection import constrain_plan, export_preflight


def original_export_data():
    rows = [f"Instrument metadata {i}" for i in range(41)]
    rows.append("t [s]\tV+ [V]\tV- [V]\tI1 [A]\tP1 [uC/cm2]\tI2 [A]\tP2 [uC/cm2]\tI3 [A]\tP3 [uC/cm2]")
    for i, (v, p) in enumerate([(-1.9, -4.8), (-.8, -3.6), (.1, -1.3), (1.2, 3.4), (2.1, 5.3), (.9, 4.2), (-.1, 1.4), (-1.9, -4.8)]):
        rows.append(f"{i/1000}\t{v}\t{-.73*v+.02}\t{p/1000}\t{p}\t{p/900}\t{p+.2}\t{p/800}\t{p+.4}")
    return "\n".join(rows).encode()


class OriginalDualVoltageExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.tables = load_tables([("device_1kHz_1.2V_3cycles.dat", original_export_data())], self.root / "raw")
        self.plan = default_plan(self.tables)

    def tearDown(self):
        self.temp.cleanup()

    def test_pv_only_uses_original_b_e_with_both_voltage_columns_present(self):
        plan = prepare_plan(constrain_plan(self.plan, self.tables, "PV만 한 그래프에"), self.tables)
        curves = materialize(plan, self.tables)
        self.assertEqual(len(curves), 1)
        self.assertEqual((curves[0].spec["x_column"], curves[0].spec["y_column"]), ("B", "E"))
        self.assertEqual(curves[0].data.source_row.tolist(), list(range(43, 51)))
        self.assertEqual(curves[0].data.x.tolist(), [-1.9, -.8, .1, 1.2, 2.1, .9, -.1, -1.9])
        self.assertEqual(curves[0].data.y.tolist(), [-4.8, -3.6, -1.3, 3.4, 5.3, 4.2, 1.4, -4.8])
        self.assertTrue(any("기존 플로터" in note for note in plan["notes"]))
        self.assertEqual(len(source_point_audit(curves)), 8)
        export_preflight(curves, plan)

    def test_iv_only_uses_original_b_d(self):
        plan = constrain_plan(self.plan, self.tables, "PV 말고 IV만")
        curves = materialize(plan, self.tables)
        self.assertEqual(len(curves), 1)
        self.assertEqual((curves[0].spec["x_column"], curves[0].spec["y_column"]), ("B", "D"))
        expected = [float(v) for v in self.tables[0].frame.iloc[42:50, 3]]
        self.assertEqual(curves[0].data.y.tolist(), expected)

    def test_all_pv_cycles_share_b_without_iv_or_extra_negative_voltage_copies(self):
        plan = prepare_plan(constrain_plan(self.plan, self.tables, "PV만 모든 사이클 한 그래프에"), self.tables)
        curves = materialize(plan, self.tables)
        self.assertEqual([(c.spec["x_column"], c.spec["y_column"]) for c in curves], [("B", "E"), ("B", "G"), ("B", "I")])
        self.assertEqual(len({group_key(c, plan) for c in curves}), 1)
        self.assertEqual(len(source_point_audit(curves)), 24)

    def test_model_negative_voltage_choice_is_corrected_from_original_format(self):
        wrong = copy.deepcopy(self.plan)
        for spec in wrong["curves"]:
            spec["x_column"] = "C"
        client = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status="completed", output_text=json.dumps(wrong)))))
        plan = ai_plan(self.tables, "PV만", "offline", "test", client=client)
        curves = materialize(plan, self.tables)
        self.assertEqual([(c.spec["x_column"], c.spec["y_column"]) for c in curves], [("B", "E")])

    def test_explicit_saved_mapping_overrides_original_default(self):
        plan = constrain_plan(self.plan, self.tables, "PV만", mappings=[{
            "source_id": self.tables[0].source_id, "start_row": 43, "end_row": 50,
            "x_column": "C", "y_column": "E"}])
        curves = materialize(plan, self.tables)
        self.assertEqual(curves[0].spec["x_column"], "C")
        self.assertEqual(curves[0].data.x.iloc[0], float(self.tables[0].frame.iat[42, 2]))

    def test_other_vplus_vminus_layouts_still_require_source_evidence(self):
        tables = load_tables([("other.csv", b"t [s],V+ [V],V- [V],P1 [uC/cm2],I1 [A]\n0,-1,1,-2,-.1\n1,0,0,1,.1\n2,1,-1,2,.2")], self.root / "other")
        self.assertIsNone(original_plotter_voltage(tables[0], 2, 3))
        with self.assertRaisesRegex(ValueError, "전압열 대응 불명확"):
            materialize(constrain_plan(default_plan(tables), tables, "PV만"), tables)

    def test_extra_voltage_channel_disables_original_two_voltage_profile(self):
        frame = self.tables[0].frame.copy()
        frame[9] = frame[1]
        frame.iat[41, 9] = "Voltage extra [V]"
        self.tables[0].frame = frame
        self.assertIsNone(original_plotter_voltage(self.tables[0], 43, 4))
        with self.assertRaisesRegex(ValueError, "전압열 대응 불명확"):
            materialize(constrain_plan(default_plan(self.tables), self.tables, "PV만"), self.tables)


class DualVoltageWebRegressionTests(unittest.TestCase):
    def test_reported_manual_save_path_handles_original_dual_voltage_export(self):
        upload = io.BytesIO(original_export_data())
        upload.name = "device_1kHz_1.2V_3cycles.dat"
        with tempfile.TemporaryDirectory() as directory, patch("streamlit.file_uploader", return_value=[upload]):
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(directory).run()
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            result = app.session_state["result"]
            self.assertEqual(len(result["curves"]), 1)
            self.assertEqual((result["curves"][0].spec["x_column"], result["curves"][0].spec["y_column"]), ("B", "E"))
            self.assertEqual(result["plan"]["measurement"], "PV")
            self.assertEqual(len(app.get("plotly_chart")), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
