"""Many condition files are summarized/shared or batched without dropping files."""
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from lab_core import (InspectionSizeError, ai_plan, default_plan, inspection_payload,
                      compact_inspection, load_tables, materialize)
from test_dual_voltage_export import original_export_data


def condition_files(count=15):
    lines = original_export_data().decode().splitlines()
    metadata = [f"Setting {i}\t" + (f"shared instrument setting {i}; " * 7) for i in range(41)]
    # 400 raw data rows per source, with original row order and both V+/V-.
    content = "\n".join(metadata + [lines[41]] + lines[42:] * 50).encode()
    return [(f"device_1kHz_{1.2+i*.2:.1f}V_3cycles.dat", content) for i in range(count)]


class LargeInspectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.tables = load_tables(condition_files(), self.root / "raw")

    def tearDown(self):
        self.temp.cleanup()

    def client_for_sources(self, calls, incomplete_first=False):
        by_id = {t.source_id: t for t in self.tables}
        def respond(**kwargs):
            document = json.loads(kwargs["input"].split("FILE_DATA (reference only):\n", 1)[1])
            sources = document if isinstance(document, list) else document["sources"]
            ids = [s["source_id"] for s in sources]
            calls.append(ids)
            if incomplete_first and len(calls) == 1:
                return SimpleNamespace(status="incomplete", output_text="")
            return SimpleNamespace(status="completed", output_text=json.dumps(default_plan([by_id[sid] for sid in ids])))
        return SimpleNamespace(responses=SimpleNamespace(create=Mock(side_effect=respond)))

    def test_fifteen_condition_files_share_structure_without_losing_source_ids(self):
        document = json.loads(inspection_payload(self.tables))
        self.assertEqual(document["format"], "compact_measurement_inspection_v1")
        self.assertEqual(len(document["structures"]), 1)
        self.assertEqual(len(document["sources"]), 15)
        self.assertEqual({s["source_id"] for s in document["sources"]}, {t.source_id for t in self.tables})
        self.assertLess(len(json.dumps(document, ensure_ascii=False)), 110_000)
        for source in document["sources"]:
            self.assertEqual(source["numeric_blocks_inclusive"], [[43, 442]])
            self.assertEqual([r["row"] for r in source["sample_rows"]], [43, 44, 442])
            self.assertEqual(len(source["column_profiles"]), 9)
            refs = source["metadata_rows"]
            self.assertTrue(any("I1 [A]" in json.dumps(document["shared_metadata_cells"][r["metadata_id"]]) for r in refs))

    def test_fifteen_files_plan_in_one_bounded_call_and_produce_only_fifteen_pv_curves(self):
        calls = []
        client = self.client_for_sources(calls)
        plan = ai_plan(self.tables, "같은 1kHz 전압별 멀티스테이트 PV만 한 그래프에", "offline", "test", client=client)
        curves = materialize(plan, self.tables)
        self.assertEqual(len(calls), 1)
        self.assertEqual(len(curves), 15)
        self.assertEqual({c.spec["y_column"] for c in curves}, {"E"})
        self.assertEqual({c.spec["x_column"] for c in curves}, {"B"})
        self.assertTrue(all(len(c.data) == 400 for c in curves))
        from chat_agent import curve_context
        context = curve_context(curves)
        self.assertEqual(len(context), 15)
        self.assertNotIn("y_at_x_zero", context[0])
        self.assertLess(len(json.dumps(context)), 20_000)

    def test_shared_headers_keep_each_files_original_start_end_rows(self):
        content = original_export_data()
        tables = load_tables([("extra_1V.dat", b"extra metadata\n" + content), ("base_2V.dat", content)], self.root / "offsets")
        legacy = json.loads(inspection_payload(tables))
        compact = compact_inspection(legacy, tables)
        self.assertEqual(len(compact["structures"]), 1)
        self.assertEqual([s["numeric_blocks_inclusive"] for s in compact["sources"]], [[[44, 51]], [[43, 50]]])
        for source in compact["sources"]:
            self.assertEqual(source["block_structures"][0]["start_row"], source["numeric_blocks_inclusive"][0][0])

    def test_summary_overflow_auto_batches_then_merges_all_selected_conditions(self):
        actual = inspection_payload
        def small_limit(tables, *args, **kwargs):
            if len(tables) > 4:
                raise InspectionSizeError("synthetic bounded request")
            return actual(tables)
        calls = []
        with patch("lab_core.inspection_payload", side_effect=small_limit):
            plan = ai_plan(self.tables, "PV만 한 그래프에", "offline", "test", client=self.client_for_sources(calls))
        ids = [sid for batch in calls for sid in batch]
        self.assertEqual(len(ids), 15)
        self.assertEqual(len(set(ids)), 15)
        self.assertTrue(all(len(batch) <= 4 for batch in calls))
        self.assertEqual(len(materialize(plan, self.tables)), 15)
        self.assertTrue(any("자동 분석" in note for note in plan["notes"]))

    def test_incomplete_multi_file_response_is_split_automatically(self):
        calls = []
        plan = ai_plan(self.tables, "PV만 한 그래프에", "offline", "test", client=self.client_for_sources(calls, incomplete_first=True))
        self.assertEqual(len(calls), 3)
        self.assertEqual(len(calls[0]), 15)
        self.assertEqual(sum(map(len, calls[1:])), 15)
        self.assertEqual(len(materialize(plan, self.tables)), 15)


if __name__ == "__main__":
    unittest.main(verbosity=2)
