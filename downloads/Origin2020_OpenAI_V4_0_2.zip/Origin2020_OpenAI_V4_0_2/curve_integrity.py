"""Validate selected source links; never edit or delete measurement values."""
from collections import defaultdict

import numpy as np

from plot_rules import grouping_axes, axis_channel, source_header
from openpyxl.utils import column_index_from_string


def validate_channel_links(plan, sources=None):
    """One measured Y must not be silently plotted against competing X channels."""
    if plan.get("measurement") == "manual":
        return
    by_source_y = defaultdict(list)
    for spec in plan["curves"]:
        key = (spec["source_id"], spec["y_column"])
        for previous in by_source_y[key]:
            overlapping = max(previous["start_row"], spec["start_row"]) < min(previous["end_row"], spec["end_row"])
            if overlapping and previous["x_column"] != spec["x_column"]:
                source = (sources or {}).get(spec["source_id"])
                description = f"{source.filename} / {source.sheet}" if source else spec["source_id"]
                raise ValueError(
                    f"X열 중복 연결을 차단했습니다: {description}, Y={spec['y_column']}가 "
                    f"X={previous['x_column']}와 X={spec['x_column']}에 동시에 연결돼 있습니다. "
                    "수동 계획에서 원래 사용하던 X–Y 한 쌍을 선택하세요. "
                    "두 X축 비교가 의도된 경우에만 '열 지정 그대로'를 사용하세요."
                )
        by_source_y[key].append(spec)


def _same(a, b):
    scale = max(float(np.max(np.abs(a))), float(np.max(np.abs(b))))
    return np.allclose(a, b, rtol=1e-12, atol=scale * 1e-14)


def validate_reflected_channels(curves, plan):
    """Flag algebraic reflections from overlapping rows of ONE source, not whole sweeps."""
    if plan.get("measurement") == "manual" or plan.get("channel_selection") in ("explicit", "all"):
        return
    sources = defaultdict(list)
    fields = ("device_id", "voltage_v", "frequency_hz", "temperature_c", "cycle", "split_condition", "device_stack", "treatment")
    for curve in curves:
        key = (curve.source.source_id, tuple(grouping_axes(curve.spec)))
        for previous in sources[key]:
            def paired_channel(item):
                x = column_index_from_string(item.spec["x_column"]) - 1
                y = column_index_from_string(item.spec["y_column"]) - 1
                xc = axis_channel(source_header(item.source, item.spec["start_row"], x))
                yc = axis_channel(source_header(item.source, item.spec["start_row"], y))
                return xc if xc is not None and xc == yc else None
            a_channel, b_channel = paired_channel(previous), paired_channel(curve)
            if a_channel and b_channel and a_channel != b_channel:
                continue  # Distinct correctly matched raw channels are legitimate measurements.
            # Explicitly different experimental conditions can legitimately be reflections.
            if any(previous.spec["metadata"].get(k) is not None and curve.spec["metadata"].get(k) is not None
                   and previous.spec["metadata"][k] != curve.spec["metadata"][k] for k in fields):
                continue
            common = previous.data.merge(curve.data, on="source_row", suffixes=("_a", "_b"))
            if len(common) < 3:
                continue
            xa, ya, xb, yb = (common[k].to_numpy(dtype=float) for k in ("x_a", "y_a", "x_b", "y_b"))
            if np.ptp(xa) == 0 or np.ptp(ya) == 0:
                continue
            x_same, y_same = _same(xa, xb), _same(ya, yb)
            mirrored = (x_same and _same(ya, -yb)) or (y_same and _same(xa, -xb)) or (_same(xa, -xb) and _same(ya, -yb))
            if mirrored:
                a, b = previous.spec, curve.spec
                raise ValueError(
                    f"같은 원본 행에서 반전 채널이 함께 선택됐습니다: {curve.source.filename} / {curve.source.sheet}, "
                    f"X={a['x_column']}, Y={a['y_column']}와 X={b['x_column']}, Y={b['y_column']}. "
                    "곡선을 임의로 삭제하거나 부호를 보정하지 않았습니다. 원래 사용하던 열을 선택해 주세요. "
                    "반대 극성 채널을 함께 비교하려는 요청이면 '열 지정 그대로'를 선택하세요."
                )
        sources[key].append(curve)


def source_point_audit(curves):
    """Export every plotted point beside the literal source cells and source coordinates."""
    from openpyxl.utils import column_index_from_string
    import pandas as pd
    rows = []
    for curve in curves:
        spec = curve.spec
        xc, yc = (column_index_from_string(spec[key]) - 1 for key in ("x_column", "y_column"))
        for row in curve.data.itertuples(index=False):
            source_row = int(row.source_row)
            raw_x = curve.source.frame.iat[source_row - 1, xc]
            raw_y = curve.source.frame.iat[source_row - 1, yc]
            if float(raw_x) != float(row.x) or float(raw_y) != float(row.y):
                raise ValueError("원본과 플롯 데이터 값이 일치하지 않습니다. 출력을 중단했습니다.")
            rows.append({"curve_id": curve.curve_id, "filename": curve.source.filename,
                         "sheet": curve.source.sheet, "source_row": source_row,
                         "x_column": spec["x_column"], "y_column": spec["y_column"],
                         "source_x": str(raw_x), "source_y": str(raw_y), "plotted_x": float(row.x), "plotted_y": float(row.y)})
    return pd.DataFrame(rows)
