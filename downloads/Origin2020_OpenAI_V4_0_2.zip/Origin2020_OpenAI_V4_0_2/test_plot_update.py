import ast
import tempfile
import unittest
from pathlib import Path

from apply_plot_update import update_existing


class PlotUpdateTests(unittest.TestCase):
    def test_update_preserves_key_config_environment_and_database(self):
        source = Path(__file__).resolve().parent
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            app = root / "agent_origin2020_openai.py"
            old = source.joinpath(app.name).read_text().replace('OPENAI_API_KEY = "여기에_새_OpenAI_API_키_입력"', 'OPENAI_API_KEY = "SYNTHETIC_TEST_ONLY"').replace('DEFAULT_MODEL = "gpt-4.1-mini"', 'DEFAULT_MODEL = "my-model"')
            old = old.replace('ORIGIN_PROG_ID = "Origin.Application"', 'ORIGIN_PROG_ID = "Origin.ApplicationSI"')
            app.write_text(old, encoding="utf-8")
            (root / "lab_core.py").write_text("# previous version\n")
            (root / ".venv").mkdir()
            (root / ".venv" / "marker").write_bytes(b"keep-environment")
            (root / "lab_workspace").mkdir()
            database = root / "lab_workspace" / "experiments.sqlite3"
            database.write_bytes(b"keep-measurements")
            before = app.read_bytes()
            backup = update_existing(app, source)
            values = {n.targets[0].id: n.value for n in ast.parse(app.read_text()).body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)}
            self.assertEqual(ast.literal_eval(values["OPENAI_API_KEY"]), "SYNTHETIC_TEST_ONLY")
            self.assertEqual(ast.literal_eval(values["DEFAULT_MODEL"]), "my-model")
            self.assertEqual(ast.literal_eval(values["ORIGIN_PROG_ID"]), "Origin.Application")
            self.assertEqual((backup / app.name).read_bytes(), before)
            self.assertEqual(database.read_bytes(), b"keep-measurements")
            self.assertEqual((root / ".venv" / "marker").read_bytes(), b"keep-environment")
            self.assertTrue((root / "plot_rules.py").is_file())
            self.assertTrue((root / "v4_selection.py").is_file())
            self.assertTrue((root / "analysis_core.py").is_file())

    def test_wrong_app_is_rejected_before_creating_backups_or_modifying_files(self):
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory) / "old_gemini.py"
            app.write_text('GEMINI_API_KEY = "test-only"\n')
            before = app.read_bytes()
            with self.assertRaises(ValueError):
                update_existing(app, Path(__file__).resolve().parent)
            self.assertEqual(app.read_bytes(), before)
            self.assertEqual(len(list(Path(directory).iterdir())), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
