"""V4 request boundaries. The model proposes; these rules limit execution."""
from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path

from openpyxl.utils import column_index_from_string, get_column_letter

from plot_rules import axis_info, request_options, select_requested_channels, source_header

APP_VERSION = "4.0.1"


def source_kind(spec, tables):
    source = next(t for t in tables if t.source_id == spec["source_id"])
    kinds = [axis_info(source_header(source, spec["start_row"], column_index_from_string(spec[f"{a}_column"]) - 1))[0]
             for a in ("x", "y")]
    # The literal source labels take priority over model-written labels/metadata.
    for response in ("polarization", "current", "current_density"):
        if response in kinds and "voltage" in kinds:
            return "PV" if response == "polarization" else "IV"
    return "other"


def constrain_plan(plan, tables, request="", measurement=None, channel_mode="first", mappings=None):
    result = copy.deepcopy(plan)
    options = request_options(request)
    result.update(options)
    if "measurement" not in options:
        result["measurement"] = measurement or result.get("measurement", "PV")
    if mappings is not None:
        result["column_mappings"] = mappings
    result["curves"] = [s for s in result["curves"] if not any(m["source_id"] == s["source_id"]
        and m["start_row"] <= s["start_row"] and m["end_row"] >= s["end_row"]
        and m["y_column"] == s["y_column"] and not m["x_column"] for m in result.get("column_mappings", []))]
    target = result.get("measurement")
    if target in ("PV", "IV"):
        before = len(result["curves"])
        result["curves"] = [s for s in result["curves"] if source_kind(s, tables) == target]
        if before != len(result["curves"]):
            result["notes"].append(f"V4 요청 제한: {target} 이외의 측정열은 실행 대상에서 제외했습니다.")
    result = select_requested_channels(result, tables, request)
    explicit_channels = bool(re.search(r"(?<![A-Za-z0-9])[PIJ][ _-]*\d+(?![A-Za-z0-9])|cycle\s*\d|\d+\s*(?:번째|회차|사이클)", request, re.I))
    all_channels = bool(re.search(r"(?:모든|전체|전부)\s*(?:측정\s*)?(?:채널|사이클|cycle|반복)|all\s*(?:channels|cycles)", request, re.I))
    result["channel_selection"] = "explicit" if explicit_channels else "all" if all_channels or channel_mode == "all" else "primary"
    # Multistate voltages/files remain intact. Only unrequested repeated response
    # channels within the SAME table and row interval are limited to one.
    last_channel = bool(re.search(r"마지막\s*(?:측정\s*)?(?:채널|사이클|cycle)|last\s*(?:channel|cycle)", request, re.I))
    if (channel_mode == "first" or last_channel) and not explicit_channels and not all_channels and target != "manual":
        groups = {}
        for spec in result["curves"]:
            key = (spec["source_id"], spec["start_row"], spec["end_row"], source_kind(spec, tables))
            table = next(t for t in tables if t.source_id == spec["source_id"])
            y_header = source_header(table, spec["start_row"], column_index_from_string(spec["y_column"]) - 1)
            response_axis = "x" if axis_info(y_header)[0] == "voltage" else "y"
            rank = column_index_from_string(spec[f"{response_axis}_column"])
            if key not in groups or (rank > groups[key][0] if last_channel else rank < groups[key][0]):
                groups[key] = (rank, spec)
        chosen = {id(spec) for _, spec in groups.values()}
        before = len(result["curves"])
        result["curves"] = [s for s in result["curves"] if id(s) in chosen]
        if before != len(result["curves"]):
            result["notes"].append(("요청한 마지막 측정 채널만 선택했습니다." if last_channel else
                "사이클/채널을 지정하지 않아 원본 순서의 첫 측정 채널만 선택했습니다.") + " 모든 전압·파일 조건은 유지했습니다.")
    return result


def layouts(tables):
    from lab_core import numeric_blocks
    rows = []
    for table in tables:
        for start, end in numeric_blocks(table.frame):
            headers = [source_header(table, start, i) for i in range(table.frame.shape[1])]
            signature = hashlib.sha256(json.dumps(headers, ensure_ascii=False).encode()).hexdigest()
            rows.append({"table": table, "start": start, "end": end, "headers": headers, "signature": signature})
    return rows


def load_profiles(path):
    if not Path(path).exists():
        return {}
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("열 대응 프로필 형식을 확인하세요.")
    return value


def save_profiles(path, profiles):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(profiles, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def profile_mappings(tables, profiles):
    result = []
    for layout in layouts(tables):
        saved = profiles.get(layout["signature"], {})
        for y, x in saved.items():
            result.append({"source_id": layout["table"].source_id, "start_row": layout["start"], "end_row": layout["end"],
                           "y_column": y, "x_column": x})
    return result


def validate_mappings(plan, tables):
    mappings = plan.get("column_mappings", [])
    if not isinstance(mappings, list):
        raise ValueError("column_mappings는 목록이어야 합니다.")
    sources = {t.source_id: t for t in tables}
    for mapping in mappings:
        if not isinstance(mapping, dict) or set(mapping) != {"source_id", "start_row", "end_row", "y_column", "x_column"}:
            raise ValueError("저장된 열 대응 필드를 확인하세요.")
        table = sources.get(mapping["source_id"])
        if table is None or type(mapping["start_row"]) is not int or type(mapping["end_row"]) is not int or not 1 <= mapping["start_row"] <= mapping["end_row"] <= len(table.frame):
            raise ValueError("열 대응의 원본/행 범위를 확인하세요.")
        for field in ("x_column", "y_column"):
            col = mapping[field]
            if field == "x_column" and col == "":
                continue  # explicit exclusion in a saved source-format profile
            if not isinstance(col, str) or not re.fullmatch(r"[A-Z]{1,3}", col) or column_index_from_string(col) > table.frame.shape[1]:
                raise ValueError("열 대응의 원본 열 범위를 확인하세요.")


def export_preflight(curves, plan):
    """Reject stale/mixed curves before contacting COM, even for direct callers."""
    from lab_core import prepare_plan
    from curve_integrity import source_point_audit
    tables = list({c.source.source_id: c.source for c in curves}.values())
    expected = prepare_plan(plan, tables)
    def key(spec):
        return tuple(spec[k] for k in ("source_id", "start_row", "end_row", "x_column", "y_column"))
    if len(curves) != len(expected["curves"]) or {key(c.spec) for c in curves} != {key(s) for s in expected["curves"]}:
        raise ValueError("V4 실행 차단: 요청 계획과 출력 곡선이 다릅니다. 현재 요청으로 데이터를 다시 선택하세요.")
    if plan.get("measurement") in ("PV", "IV") and any(source_kind(c.spec, tables) != plan["measurement"] for c in curves):
        raise ValueError("V4 실행 차단: 요청하지 않은 PV/IV 측정열이 포함됐습니다.")
    source_point_audit(curves)
