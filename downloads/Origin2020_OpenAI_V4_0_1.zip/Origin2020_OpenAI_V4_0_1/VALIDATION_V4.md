# V4 validation — 2026-11-09

Version 4.0.1. Synthetic anonymous fixtures; no paid API calls or user measurements published.

- Mixed Time, V+ [V], Current, Polarization, opposite-sign repeated channels: one requested PV or IV per source by default; original values and acquisition order retained.
- Original user PV/IV restrictions override mixed model plans and rewritten tasks. A style action switching to IV reselects Current from raw data.
- Multiple voltage states and Excel sheets remain selectable and compatible axes overlay.
- P2, last-cycle and all-cycle requests honored. Unrequested repeated channels are not expanded.
- Numbered/polarity voltage matching; ambiguous links rejected instead of guessing. Exact-header profiles support special formats.
- The supplied original B,D IV / B,E PV convention is recognized only when B=V+, C=V-, D=I1, E=P1 match. Other layouts are not guessed. Regression includes 41 metadata rows and competing V- values.
- Fifteen condition files with 400 rows each share one bounded structure summary and produce all 15 requested PV curves. Forced summary overflow and incomplete multi-file model outputs automatically split and merge without dropping sources. Different source header offsets remain correct.
- An unrelated ambiguous IV channel cannot block a PV-only run.
- Original-cell audit verifies every point. Export preflight rejects stale mixed curves before COM.
- Mock COM checks XY payload, graph count, legends and template routing.
- Updater backs up code, preserves API key/configuration/.venv/DB, installs every V4 module, changes default Origin connection to a separate instance.

Full offline suite: 100 tests passed (`python3 -m unittest discover -v`, Python 3.12).
This includes original-format mapping, 15-file compact planning, forced automatic batches,
incomplete-output recovery, differing header offsets, Streamlit AppTest, SDK transport,
COM payload and update-preservation tests.
Real Chromium browser: synthetic dual-voltage export with 41 metadata rows saved PV alone,
then reselected IV alone; both produced exactly one graph. Browser exercised the local
manual path without API calls; AI response handling is verified separately with mocks.

Limits: real Origin 2020 execution requires Windows and was not available here. OpenAI responses were mocked, including deliberately wrong responses. The supplied OPJU metadata did not expose original raw DAT numeric arrays, so the exact user screenshot was not reproduced or claimed fixed by a real-data test.
