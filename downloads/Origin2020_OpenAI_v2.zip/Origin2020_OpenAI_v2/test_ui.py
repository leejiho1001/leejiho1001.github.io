"""Streamlit workflow test with a synthetic upload and no remote API requests."""
import io
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
from types import SimpleNamespace

from streamlit.testing.v1 import AppTest

from test_lab import example_excel


class WebWorkflowTests(unittest.TestCase):
    def test_model_catalog_selection_and_manual_entry(self):
        api = MagicMock()
        api.__enter__.return_value = api
        api.models.list.return_value = [SimpleNamespace(id=name) for name in
            ("gpt-test-model", "gpt-4.1-mini", "gpt-test-audio", "text-embedding-test")]
        with patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("openai.OpenAI", return_value=api):
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            selector = next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델")
            self.assertEqual(selector.value, "gpt-4.1-mini")
            next(b for b in app.button if b.label == "API 모델 목록 불러오기").click().run(timeout=30)
            selector = next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델")
            self.assertIn("gpt-test-model", selector.options)
            self.assertNotIn("gpt-test-audio", selector.options)
            selector.select("gpt-test-model").run()
            self.assertEqual(next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").value, "gpt-test-model")
            next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").select("직접 입력…").run()
            next(t for t in app.sidebar.text_input if t.label == "모델 ID 직접 입력").set_value("gpt-my-custom-model").run()
            self.assertFalse(app.exception)
            self.assertEqual(api.models.list.call_count, 1)

    def test_saved_custom_model_and_catalog_failure_preserve_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            original = Path(__file__).with_name("agent_origin2020_openai.py")
            app_path = root / original.name
            app_path.write_text(original.read_text().replace("USE_SAVED_SETTINGS = False", "USE_SAVED_SETTINGS = True"), encoding="utf-8")
            (root / "local_settings.json").write_text(json.dumps({"model": "gpt-saved-custom-model"}), encoding="utf-8")
            with patch.dict(os.environ, {"OPENAI_API_KEY": "offline-test-only"}), patch("openai.OpenAI", side_effect=RuntimeError("simulated offline")):
                app = AppTest.from_file(str(app_path)).run(timeout=30)
                self.assertEqual(next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").value, "gpt-saved-custom-model")
                next(b for b in app.button if b.label == "API 모델 목록 불러오기").click().run(timeout=30)
                self.assertFalse(app.exception)
                self.assertEqual(next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").value, "gpt-saved-custom-model")
                self.assertTrue(any("목록 조회 실패" in w.value for w in app.warning))

    def test_code_defaults_override_saved_model_in_code_mode(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = Path(__file__).with_name("agent_origin2020_openai.py")
            app_path = root / source.name
            app_path.write_bytes(source.read_bytes())
            (root / "local_settings.json").write_text(json.dumps({"model": "gpt-previous-saved"}), encoding="utf-8")
            app = AppTest.from_file(str(app_path)).run(timeout=30)
            self.assertFalse(app.exception)
            self.assertEqual(next(s for s in app.sidebar.selectbox if s.label == "OpenAI 모델").value, "gpt-4.1-mini")
            self.assertTrue(next(b for b in app.button if b.label == "경로·모델·선 두께 기본값 저장").disabled)

    def test_upload_extract_export_db_and_idempotent_resave(self):
        upload = io.BytesIO(example_excel())
        upload.name = "sample_3V_10kHz.xlsx"
        with tempfile.TemporaryDirectory() as directory, patch("streamlit.file_uploader", return_value=[upload]):
            app = AppTest.from_file(str(Path(__file__).with_name("agent_origin2020_openai.py"))).run(timeout=30)
            app.sidebar.text_input[0].set_value(directory).run()
            next(b for b in app.button if b.label.startswith("1.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            next(b for b in app.button if b.label.startswith("4.")).click().run(timeout=30)
            self.assertFalse(app.exception)
            self.assertFalse(app.error)
            db = Path(directory, "experiments.sqlite3")
            self.assertTrue(db.is_file())
            self.assertEqual(len(list(Path(directory).glob("runs/*/cleaned.xlsx"))), 1)
            next(b for b in app.button if b.label == "이 결과를 DB에 저장 / 재확인").click().run(timeout=30)
            self.assertFalse(app.exception)
            with sqlite3.connect(db) as con:
                self.assertEqual(con.execute("SELECT COUNT(*) FROM curves").fetchone()[0], 4)
                self.assertEqual(con.execute("SELECT COUNT(*) FROM runs").fetchone()[0], 1)
                self.assertEqual(con.execute("SELECT COUNT(*) FROM points").fetchone()[0], 18)


if __name__ == "__main__":
    unittest.main(verbosity=2)
