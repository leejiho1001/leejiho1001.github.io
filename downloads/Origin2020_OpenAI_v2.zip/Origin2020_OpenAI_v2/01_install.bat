@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 exit /b 1
py -3.12 -c "import sys; print(sys.version)" >nul 2>&1
if errorlevel 1 (
    echo Python 3.12 was not found. Install Python 3.12 64-bit with the Python launcher.
    pause
    exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
    py -3.12 -m venv .venv
    if errorlevel 1 (
        echo Failed to create the Python environment.
        pause
        exit /b 1
    )
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo Installation failed. Keep this window open and copy the error above.
    pause
    exit /b 1
)
echo.
echo Installation completed.
echo Enter your new OpenAI key in agent_origin2020_openai.py, then run 02_start.bat.
pause
