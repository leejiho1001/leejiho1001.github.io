"""Run with: streamlit run agent_origin2020_openai.py"""
from __future__ import annotations

import json
import os
import sqlite3
import uuid
from collections import defaultdict
from contextlib import closing
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from lab_core import (
    META_FIELDS, NUMBER_FIELDS, GROUP_FIELDS, ai_interpret, ai_plan, curve_color,
    default_plan, digest, export_excel, group_key, load_tables, materialize,
    numeric_blocks, points_frame, query_curves, save_run, stable_json, summary_frame,
)
from origin_adapter import plot_origin


if __name__ == "__main__" and not st.runtime.exists():
    import sys
    from streamlit.web import cli as stcli
    sys.argv = ["streamlit", "run", __file__]
    raise SystemExit(stcli.main())


# ================= 사용자 설정 =================
# 새 OpenAI API 키를 이 따옴표 안에 넣으세요. 이전 Gemini 키는 사용하지 않습니다.
OPENAI_API_KEY = "여기에_새_OpenAI_API_키_입력"
DEFAULT_MODEL = "gpt-4.1-mini"  # Responses API + Structured Outputs 지원 모델
DEFAULT_WORKSPACE = Path(__file__).resolve().parent / "lab_workspace"
DEFAULT_TEMPLATE = ""  # 예: r"C:\Users\이지호\Desktop\Graph Template\P-V Curve.otpu"
USE_SAVED_SETTINGS = False  # False: 상단 코드값 우선 / True: 저장된 UI 기본값 사용
ORIGIN_PROG_ID = "Origin.ApplicationSI"  # 원본 코드의 연결 방식. 별도 인스턴스: Origin.Application
# ================================================
SETTINGS_FILE = Path(__file__).resolve().parent / "local_settings.json"


def load_settings() -> dict:
    try:
        value = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def get_key() -> str:
    key = os.environ.get("OPENAI_API_KEY", "").strip() or OPENAI_API_KEY.strip()
    if not key or key.startswith("여기에_"):
        raise ValueError("코드 상단 OPENAI_API_KEY에 새 키를 입력하거나 환경변수를 설정하세요.")
    return key


def clear_results():
    for key in ("result", "interpretation", "origin_result"):
        st.session_state.pop(key, None)


def set_plan(plan: dict):
    st.session_state.plan = plan
    st.session_state.plan_revision = st.session_state.get("plan_revision", 0) + 1
    clear_results()


def plan_editor(plan: dict) -> dict:
    revision = st.session_state.plan_revision
    with st.expander("고급: 전체 계획 JSON 확인", expanded=False):
        st.code(json.dumps(plan, ensure_ascii=False, indent=2), language="json")
    rows = []
    for spec in plan["curves"]:
        rows.append({k: v for k, v in spec.items() if k != "metadata"} | spec["metadata"])
    if not rows:
        st.warning("인식된 곡선이 없습니다. 요청을 구체화하거나 아래 JSON 계획을 직접 입력하세요.")
    else:
        st.caption("행 번호는 원본 기준 1부터 시작하며 끝 행을 포함합니다. 공통 X를 사용하는 여러 Y는 행을 추가해 지정할 수 있습니다. 중복·불필요 곡선은 행을 삭제하세요.")
        edited = st.data_editor(
            pd.DataFrame(rows), key=f"curve_editor_{revision}", hide_index=True,
            num_rows="dynamic", width="stretch",
            column_config={
                "source_id": st.column_config.TextColumn("원본 ID"),
                "start_row": st.column_config.NumberColumn("시작 행 (1-based)", min_value=1, step=1),
                "end_row": st.column_config.NumberColumn("끝 행 (포함)", min_value=1, step=1),
                "voltage_v": st.column_config.NumberColumn("인가전압 조건 (V)"),
                "frequency_hz": st.column_config.NumberColumn("주파수 (Hz)"),
                "temperature_c": st.column_config.NumberColumn("온도 (°C)"),
            },
        )
        new_specs = []
        for row in edited.to_dict(orient="records"):
            cleaned = {key: None if pd.isna(value) else value for key, value in row.items()}
            metadata = {key: cleaned.pop(key) for key in META_FIELDS}
            for key in ("start_row", "end_row"):
                value = cleaned[key]
                if value is not None and float(value).is_integer():
                    cleaned[key] = int(value)
            for key in ("x_unit", "y_unit"):
                if cleaned[key] is None:
                    cleaned[key] = ""
            for key in META_FIELDS:
                if key not in NUMBER_FIELDS and metadata[key] is not None:
                    metadata[key] = str(metadata[key])
            cleaned["metadata"] = metadata
            new_specs.append(cleaned)
        plan = dict(plan, curves=new_specs)
    group = st.multiselect("같은 그래프에 묶을 측정 조건", GROUP_FIELDS, default=plan["group_by"], key=f"groups_{revision}")
    color = st.selectbox("색상을 구분할 조건", GROUP_FIELDS, index=GROUP_FIELDS.index(plan["color_by"]), key=f"color_{revision}")
    use_target = st.checkbox("특정 X 값에서 Y 비교 (모든 스윕 교차점 유지)", value=plan["compare_at_x"] is not None, key=f"target_on_{revision}")
    target = st.number_input("비교할 X 값 — 원본 X 단위", value=float(plan["compare_at_x"] or 0), key=f"target_{revision}") if use_target else None
    st.caption("그룹 조건이 미확인(null)이면 같은 조건이라고 가정하지 않고 분리합니다. X/Y 이름·단위가 다르면 별도 그래프로 나눕니다. 같은 물리량은 이름과 단위를 맞춰 주세요.")
    return dict(plan, group_by=group, color_by=color, compare_at_x=target)


def preview(curves, plan):
    grouped = defaultdict(list)
    for curve in curves:
        grouped[group_key(curve, plan)].append(curve)
    st.caption(f"총 {len(grouped)}개 그래프 그룹. 화면에는 처음 20개를 표시하며, 내보내기에는 전체를 포함합니다.")
    for key, members in list(grouped.items())[:20]:
        info = json.loads(key)
        title = ", ".join(f"{k}={v}" for k, v in info["conditions"].items()) or "전체 조건 비교"
        spec = members[0].spec
        figure = go.Figure()
        for curve in members:
            indexed = curve.data.set_index("source_row")[["x", "y"]]
            full = indexed.reindex(range(int(indexed.index.min()), int(indexed.index.max()) + 1))
            # No sorting or downsampling; gaps remain visible.
            figure.add_trace(go.Scattergl(
                x=full.x, y=full.y, mode="lines", name=curve.spec["label"],
                line={"color": curve_color(curve, plan), "width": 2}, connectgaps=False,
            ))
        figure.update_layout(title=title,
            xaxis_title=f"{spec['x_name']} [{spec['x_unit'] or '단위 미확인'}]",
            yaxis_title=f"{spec['y_name']} [{spec['y_unit'] or '단위 미확인'}]")
        st.plotly_chart(figure, width="stretch")


def csv_bytes(frame):
    safe = frame.map(lambda v: "'" + v if isinstance(v, str) and v.startswith(("=", "+", "-", "@")) else v)
    return safe.to_csv(index=False).encode("utf-8-sig")


st.set_page_config(page_title="Origin 2020 · OpenAI Lab Agent", layout="wide")
st.title("Origin 2020 · OpenAI 측정 데이터 에이전트")
st.caption("파일 업로드 → 자연어 정리 요청 → 행·열·조건 검토 → 데이터/DB 저장 → Origin 플롯")

settings = load_settings() if USE_SAVED_SETTINGS else {}
# Reset the model widget when code-level defaults change during a Streamlit rerun.
defaults_id = (DEFAULT_MODEL, str(DEFAULT_WORKSPACE), DEFAULT_TEMPLATE, USE_SAVED_SETTINGS)
if st.session_state.get("code_defaults_id") != defaults_id:
    st.session_state.pop("openai_model_choice", None)
    st.session_state.pop("openai_manual_model", None)
    st.session_state["code_defaults_id"] = defaults_id
with st.sidebar:
    st.header("설정")
    workspace = Path(st.text_input("데이터 보관 폴더", settings.get("workspace", str(DEFAULT_WORKSPACE)))).expanduser()
    # MODEL_SELECTOR_START
    saved_model = str(settings.get("model", DEFAULT_MODEL)).strip() or DEFAULT_MODEL
    if st.button("API 모델 목록 불러오기"):
        try:
            from openai import OpenAI
            with OpenAI(api_key=get_key(), timeout=20, max_retries=1) as api:
                catalog = [item.id for item in api.models.list()]
            # Exclude obvious image/audio/embedding models. Listing a model does
            # not prove Responses API or Structured Outputs compatibility.
            excluded = ("audio", "realtime", "transcrib", "tts", "image", "search", "instruct")
            candidates = sorted({name for name in catalog
                if name.startswith(("gpt-", "o1", "o3", "o4"))
                and not any(word in name.lower() for word in excluded)})
            if not candidates:
                raise ValueError("계정에서 텍스트 분석 모델을 찾지 못했습니다.")
            st.session_state["api_model_ids"] = candidates
            st.success(f"API 모델 {len(candidates)}개를 불러왔습니다.")
        except Exception as exc:
            st.warning(f"목록 조회 실패: {exc}. 기본 후보나 직접 입력을 사용할 수 있습니다.")
    choices = list(dict.fromkeys([
        saved_model, DEFAULT_MODEL, "gpt-4.1-nano", "gpt-4.1",
        *st.session_state.get("api_model_ids", []),
    ]))
    manual_option = "직접 입력…"
    selected_model = st.selectbox(
        "OpenAI 모델", choices + [manual_option], key="openai_model_choice",
        help="실제 OpenAI API 모델 ID를 선택하세요. Codex 표시명은 API ID와 다를 수 있습니다.",
    )
    model = (st.text_input("모델 ID 직접 입력", value=saved_model,
             key="openai_manual_model") if selected_model == manual_option else selected_model).strip()
    if not model:
        st.warning("사용할 모델 ID를 입력하세요.")
    st.caption("기본 후보의 계정 접근 권한은 다를 수 있습니다. API 목록에 표시돼도 이 앱의 분석 형식 지원 여부는 모델마다 다릅니다.")
    # MODEL_SELECTOR_END
    template = st.text_input("Origin 2020 템플릿 경로 (.otpu, 선택)", settings.get("template", DEFAULT_TEMPLATE))
    line_width = st.number_input("Origin 선 두께", min_value=.1, max_value=10., value=float(settings.get("line_width", 3.)), step=.1)
    auto_db = st.checkbox("데이터 정리 시 SQLite에도 자동 저장", value=settings.get("auto_db", True))
    if not USE_SAVED_SETTINGS:
        st.caption("코드 상단 기본값을 사용 중입니다. UI 기본값을 저장·복원하려면 USE_SAVED_SETTINGS를 True로 바꾸세요.")
    if st.button("경로·모델·선 두께 기본값 저장", disabled=not USE_SAVED_SETTINGS):
        try:
            if not model:
                raise ValueError("모델 ID를 입력한 뒤 저장하세요.")
            SETTINGS_FILE.write_text(json.dumps({"workspace": str(workspace), "model": model,
                "template": template, "line_width": line_width, "auto_db": auto_db}, ensure_ascii=False, indent=2), encoding="utf-8")
            st.success("다음 실행에도 사용할 기본값을 저장했습니다. API 키는 저장하지 않습니다.")
        except (OSError, ValueError) as exc:
            st.error(f"기본값 저장 실패: {exc}")
    st.caption("API 키는 코드 상단 또는 OPENAI_API_KEY 환경변수에 입력합니다. OpenAI API 사용료는 ChatGPT 구독과 별개입니다.")
    st.info("AI 구조 분석 시 파일명·일부 원본 행·수치 범위가 OpenAI로 전송됩니다. 'AI 해석' 시 계산된 요약이 전송됩니다. 원본과 SQLite는 이 PC에 저장됩니다.")

db_path = workspace / "experiments.sqlite3"
work_tab, db_tab = st.tabs(["파일 정리 · 플롯", "누적 실험 DB"])
with work_tab:
    uploads = st.file_uploader("측정 파일 여러 개 업로드", type=["xlsx", "xls", "csv", "txt", "dat", "tsv"], accept_multiple_files=True)
    request = st.text_area("어떻게 정리할까요?", value="전압을 X로 사용하고 측정값을 Y로 찾아줘. 인가전압 조건이 같은 측정끼리 묶고 공정 split 조건별로 색을 구분해줘. 불확실한 조건은 추측하지 마.", height=110)
    if uploads:
        signature = digest(stable_json([str(workspace.resolve())] + [(f.name, digest(f.getvalue())) for f in uploads]).encode())
        if st.session_state.get("upload_signature") != signature:
            st.session_state.pop("tables", None)
            st.session_state.pop("plan", None)
            clear_results()
        if st.button("1. 파일 읽기 · 데이터 구간 탐색", type="primary"):
            try:
                with st.spinner("원본 보관 및 전체 시트 탐색 중..."):
                    tables = load_tables([(f.name, f.getvalue()) for f in uploads], workspace / "raw")
                    st.session_state.tables = tables
                    st.session_state.upload_signature = signature
                    set_plan(default_plan(tables))
                st.success(f"{len(tables)}개 시트/텍스트를 읽었습니다. 원본은 SHA-256 이름으로 보관했습니다.")
            except Exception as exc:
                st.error(f"파일 읽기 실패: {exc}")
    tables = st.session_state.get("tables") if uploads else None
    if tables:
        st.dataframe(pd.DataFrame([{
            "source_id": t.source_id, "파일": t.filename, "시트": t.sheet,
            "행": len(t.frame), "열": t.frame.shape[1], "수치구간(원본 행)": str(numeric_blocks(t.frame)),
        } for t in tables]), hide_index=True, width="stretch")
        with st.expander("원본 시트 확인 (처음 100행)"):
            from openpyxl.utils import get_column_letter
            chosen = st.selectbox("시트 선택", list(range(len(tables))), format_func=lambda i: f"{tables[i].filename} / {tables[i].sheet}")
            frame = tables[chosen].frame.head(100).copy()
            frame.columns = [get_column_letter(i + 1) for i in range(frame.shape[1])]
            frame.index = frame.index + 1
            st.dataframe(frame.fillna("").astype(str), width="stretch")
        if st.button("2. OpenAI로 요청에 맞게 행·열·측정 조건 찾기", disabled=not model):
            try:
                with st.spinner("파일 구조를 분석 중입니다. DB 저장이나 Origin 실행은 아직 하지 않습니다..."):
                    proposed = ai_plan(tables, request, get_key(), model)
                    # Validate before handing an AI plan to widgets; allow an empty
                    # selection only to display a reason and let the user re-plan.
                    from lab_core import validate_plan
                    validate_plan(proposed, tables, allow_empty=True)
                    set_plan(proposed)
                st.success("정리 계획을 만들었습니다. 아래 표에서 확인·수정하세요.")
            except Exception as exc:
                st.error(f"OpenAI 분석 실패: {exc}")
        if "plan" in st.session_state:
            st.subheader("3. 정리 계획 확인 · 수정")
            for note in st.session_state.plan["notes"]:
                st.info(note)
            edited_plan = plan_editor(st.session_state.plan)
            with st.expander("계획 JSON 직접 교체 (다른 블록 추가 등)"):
                manual = st.text_area("source_id는 위 표의 값을 사용하세요.", json.dumps(st.session_state.plan, ensure_ascii=False, indent=2), height=200, key=f"manual_{st.session_state.plan_revision}")
                if st.button("JSON 계획 적용"):
                    try:
                        from lab_core import validate_plan
                        candidate = validate_plan(json.loads(manual), tables)
                        set_plan(candidate)
                        st.rerun()
                    except Exception as exc:
                        st.error(f"계획 오류: {exc}")
            if st.button("4. 이 계획으로 데이터 정리 · 저장", type="primary"):
                try:
                    with st.spinner("유효한 X-Y 쌍 추출, 교차점 계산, 파일 저장 중..."):
                        curves = materialize(edited_plan, tables)
                        run_id = uuid.uuid4().hex
                        run_dir = workspace / "runs" / run_id
                        run_dir.mkdir(parents=True, exist_ok=False)
                        (run_dir / "plan.json").write_text(json.dumps(edited_plan, ensure_ascii=False, indent=2), encoding="utf-8")
                        (run_dir / "cleaned.xlsx").write_bytes(export_excel(curves))
                        (run_dir / "summary.csv").write_bytes(csv_bytes(summary_frame(curves)))
                        (run_dir / "points.csv").write_bytes(csv_bytes(points_frame(curves)))
                        result = {"run_id": run_id, "run_dir": str(run_dir.resolve()), "db_path": str(db_path.resolve()), "request": request, "plan": edited_plan, "curves": curves, "db_saved": False}
                        clear_results()
                        st.session_state.result = result
                    st.success(f"{len(curves)}개 곡선 정리 완료: {run_dir}")
                    if auto_db:
                        try:
                            count = save_run(db_path, run_id, request, edited_plan, curves)
                            result["db_saved"] = True
                            st.success(f"SQLite 저장 완료: 새 곡선 {count}개. 동일 원본·설정은 중복 저장하지 않습니다.")
                        except Exception as exc:
                            st.error(f"파일 정리는 완료했지만 DB 저장 실패: {exc}. 아래 버튼으로 재시도할 수 있습니다.")
                except Exception as exc:
                    st.error(f"데이터 정리 실패: {exc}")

    result = st.session_state.get("result") if tables else None
    if result:
        curves, plan = result["curves"], result["plan"]
        run_dir = Path(result["run_dir"])
        st.subheader("저장된 결과")
        st.caption("아래는 마지막 '데이터 정리 · 저장'에서 확정한 결과입니다. 위 설정을 바꿨다면 다시 정리 버튼을 눌러 적용하세요.")
        st.dataframe(summary_frame(curves), hide_index=True, width="stretch")
        excluded = sum(c.excluded_rows for c in curves)
        if excluded:
            st.warning(f"선택한 구간에서 숫자가 아니거나 X/Y가 비어 제외된 행이 곡선별 합계 {excluded}개 있습니다. 제외 구간 사이로 보간하지 않습니다.")
        st.caption("교차점의 point는 정리된 곡선의 1-based 위치입니다. exact는 실측점, linear는 인접 유효점 사이 선형 보간입니다. 이를 자동으로 Pr/Ec로 판정하지 않습니다.")
        preview(curves, plan)
        st.download_button("정리 Excel 다운로드", (run_dir / "cleaned.xlsx").read_bytes(), "cleaned.xlsx")
        st.download_button("정리 계획 JSON 다운로드", (run_dir / "plan.json").read_bytes(), "plan.json")
        st.download_button("전체 데이터 CSV 다운로드", (run_dir / "points.csv").read_bytes(), "points.csv")
        if st.button("이 결과를 DB에 저장 / 재확인"):
            try:
                count = save_run(Path(result["db_path"]), result["run_id"], result["request"], plan, curves)
                result["db_saved"] = True
                st.success(f"DB 저장 완료: 새 곡선 {count}개")
            except Exception as exc:
                st.error(f"DB 저장 실패: {exc}")
        if st.button("5. Origin 2020으로 플롯 · OPJU 저장"):
            try:
                output = run_dir / f"Origin_{uuid.uuid4().hex[:8]}.opju"
                with st.spinner("Windows의 Origin을 제어 중..."):
                    st.session_state.origin_result = plot_origin(curves, plan, output, template, line_width, prog_id=ORIGIN_PROG_ID)
                st.success(f"Origin 저장 완료: {output}")
            except Exception as exc:
                st.error(f"Origin 실행 실패: {exc}")
                st.caption("표시된 실패 단계와 오류 문구를 복사해 알려주세요. 정리 Excel/DB는 유지됩니다.")
        if "origin_result" in st.session_state:
            st.json(st.session_state.origin_result)
        if st.button("6. 계산 결과를 OpenAI로 해석", disabled=not model):
            try:
                with st.spinner("계산된 수치 요약을 해석 중..."):
                    st.session_state.interpretation = ai_interpret(curves, result["request"], get_key(), model)
                    (run_dir / "analysis.md").write_text(st.session_state.interpretation, encoding="utf-8")
            except Exception as exc:
                st.error(f"AI 해석 실패: {exc}")
        if "interpretation" in st.session_state:
            st.markdown(st.session_state.interpretation)

with db_tab:
    st.caption(f"DB 위치: {db_path}")
    if db_path.is_file():
        try:
            a, b = st.columns(2)
            filter_voltage = a.text_input("인가전압 조건 (V, 정확히 일치 / 빈칸=전체)")
            filter_split = b.text_input("공정 split (정확히 일치 / 빈칸=전체)")
            filters = {"split_condition": filter_split}
            if filter_voltage.strip():
                filters["voltage_v"] = float(filter_voltage)
            stored = query_curves(db_path, filters)
            visible = ["curve_id", "filename", "sheet", "label", *META_FIELDS]
            st.dataframe(stored[visible], hide_index=True, width="stretch")
            st.download_button("검색 결과 CSV", csv_bytes(stored), "db_search.csv")
            chosen_ids = st.multiselect("저장된 곡선 다시 보기", stored.curve_id.tolist(), format_func=lambda cid: stored.loc[stored.curve_id == cid, "label"].iloc[0])
            if chosen_ids:
                fig = go.Figure()
                with closing(sqlite3.connect(db_path)) as con:
                    for cid in chosen_ids:
                        frame = pd.read_sql_query("SELECT source_row,x,y FROM points WHERE curve_id=? ORDER BY point_index", con, params=(cid,))
                        spec = json.loads(stored.loc[stored.curve_id == cid, "spec_json"].iloc[0])
                        data = frame.set_index("source_row").reindex(range(int(frame.source_row.min()), int(frame.source_row.max()) + 1))
                        fig.add_trace(go.Scattergl(x=data.x, y=data.y, mode="lines", connectgaps=False, name=f"{spec['label']} | {spec['y_name']} [{spec['y_unit']}]"))
                st.warning("DB 재보기는 선택한 곡선을 그대로 겹칩니다. 축 물리량·단위·측정 조건이 같은지 확인하세요.")
                st.plotly_chart(fig, width="stretch")
        except Exception as exc:
            st.error(f"DB 조회 실패: {exc}")
    else:
        st.info("데이터 정리 후 DB 저장을 실행하면 검색할 수 있습니다.")
