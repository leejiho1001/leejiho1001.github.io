"""Mock COM protocol tests; these do NOT validate a real Origin installation."""
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from lab_core import default_plan, load_tables, materialize
from origin_adapter import plot_origin


class OriginProtocolTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        tables = load_tables([("demo_3V.csv", b"V,I\n-1,-2\n0,1\n1,2\n")], self.root / "raw")
        self.plan = default_plan(tables)
        self.curves = materialize(self.plan, tables)
        self.origin = Mock()
        self.origin.CreatePage.side_effect = lambda page_type, name, template: name
        self.origin.Execute.return_value = True
        self.origin.Save.side_effect = self.save
        self.com = types.ModuleType("pythoncom")
        self.com.CoInitialize = Mock()
        self.com.CoUninitialize = Mock()
        self.client = types.ModuleType("win32com.client")
        self.client.Dispatch = Mock(return_value=self.origin)
        self.client.DispatchEx = Mock(return_value=self.origin)
        self.package = types.ModuleType("win32com")
        self.package.client = self.client

    def tearDown(self):
        self.temp.cleanup()

    def save(self, path):
        Path(path).write_bytes(b"MOCK-OPJU-NOT-A-REAL-PROJECT")
        return True

    def run_plot(self, **kwargs):
        with patch.dict(sys.modules, {"pythoncom": self.com, "win32com": self.package, "win32com.client": self.client}), patch("origin_adapter.sys.platform", "win32"):
            return plot_origin(self.curves, self.plan, self.root / "result.opju", **kwargs)

    def test_original_si_connection_transfers_xy_and_saves(self):
        result = self.run_plot()
        self.client.Dispatch.assert_called_once_with("Origin.ApplicationSI")
        self.client.DispatchEx.assert_not_called()
        self.assertEqual(result["curve_count"], 1)
        self.assertEqual(self.origin.PutWorksheet.call_args_list[0].args[1], [-1., 0., 1.])
        self.assertEqual(self.origin.PutWorksheet.call_args_list[1].args[1], [-2., 1., 2.])
        self.origin.NewProject.assert_not_called()
        self.origin.Quit.assert_not_called()
        self.com.CoUninitialize.assert_called_once()

    def test_separate_instance_is_an_explicit_option(self):
        self.run_plot(prog_id="Origin.Application")
        self.client.Dispatch.assert_not_called()
        self.client.DispatchEx.assert_called_once_with("Origin.Application")

    def test_failure_reports_stage_and_cleans_com_without_saving(self):
        self.origin.Execute.side_effect = lambda command: not command.startswith("plotxy")
        with self.assertRaisesRegex(RuntimeError, "LabTalk 플롯 생성"):
            self.run_plot()
        self.origin.Save.assert_not_called()
        self.com.CoUninitialize.assert_called_once()

    def test_save_failure_is_reported_even_if_file_exists(self):
        def failed_save(path):
            Path(path).write_bytes(b"incomplete")
            return False
        self.origin.Save.side_effect = failed_save
        with self.assertRaisesRegex(RuntimeError, "OPJU 파일 저장"):
            self.run_plot()
        self.com.CoUninitialize.assert_called_once()


if __name__ == "__main__":
    unittest.main(verbosity=2)
