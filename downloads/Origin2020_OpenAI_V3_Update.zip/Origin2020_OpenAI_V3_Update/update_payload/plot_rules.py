"""Deterministic plotting choices shared by the web preview and Origin export."""
from __future__ import annotations

import copy
import re
from pathlib import Path
from string import Formatter

from openpyxl.utils import column_index_from_string


PLOT_DEFAULTS = {"plot_mode": "combined", "measurement": "auto", "legend_format": ""}
PLOT_MODES = ("combined", "separate", "grouped")
MEASUREMENTS = ("auto", "PV", "IV", "manual")
AXIS_NAMES = {"voltage": "Voltage", "polarization": "Polarization", "current": "Current",
              "current_density": "Current density", "time": "Time", "field": "Electric field", "charge": "Charge"}
LEGEND_FIELDS = {"filename", "stem", "sheet", "x_name", "y_name", "x_unit", "y_unit",
                 "device_id", "measurement_type", "voltage_v", "frequency_hz", "temperature_c",
                 "cycle", "split_condition", "device_stack", "treatment"}


def unit_text(text: str) -> str:
    return (str(text).replace("µ", "u").replace("μ", "u").replace("²", "2")
            .replace("^2", "2").replace("−", "-").replace(" ", "").strip())


def axis_info(name: str, unit: str = "") -> tuple[str, str]:
    """Recognize explicit labels/units, never infer physics from numeric ranges."""
    text = str(name).strip()
    normalized = unit_text(unit)
    if not normalized:
        match = re.search(r"\(([^)]+)\)|\[([^\]]+)\]", text)
        if match:
            normalized = unit_text(match.group(1) or match.group(2))
    name_only = re.sub(r"[\[(].*", "", text).strip()
    if re.search(r"polar|분극", name_only, re.I) or re.fullmatch(r"P\d*", name_only, re.I):
        kind = "polarization"
    elif re.search(r"current.?density|전류.?밀도", name_only, re.I) or re.fullmatch(r"J\d*", name_only):
        kind = "current_density"
    elif re.search(r"current|전류", name_only, re.I) or re.fullmatch(r"I\d*", name_only, re.I):
        kind = "current_density" if "/" in normalized else "current"
    elif re.search(r"electric.?field|전계", name_only, re.I):
        kind = "field"
    elif re.search(r"volt|전압", name_only, re.I) or re.fullmatch(r"V\d*", name_only, re.I):
        kind = "voltage"
    elif re.search(r"time|시간", name_only, re.I):
        kind = "time"
    elif re.search(r"charge|전하", name_only, re.I) or re.fullmatch(r"Q\d*", name_only):
        kind = "charge"
    elif re.fullmatch(r"[pnumkM]?C/(?:cm|m)2", normalized):
        kind = "polarization"
    elif re.fullmatch(r"[pnumkM]?A/(?:cm|m)2", normalized):
        kind = "current_density"
    elif re.fullmatch(r"[pnumkM]?A", normalized):
        kind = "current"
    elif re.fullmatch(r"[pnumkM]?V", normalized):
        kind = "voltage"
    else:
        kind = "unknown"
    return kind, normalized


def request_options(request: str) -> dict:
    """Resolve clear commands locally; ambiguous wording remains with the AI/UI."""
    patterns = {
        "combined": r"한\s*그래프|하나(?:의\s*그래프)?로|겹쳐|겹치|합쳐|overlay|combined?",
        "separate": r"각각|따로|개별|separate(?:ly)?",
        "grouped": r"조건별|전압별|온도별|주파수별|grouped",
    }
    matches = {key for key, pattern in patterns.items() if re.search(pattern, request, re.I)}
    options = {"plot_mode": next(iter(matches))} if len(matches) == 1 else {}
    pv = bool(re.search(r"(?<![A-Za-z])P\s*[-–]?\s*V(?![A-Za-z])|분극만", request, re.I))
    iv = bool(re.search(r"(?<![A-Za-z])I\s*[-–]?\s*V(?![A-Za-z])|전류만", request, re.I))
    if pv != iv:
        options["measurement"] = "PV" if pv else "IV"
    return options


def validate_plot_options(plan: dict):
    if plan.get("plot_mode", "combined") not in PLOT_MODES:
        raise ValueError("plot_mode는 combined, separate, grouped 중 하나여야 합니다.")
    if plan.get("measurement", "auto") not in MEASUREMENTS:
        raise ValueError("measurement는 auto, PV, IV, manual 중 하나여야 합니다.")
    pattern = plan.get("legend_format", "")
    if not isinstance(pattern, str) or len(pattern) > 500:
        raise ValueError("범례 형식은 500자 이하 문자열이어야 합니다.")
    try:
        for _, field, spec, conversion in Formatter().parse(pattern):
            if field is None:
                continue
            if field not in LEGEND_FIELDS or conversion or not re.fullmatch(r"(?:\.\d{1,2})?[fgGeEd]?", spec):
                raise ValueError("지원하지 않는 범례 필드/형식입니다: " + str(field))
    except ValueError as exc:
        raise ValueError(f"범례 형식을 확인하세요: {exc}") from exc


def legend_label(spec: dict, source, pattern: str) -> str:
    if not pattern:
        return spec["label"]
    context = {**spec["metadata"], **{k: spec[k] for k in ("label", "x_name", "y_name", "x_unit", "y_unit")},
               "filename": source.filename, "stem": Path(source.filename).stem, "sheet": source.sheet}
    parts = []
    for literal, field, formatting, _ in Formatter().parse(pattern):
        parts.append(literal)
        if field is not None:
            value = context[field]
            try:
                parts.append("미확인" if value is None else format(value, formatting))
            except (ValueError, TypeError) as exc:
                raise ValueError(f"범례 {{{field}:{formatting}}}에 맞지 않는 값입니다.") from exc
    label = "".join(parts)
    if len(label) > 500:
        raise ValueError("생성된 범례가 500자를 넘습니다.")
    return label


def prepare_plot_plan(plan: dict, tables: list, header_reader) -> dict:
    """Correct inverted V-Y pairs from raw headers, preserving acquisition order."""
    result = copy.deepcopy(plan)
    for key, value in PLOT_DEFAULTS.items():
        result.setdefault(key, value)
    validate_plot_options(result)
    sources = {table.source_id: table for table in tables}
    selected = []
    reversed_count = 0
    for spec in result["curves"]:
        source = sources[spec["source_id"]]
        kinds = {}
        for axis in ("x", "y"):
            col = column_index_from_string(spec[f"{axis}_column"]) - 1
            raw_name = header_reader(source, spec["start_row"], col)
            raw_kind, raw_unit = axis_info(raw_name)
            named_kind, named_unit = axis_info(spec[f"{axis}_name"], spec[f"{axis}_unit"])
            kinds[axis] = raw_kind if raw_kind != "unknown" else named_kind
            if result["measurement"] != "manual":
                spec[f"{axis}_unit"] = raw_unit or named_unit
                if kinds[axis] != "unknown":
                    spec[f"{axis}_name"] = AXIS_NAMES[kinds[axis]]
        if result["measurement"] != "manual":
            if kinds["y"] == "voltage" and kinds["x"] in ("polarization", "current", "current_density"):
                for suffix in ("column", "name", "unit"):
                    spec[f"x_{suffix}"], spec[f"y_{suffix}"] = spec[f"y_{suffix}"], spec[f"x_{suffix}"]
                kinds["x"], kinds["y"] = kinds["y"], kinds["x"]
                reversed_count += 1
            measurement = "PV" if kinds["x"] == "voltage" and kinds["y"] == "polarization" else (
                "IV" if kinds["x"] == "voltage" and kinds["y"] in ("current", "current_density") else "other")
            target = result["measurement"]
            if target in ("PV", "IV") and measurement != target:
                continue
            if measurement != "other":
                spec["metadata"]["measurement_type"] = measurement
        spec["label"] = legend_label(spec, source, result["legend_format"])
        selected.append(spec)
    result["curves"] = selected
    if reversed_count:
        result["notes"].append(f"원본 헤더 기준으로 {reversed_count}개 곡선의 X/Y를 바로잡았습니다: X=전압, Y=분극/전류.")
    if not selected:
        raise ValueError("선택한 P–V/I–V에 맞는 전압·측정값 열을 찾지 못했습니다. 열/헤더를 확인하거나 '열 지정 그대로' 모드를 사용하세요.")
    return result


def grouping_axes(spec: dict) -> list[str]:
    result = []
    for axis in ("x", "y"):
        kind, unit = axis_info(spec[f"{axis}_name"], spec[f"{axis}_unit"])
        result.extend([kind if kind != "unknown" else spec[f"{axis}_name"].strip().casefold(), unit])
    return result
